# Copyright 2004-2009, David Wang, dwang@liberty.edu
# Customized for PSPad: always return 1
use strict;

local $SIG{'__WARN__'} = sub { }; # no compile-time or run-time warnings. for controlling eval's error msgs
#local $SIG{'__DIE__'} = sub { };

if ($#ARGV < 0) {
	print "No inline-script input file found.\n";
	exit 1;
}

my $__script = '';
my $__file = $ARGV[0];
my @__exts;
my ($__read_file, $__overwrite_file, $__include_subdirs, $__fname, $__path, $__pname);
my ($__backup_files, $__delete_backup_files, $__restore_from_backup, $__process_dirs_only);
my ($__x, $__y, $__z, $__count);
my (@__x, @__y, @__z);
my (%__x, %__y, %__z);
my $__bak_ext = 'is~';
my @unaccessible_dirs;

unless (open FILE, "<$ARGV[0]") {
	print "Failed to open file $__file\n";
	exit 1;
}

{
	my $lineno = 0;
	my $script_closed = 0;

	# fetch Perl script between <?perl and ?>
	while (<FILE>) {
		$lineno++;
		if (/^\s*<\?perl\s*$/i) {
			$__script .= "#$_";
			last;
		} elsif (/^\s*$/ or /^\s*#/) {
			$__script .= $_;
		} else {
			&__err_msg;
		}
	}

	while (<FILE>) {
		$lineno++;
		if (/^\s*\?>\s*$/) {
			$script_closed = 1;
			last;
		}
		if (/__FILE_EXTS\s*/) {
			if (/^\s*__FILE_EXTS\s+([^;]*)/) {
				my $exts = $1;
				$exts =~ s/^\.//;
				$exts =~ s/\s\./ /g;
				$exts =~ s/[,]/ /g;
				$exts =~ s/^\s+//;
				$exts =~ s/\s+$//;
				unless ($exts =~ /^[\s\w\*]*$/) {
					my @tmp = split(/\n/, $__script);
					my $tmp = $#tmp + 2;
					print "Invalid file name extensions given at file $__file on line $tmp.\n";
					exit 1;
				}
				@__exts = split(/\s+/, $exts);
				foreach (@__exts) {
					if ($_ eq '*') {
						$__exts[0] = '*';
						last;
					}
				}
			}
			$_ = "#\n";
		} elsif (/__OVERWRITE_FILE\s*;/) {
			$__overwrite_file = 1 if /^\s*__OVERWRITE_FILE\s*;/;
			$_ = "#\n";
		} elsif (/__INCLUDE_SUB_DIRS\s*;/) {
			$__include_subdirs = 1 if /^\s*__INCLUDE_SUB_DIRS\s*;/;
			$_ = "#\n";
		} elsif (/__BACKUP_FILES\s*;/) {
			$__backup_files = 1 if /^\s*__BACKUP_FILES\s*;/;
			$_ = "#\n";
		} elsif (/__DELETE_BACKUP_FILES\s*;/) {
			$__delete_backup_files = 1 if /^\s*__DELETE_BACKUP_FILES\s*;/;
			$_ = "#\n";
		} elsif (/__RESTORE_FROM_BACKUP\s*;/) {
			$__restore_from_backup = 1 if /^\s*__RESTORE_FROM_BACKUP\s*;/;
			$_ = "#\n";
		} elsif (/__PROCESS_DIRS_ONLY\s*;/) {
			$__process_dirs_only = 1 if /^\s*__PROCESS_DIRS_ONLY\s*;/;
			$_ = "#\n";
		} elsif ($__overwrite_file) {
			s/sprintf/SPRFxXx/g;
			s/print\s+STD/PRTxXx/g;
			s/printf\s+STD/PRTFxX/g;

			s/(printf?)\s*([^\(\[])/$1 __OUT $2/g; # print[f] (..) => output to screen always

			s/PRTxXx/print STD/g;
			s/PRTFxX/printf STD/g;
			s/SPRFxXx/sprintf/g;
		}

		$__script .= $_;
		if (!$__read_file) {
			if (/^(.*)#.*<\s*FILE\s*>/) {
				if ($1 !~ /^\s*$/) {
					# to simplify coding and thus make it easy to recognize read-file-content-operation
					print "non-Perl syntax error at $__file line $lineno: # in front of <FILE>\n";
					exit 1;
				}
			} elsif (/<\s*FILE\s*>/) {
				$__read_file = 1;
			}
		}
	}

	$script_closed or &__err_msg;

	if ($__overwrite_file) { # 10/14/2004
		unless ($__script =~ /printf? __OUT /) {
			print "Failed: you chose to overwrite file(s) with empty output!";
			exit 1;
		}
	}
	if (@__exts and ($__delete_backup_files or $__restore_from_backup)) {
		@__exts = ( $__bak_ext );
	}
	$__backup_files = 0 unless $__overwrite_file;
}

if ($__process_dirs_only) { # 10/11/2004
	close FILE;
	if ($__overwrite_file) {
		print "Failed: you turned on both __PROCESS_DIRS_ONLY and __OVERWRITE_FILE.";
		exit 1;
	}
	if ($__read_file) {
		print "Failed: you are to read file while turning on __PROCESS_DIRS_ONLY.";
		exit 1;
	}
	if ($__restore_from_backup) {
		print "Failed: you turned on both __PROCESS_DIRS_ONLY and __RESTORE_FROM_BACKUP.\n";
		exit 1;
	}
	if ($__delete_backup_files) {
		print "Failed: you turned on both __PROCESS_DIRS_ONLY and __DELETE_BACKUP_FILES.\n";
		exit 1;
	}
	$__backup_files = 0;
	#if ($__backup_files) {
	#	print "Failed: you turned on both __PROCESS_DIRS_ONLY and __BACKUP_FILES.\n";
	#	close FILE;
	#	exit 1;
	#}
} else {
	if ($__overwrite_file and !$__read_file) {
		print "You chose to overwrite file without reading file contents. That's not allowed.";
		close FILE;
		exit 1;
	}

	if ($__overwrite_file and $__restore_from_backup) {
		print "Confusing choices: both __OVERWRITE_FILE and __RESTORE_FROM_BACKUP turned on.";
		close FILE;
		exit 1;
	}

	if ($__backup_files and $__delete_backup_files) {
		print "Confusing choices: __BACKUP_FILES and __DELETE_BACKUP_FILES turned on.\n";
		close FILE;
		exit 1;
	}

	if ($__overwrite_file and $__delete_backup_files) {
		print "Confusing choices: both __OVERWRITE_FILE and __DELETE_BACKUP_FILES turned on.";
		close FILE;
		exit 1;
	}

	if ($__restore_from_backup and $__delete_backup_files) {
		print "Confusing choices: __RESTORE_FROM_BACKUP and __DELETE_BACKUP_FILES turned on.\n";
		close FILE;
		exit 1;
	}

	if ($__backup_files and $__restore_from_backup) {
		print "Confusing choices: __BACKUP_FILES and __RESTORE_FROM_BACKUP turned on.\n";
		close FILE;
		exit 1;
	}

	if ($__restore_from_backup or $__delete_backup_files) {
		if ($__restore_from_backup) {
			print "You turned on __RESTORE_FROM_BACKUP to restore file(s) from backup.\n";
		} else {
			print "You turned on __DELETE_BACKUP_FILES to delete backup file(s).\n";
		}
		print "(After the job is done, please turn off it.)\n";
	}
}

if (@__exts or $__process_dirs_only) { # process files/directories in batch way
	close FILE;

	my $code;
	if ($__process_dirs_only) {
		$code =
'sub __process_file {' .
	'$__fname = $_[0];' .
	'$__pname = "$__path/$__fname";' .
	$__script .
'}';
	} else {
		$code =
'sub __process_file {' .
	'$__fname = $_[0];' .
	'$__pname = "$__path/$__fname";' .
	'if ($__restore_from_backup) {' .
		'$__pname =~ /^(.*)\.$__bak_ext$/;' .
		'my $ori_pname = $1;' .
		'unless (rename "$__pname", "$ori_pname") {' .
			'unless (open BAKFILE, "<$__pname") {' .
				'print "Failed to read backup file, $__pname\n";' .
				'exit 1;' .
			'}' .
			'unless (open ORIFILE, ">$ori_pname") {' .
				'close BAKFILE;' .
				'print "Failed to restore file, $ori_pname\n";' .
				'exit 1;' .
			'}' .
			'while (<BAKFILE>) {' .
				'print ORIFILE "$_";' .
			'}' .
			'close BAKFILE;' .
			'close ORIFILE;' .
		'}' .
		'return;' .
	'} elsif ($__delete_backup_files) {' .
		'unlink "$__pname";' .
		'return;' .
	'}' .
	'my $bak_ext = ".$__bak_ext";' .
	'if ($__overwrite_file) {' .
		'unless (rename "$__pname", "$__pname$bak_ext") {' .
			'unless (open BAKFILE, ">$__pname$bak_ext") {' .
				'print "Failed to create temporary file, $__pname$bak_ext";' .
				'return;' .
			'}' .
			'unless (open ORIFILE, "<$__pname") {' .
				'close BAKFILE;' .
				'print "Failed to read file, $__pname";' .
				'return;' .
			'}' .
			'while (<ORIFILE>) {' .
				'print BAKFILE "$_";' .
			'}' .
			'close BAKFILE;' .
			'close ORIFILE;' .
		'}' .
	'} else {' .
		'$bak_ext = "";' .
	'}' .
	'if ($__read_file) {' .
		'unless (open FILE, "<$__pname$bak_ext") {' .
			'push @unaccessible_dirs, $__pname;' .
			'return;' .
		'}' .
	'}' .
	'if ($__overwrite_file) {' .
		'unless (open __OUT, ">$__pname") {' .
			'close FILE;' .
			'print "Failed to overwrite file $__pname\n";' .
			'return;' .
		'}' .
	'}' .
	$__script .
	'close FILE if $__read_file;' .
	'if ($__overwrite_file) {' .
		'close __OUT;' .
		'unlink("$__pname$bak_ext") unless $__backup_files;' .
	'}' .
'}'
	};

	eval($code);
	if ($@) {
		my $err = $@;
		$err =~ s/\(eval \d+\)/$__file/g;
		$err =~ s/, <> line \d+\.//g;
		print "$err";
		exit 1;
	}

	my $path;
	if ($__path) { # user may use BEGIN to indicate different directory
		$path = $__path;
		$path =~ s/[\/\\]$//; # delete ending /
	} else {
		my @parts = split(/[\\\/]/, $ARGV[0]);
		$path = join('/', @parts[0..$#parts-1]);
	}
	$path = &expand_path($path);

	#my $oldDir = `pwd`;	# Win32 has no such command
	#chomp $oldDir;

	if (chdir "$path") {
		__traverse_dir($path);

		print "\n" if @unaccessible_dirs;
		foreach (@unaccessible_dirs) {
			print "Failed to access '$_'\n";
		}
	} else {
		print "Error: no directory '$path', or no access permission.";
		exit 1;
	}
	#chdir $oldDir;
} else {	 # process current file only
	my @parts = split(/[\\\/]/, $ARGV[0]);
	$__path = &expand_path(join('/', @parts[0..$#parts-1]));
	$__fname = $parts[-1];
	$__pname = &expand_path($ARGV[0]);

	my $code = "sub __process_file {\n $__script \n}"; # we may only need BEGIN and END blocks!
	eval($code);	# evaluate here to activate BEGIN and END blocks

	if ($__restore_from_backup) {
		close FILE;
		my $bak_pname = "$__pname.$__bak_ext";
		unless (open BAKFILE, "<$bak_pname") {
			print "Failed to read backup file, $bak_pname\n";
			exit 1;
		}
		unless (open ORIFILE, ">$__pname") {
			close BAKFILE;
			print "Failed to restore file, $__pname\n";
			exit 1;
		}
		while (<BAKFILE>) {
			print ORIFILE "$_";
		}
		close BAKFILE;
		close ORIFILE;
		printf "Done. You may need to reload the file manually.";
		exit 1;
	} elsif ($__delete_backup_files) {
		unlink "$__pname.$__bak_ext";
		printf "Done.";
		exit 1;
	}

	if ($@) {
		my $err = $@;
		$err =~ s/\(eval \d+\)/$__file/g;
		$err =~ s/, <> line \d+\.//g;
		print "$err";
		print "\nPlease don't reload current file!";
		exit 1;
	}

	if ($__overwrite_file) {
		# copy hosting file to temp file
		unless (open __OUT, ">$__pname.$__bak_ext") {
			print "Failed to create temporary file $__pname.$__bak_ext\n";
			return;
		}
		while (<FILE>) {
			print __OUT "$_";
		}
		close FILE;
		close __OUT;

		# process temp file to generate new hosting file
		unless (open __OUT, ">$__pname") {
			print "Failed to modify hosting file\n";
			return;
		}
		open FILE, "<$__pname.$__bak_ext";
	}
	&__process_file;
	close FILE;
	if ($__overwrite_file) {
		close __OUT;
		unlink("$__pname.$__bak_ext") unless $__backup_files;
	}
}

print "Done.\n" if $__restore_from_backup or $__delete_backup_files;

# UNIX/Linux's ~ is to be expanded to HOME 09/21/2004
sub expand_path {
	my $path = $_[0];
	unless ($path and $path !~ /^~/) {
		my $home = $ENV{'HOME'};
		$home = $ENV{'LOGDIR'} unless $home;
		# $home = $ENV{'SYS$LOGIN'} unless $home;  # under VMS
		if ($path) {
			$path =~ s/^~/$home/;
		} else { # for VIM
			$path = $home;
		}
	}
	$path =~ s/\\/\//g; # Win32 path to UNIX/Linux
	return $path;
}

sub __traverse_dir {
	$__path = $_[0];
	if (opendir DIR, "$__path") {
		my ($item, @items, @dirs);
		@items = readdir(DIR);
		closedir DIR;
		if ($__process_dirs_only) {
			foreach $item (@items) {
				unless ($item =~ /^\.+$/) {
					&__process_file("$item") if -d "$__path/$item";
				}
			}
		} else {
			foreach $item (@items) {
				if ($item =~ /^\.+$/) {
				} elsif (-d "$__path/$item") {
					push @dirs, "$__path/$item";
				} elsif (&__ext_match($item)) {
					&__process_file("$item");
				}
			}
		}

		if ($__include_subdirs) {
			foreach (@dirs) {
				__traverse_dir($_);
			}
		}
	} else {
		push @unaccessible_dirs, $__path;
	}
}

sub __ext_match {
	my $fname = $_[0];
	return 1 if ($__exts[0] eq '*');
	foreach (@__exts) {
		return 1 if ($fname =~ /\.$_$/i);
	}
	return 0;
}

sub __err_msg {
	print << "HTML";
# Inline Perl script must appear at the head of current file, taking form <?perl ... ?>.
#
# Global variables you can use:
# \$__x, \$__y, \$__z, \$__count, \@__x, \@__y, \@__z, \%__x, \%__y, \%__z -  for any purpose
# \$__fname - name of file/directory being processed
# \$__pname - full path to \$__fname, i.e., \$__path/\$__fname
# \$__path - path to directory where the processed file/directory appears
# \$__file - name of current file where inline script is running
# FILE - handle of file being processed (STDOUT and STDERR are available)
<?perl
    # __FILE_EXTS txt, ini; # uncomment & set extensions of files to be processed (* matches all)
    # __INCLUDE_SUB_DIRS;   # uncomment so as to process files under sub-directories
    # __OVERWRITE_FILE;     # uncomment so as to OVERWRITE text files. In this case,
                            #   1) print[f] argv1,argv2,... will output to file
                            #   2) print[f](argv1,argv2,...) will output to screen
      __BACKUP_FILES;       # comment it so as not to backup original files;
    # __RESTORE_FROM_BACKUP;# restore files from backup (ignore code except BEGIN and END)
    # __DELETE_BACKUP_FILES;# delete backup files (ignore code except BEGIN and END)

    # __PROCESS_DIRS_ONLY;  # all above options except __INCLUDE_SUB_DIRS will be invalid

    # BEGIN {} # executed before processing any file
    # END {}   # executed after processing all files

    # BEGIN { \$__path = 'your directory'; } # process files in directory other than current file's folder

    # your code goes here
    # my \$txt = join('', <FILE>); # treat whole text as one string
    while (<FILE>) { # process text line by line
    }
?>
HTML
	close FILE;
	exit 1;
}

1;
