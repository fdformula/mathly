# extract charge on per item and find sum
<?perl
    my $x = 0;
    while (<FILE>) {
        if (/([-]{0,1}[\d,.]+)$/) {
            my $y = $1;
            $y =~ s/,//g;
            print "$y\n";
            $x += $y;
        }
    }
    print "Total $x";
?>
12/10 12/10 RADIOSHACK LYNCHBURG VA    -26.24
11/16 11/16 KROGER #407 LYNCHBURG VA  Standard Purch 13.70
11/16 11/16 FOOD LION #1538 FOREST VA  Standard Purch 71.01
11/23 11/23 WM SUPERCENTER LYNCHBURG VA  Standard Purch 65.17
11/23 11/23 TARGET LYNCHBURG VA  Standard Purch 1,109.18
12/07 12/07 KROGER #407 LYNCHBURG VA  Standard Purch 11.80
12/07 12/07 SAMSCLUB #6458 LYNCHBURG VA  Standard Purch 52.08

