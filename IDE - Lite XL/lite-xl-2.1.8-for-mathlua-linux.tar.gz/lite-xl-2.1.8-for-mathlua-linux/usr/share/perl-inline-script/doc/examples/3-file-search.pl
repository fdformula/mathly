#find all *.html files which contain all the words, "2004", "perl", and "inline"
#under /usr/.
<?perl
    __FILE_EXTS html;
    __INCLUDE_SUB_DIRS;

	BEGIN { $__path = '/usr/'; }

    my ($year, $perl, $inline) = (0, 0, 0);
    while (<FILE>) {
        $year = 1 if /2004/;
        $perl = 1 if /perl/i;
        $inline = 1 if /inline/i;
        if ($year and $perl and $inline) {
            printf "$__pname\n";
            last;
        }
    }
?>
