-- Animating regula falsi method for solving f(x) = 3cos(x) - 0.3x^2 + 2 = 0, approaching the root from both sides.
-- by David Wang, dwang@liberty.edu, October 2025

mathly = require('mathly')

jscode = [[
  let a = -1.6, b = 5.5;
  let A = a, B = b;
  function f(x) { return 3*Math.cos(x) - 0.3*x**2 + 2; }
  let fa = f(a), fb = f(b);
  var ab = [], midpts = [];
  ab.push([a, b]);
  for (let i = 1; i <= 12; i += 1) {
    let midpt = a - (b - a)/(fb - fa) * fa, fmidpt = f(midpt);
    if (fa * fmidpt > 0) {
      a = midpt; fa = fmidpt;
    } else {
      b = midpt; fb = fmidpt;
    }
    midpts.push(midpt);
    ab.push([a, b]);
  }
  a = A; b = B;

  function displaytext() { return 'Interval [' + ab[I-1][0] + ', ' + ab[I-1][1] + '], <em>x</em>-intercept = ' + midpts[I-1]; }
]]

fstr = {'@(t) t', '@(t) f(ab[I-1][0]) + (f(ab[I-1][1]) - f(ab[I-1][0])) / (ab[I-1][1] - ab[I-1][0]) * (t - ab[I-1][0])'}
opts = {
  I = {1, 12, 1, label = 'Iterations'},
  xrange = {-2.5, 6.1}, yrange = {-6, 6},
  layout = {
    width = 640, height = 640, square = false,
    title = "<font size=4>Regula falsi method for 3cos <em>x</em> - 0.3<em>x</em><sup>2</sup> + 2 = 0 starting on [-1.6, 5.5]</font>"
  },
  javascript = jscode, controls = 'I',
  enhancements = {
    {x = {'ab[I-1][0]', 'ab[I-1][1]'}, y = {'f(ab[I-1][0])', 'f(ab[I-1][1])'}, line = true, width = 1, color = 'grey'},
    {x = '@(t) t', y = '@(t) 3*cos(t) - 0.3*t^2 + 2', t = {-2.5, 6.1}, color = 'orange'},
    {x = {'ab[I-1][0]', 'ab[I-1][0]'}, y = {'f(ab[I-1][0])', 0}, line = true, width = 1, color = 'grey'},
    {x = 'ab[I-1][0]', y = 0, point = true, size = 8, color = 'green'},
    {x = 'ab[I-1][0]', y = 'f(ab[I-1][0])', point = true, size = 12, color = 'green', style="'symbol': 'circle-open'"},
    {x = {'ab[I-1][1]', 'ab[I-1][1]'}, y = {'f(ab[I-1][1])', 0}, line = true, width = 1, color = 'grey'},
    {x = 'ab[I-1][1]', y = 0, point = true, size = 8, color = 'blue'},
    {x = 'ab[I-1][1]', y = 'f(ab[I-1][1])', point = true, size = 12, color = 'blue', style="'symbol': 'circle-open'"},
    {x = 'midpts[I-1]', y = 0, color = 'red', size = 8, point = true},
    {x = 'ab[I-1][0]', y = -0.25, color = 'black', size = 12, text = 'a'},
    {x = 'ab[I-1][1]', y = 0.5, color = 'black', size = 12, text = 'b'}
  }
}
manipulate(fstr, opts)
