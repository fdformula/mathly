# Generate index HTML table for HTML documents in specified directory.
<?perl
    __FILE_EXTS html, htm;
    #__INCLUDE_SUB_DIRS;

	BEGIN { $__path = "/usr/share/emacs/22.1/etc/inline-script/"; }
	END {
		my $columns = 3;
		my $tdwidth = 130;
		my $tabwidth = $tdwidth * $columns;

		print "<CENTER>\n<TABLE width=$tabwidth border=1>\n<TBODY>\n";
		for (my $i = 0; $i <= $#__x; $i += $columns) {
			print "\t<TR>\n";
			for (my $j = 0; $j < $columns; $j++) {
				if ($i + $j <= $#__x) {
					my $url = $__x[$i + $j];
					my $caption = $url;
					$caption =~ s/^.*\///; # remove path
					$caption =~ s/\.html{0,1}$//i; # remove extension of file name

					if ($url ne "&nbsp;") {
						print qq{\t\t<TD align=center width=$tdwidth><A href="$url">$caption</A></TD>\n};
					} else {
						print qq{\t\t<TD>$caption</TD>\n};
					}
				} else {
					print qq{\t\t<TD>&nbsp;</TD>\n};
				}
			}
			print "\t</TR>\n";
		}
		print "</TBODY>\n</TABLE>\n</CENTER>\n";
	}

	# collect file names of HTML documents
	push @__x, $__pname; # $__fname, if path is not needed
?>
