-- Polar equation r^2 = a^2 * t -- not lituus spiral: a^2 / t
mathly = require('mathly')

jscode = [[
  function displaytext() { return "Blue curve: <em>r</em>(<em>&theta;</em>) = <em>a</em> sqrt(<em>&theta;</em>); Red curve: <em>r</em>(<em>&theta;</em>) = &minus;<em>a</em> sqrt(<em>&theta;</em>)"; }
]]

r = 'a * sqrt(t)'
---------------------------------------------------------
fstr1 = {'@(t) (' .. r .. ') * cos(t)', '@(t) (' .. r .. ') * sin(t)'}
fstr2 = {'@(t) (-' .. r .. ') * cos(t)', '@(t) (-' .. r .. ') * sin(t)'}
opts = {
  t = {0, 15 * pi, 0.01}, xrange = {-42, 42}, color = 'blue',
  a = {1, 6, default = 3},
  javascript = jscode, resolution = 1000,
  layout = {
    width = 500, height = 500, square = true,
    xaxis = { visible = false }, yaxis = { visible = false },
    title = '<font size=4>Polar equation: <em>r</em><sup>2</sup> = <em>a</em><sup>2</sup> <em>&theta;</em></font> <font size=1> (Lituus spiral: <em>r</em><sup>2</sup> = <em>a</em><sup>2</sup> / <em>&theta;</em>)</font>'
  },
  enhancements={
    {x = fstr2[1], y = fstr2[2], color = 'red', width = 2, resolution = 1000},
    {x = 'X', y = 'Y', color = 'blue', point = true, size = 5},
    {x = '-X', y = '-Y', color = 'red', point = true, size = 5}
    }
}
animate(fstr1, opts)
