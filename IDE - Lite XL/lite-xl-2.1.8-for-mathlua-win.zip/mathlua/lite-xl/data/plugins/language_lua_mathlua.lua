-- mod-version:3
-- by David Wang, dwang@liberty.edu, on 12/24/2025
--
-- This plugin is primarily for Lua + Mathly. Only one interpreter is allowed at a time. To use another
-- interpreter, you may enter the interpreter terminal, and press ctrl-c or execute commands like
-- os.exit(), exit, quit, exit(), etc., to exit the present interpreter. Then, go to the very file in
-- the editor and press F2 to start the associated interpreter.
--
local core = require "core"
local system = require "system"
local command = require "core.command"
local term = require "terminal" -- Adjust path if necessary

local win_browser = 'C:/Program Files/Mozilla Firefox/firefox.exe'
local linux_browser = 'firefox'
local mac_browser = '/Applications/Firefox.app/Contents/MacOS/firefox'

local perl = 'perl'
local pis_folder = '/usr/share/perl-inline-script/'

local browser = linux_browser
if PLATFORM == "Windows" then
	perl = 'C:/cygwin/bin/perl.exe'
	pis_folder = 'C:/mathlua/perl-inline-script/'
	browser = win_browser
elseif PLATFORM == "Mac OS X" then
	browser = mac_browser
end
win_browser, linux_browser, mac_browser = nil, nil, nil
local pis_engine = pis_folder .. 'inline-script.pl'
local pis_url = 'file:///' .. pis_folder .. 'doc/perlfunc.html'
local pis_idx = 'file:///' .. pis_folder .. 'doc/inline-scripting.html'

local lua = (PLATFORM == "Windows" and 'c:/mathlua/bin/lua.exe') or (PLATFORM == "Mac OS X" and '/usr/local/bin/lua') or "lua"
lua = lua .. ' -i -e "mlua = require(\'mathly\'); mathlua = mlua; mathly = mlua"'
local lua_started_q = false

local interpreters = { -- file name extensions and associated interpreters
	bc   = 'bc -l -q', -- you may provide the path, e.g., 'c:/cygwin/bin/bc.exe'
	htm  = lua,
	html = lua,
	jl   = 'julia',
	lua  = lua,
	m    = 'octave',
	py   = 'python',
	r    = 'R',
	rb   = 'irb',
	sh   = 'bash',
	pl   = 'bash'
}

local function get_fname_ext(fname)
	if fname then
		local i = #fname
		while i > 0 do
			local c = fname:sub(i, i)
			if c == '\\' or c == '/' then break end
			if c == '.' then return string.lower(fname:sub(i + 1, #fname)) end
			i = i - 1
		end
	end
	return 'lua'
end

local function interpreter()
	local ext = get_fname_ext(core.active_view.doc.filename or '')
	return interpreters[ext] or lua
end

local function get_path(path)
	local i = #path
	while i > 0 do
		local c = path:sub(i, i)
		if c == '\\' or c == '/' then break end
		i = i - 1
	end
	return path:sub(1, i)
end

local function _send_code_to_term(terminal, txt)
	txt = txt:gsub('\n', '\r')
	terminal:input(txt .. "\r")
end

local function start_interpreter(x) -- x: specified interpreter or determined by filename extension
	local terminal = core.terminal_view
	if terminal == nil then
		term.class.open_terminal()
		terminal = core.terminal_view
	end
	local p = core.active_view.doc.abs_filename
	if p then _send_code_to_term(terminal, "cd '" .. get_path(p) .. "'") end
	x = x or interpreter()
	if x == lua then lua_started_q = true end
	_send_code_to_term(terminal, x)
	return terminal
end

local function get_terminal(compiler)
	return core.terminal_view or start_interpreter(compiler)
end

local function send_code_to_terminal(txt, compiler)
	if txt and #txt > 0 then
		_send_code_to_term(get_terminal(compiler), txt)
	end
end

local function is_word_char(c) -- char c is part of a word
	if c == "" then return false end
	local d = string.byte(c)
	return (d >= 97 and d <= 122) or (d >= 65 and d <= 90) or (d >= 48 and d <= 57) or d == 95 or d == 46 or d == 58 -- a~zA~Z0~9_.:
end

local function get_current_line_column()
	local doc = core.active_view.doc
	for i, r1, c1, r2, c2 in doc:get_selections(true) do
		return i, r1, c1 -- current index, line, column
	end
end

local function stop_lua()
	lua_started_q = false; send_code_to_terminal('os.exit()')
end

local function start_interpreter_if_needed(ext)
	local luaq = ext == nil or ext == ''
	if not luaq and interpreters[ext] ~= lua then
		if lua_started_q then stop_lua(); start_interpreter() end
	elseif not lua_started_q then
		start_interpreter(lua)
	end
end

command.add(nil, { -- run selected commands or current line
	["mathly:send-selection"] = function()
		local doc = core.active_view.doc
		local ext = string.lower(get_fname_ext(doc.filename or ''))
		local txt
		if doc:has_any_selection() then
			txt = doc:get_selection_text() -- doc:get_text(doc:get_selection())
		else
			local idx, r, c = get_current_line_column()
			txt = doc:get_text(r, 1, r, math.huge)
			r = r + 1
			doc:set_selections(idx, r, c, r, c) -- move to next line
		end
		start_interpreter_if_needed(ext)
		send_code_to_terminal(txt)
	end
})

local function format_url(url)
	if PLATFORM == "Windows" then
		url = string.format('"%s" %s', browser, url)
	else
		url = string.format('%s %s', browser, url)
	end
	return url
end

command.add(nil, { -- run current script file
	["mathly:send-all"] = function()
		local doc = core.active_view.doc
		local ext = string.lower(get_fname_ext(doc.filename or ''))
		if ext == 'htm' or ext == 'html' then
			local url = doc.abs_filename
			url = url:gsub('\\', '/')
			url = url:gsub(' ', '%%20')
			url = url:gsub('&', '%%26')
			system.exec(format_url('file:///' .. url))
		else
			start_interpreter_if_needed(ext)
			if doc.abs_filename and doc:is_dirty() then doc:save(doc.abs_filename) end -- modified
			local s
			if doc.abs_filename and (ext == 'lua' or ext == 'pl' or ext == 'sh') then
				if ext == 'pl' or ext == 'sh' then
					if lua_started_q then stop_lua(); start_interpreter('bash') end
					s = 'sh'
					if ext == 'pl' then s = perl .. ' -w' end
					s = s .. ' "' .. doc.abs_filename .. '"\r'
				else
					s = 'dofile("' .. doc.abs_filename .. '")\r'
				end
				s = s:gsub('\\', '/') -- for Windows
			else
				s = doc:get_text(1, 1, math.huge, math.huge)
			end
			send_code_to_terminal(s)
		end
	end
})

local function _get_current_word(txt, col) -- txt line @ column c
	local w = ''
	for i = col, 1, -1 do
		local c = txt:sub(i, i)
		if not is_word_char(c) then break end
		w = c .. w
	end
	for i = col + 1, #txt do
		local c = txt:sub(i, i)
		if not is_word_char(c) then break end
		w = w .. c
	end
	return w
end

local function get_current_word()
	local doc = core.active_view.doc
	local idx, r, c = get_current_line_column()
	local w = _get_current_word(doc:get_text(r, 1, r, math.huge), c)
	if w:match("^%d*$") then w = '' end -- a number
	return w
end

command.add(nil, { -- open help on current function/keyword
	["mathly:send-lua-help"] = function()
		local w = get_current_word()
		if not lua_started_q then start_interpreter(lua) end
		send_code_to_terminal("help('" .. w .. "')")
	end
})

command.add(nil, {
	["mathly:start-interpreter"] = start_interpreter
})

command.add(nil, {
	["mathly:insert-mathly-plot-template"] = function ()
		local doc = core.active_view.doc
		local template = [[-- axissquare()    -- axisnotsquare()    -- invalid for a grid of subplots
-- showaxes()      -- shownotaxes()      --
-- showxaxis()     -- shownotxaxis()     --
-- showyaxis()     -- shownotyaxis()     --
-- showgridlines() -- shownotgridlines() --
-- showlegend()    -- shownotlegend()
options = {
	-- xrange = {-5, 5},
	-- yrange = {-5, 5},
	-- names = {'name_of_first_graph', ...}, -- run first: showlegend()
	-- layout = {
		-- width = 600, height = 450, -- default setting
		-- title = "Example",
		-- xaxis = {title = "Your x label"}, yaxis = {title = "Your y label"},
		-- grid = {
		--   rows = 2, columns = 3,
		--   xranges = {{-5, 5}, nil,     {0, 5}, ...},
		--   yranges = {{0, 10}, {-1, 2}, nil,    ...}
		-- },
		-- gridaxes = {
		--   xaxis  = {title = "x label 1"}, yaxis  = {title = "y label 1"},
		--   xaxis2 = {title = "x label 2"}, yaxis2 = {title = "y label 2"},
		--   -- xaxis3, yaxis3 ...
		-- },
		-- margin = {l = 10, r = 40, t = 40, b = 40, pad = 10},
		-- autosize = false
	-- }
}
plot(data_functions_and_styles, options)
]]
		if doc then doc:text_input(template) end
	end
})

local translate = require "core.doc.translate"
local dv = require "core.docview"

local function change_case(f)
	local doc = core.active_view.doc
	local nosel = false
	if not doc:has_any_selection() then
		for idx, line1, _, line2 in doc:get_selections(true) do
			if line2 >= #doc.lines then
				doc:insert(line2, math.huge, "\n")
			end
			doc:set_selections(idx, line1, 1, line2 + 1, 1)
		end
		nosel = true
	end
	doc:replace(f)
	if nosel then doc:move_to(dv.translate["next_line"], core.active_view) end
end

command.add(nil, {
	["mathly:upper-case"] = function() change_case(string.uupper) end
})

command.add(nil, {
	["mathly:lower-case"] = function() change_case(string.ulower) end
})

-------------- for Perl Inline Scripting --------------
command.add(nil, {
	["mathly:insert-pis-template"] = function()
		local doc = core.active_view.doc
		local template = [[# Global variables you can use:
# $__x, $__y, $__z, $__count, @__x, @__y, @__z, %__x, %__y, %__z -  for any purpose
# $__fname - name of file/directory being processed
# $__pname - full path to $__fname, i.e., $__path/$__fname
# $__path - path to directory where the processed file/directory appears
# $__file - name of current file which hosts inline script
# $__skip_this_dir - set it to 1 to skip the directory being processed

# FILE - handle of file being processed (STDOUT and STDERR are available)
<?perl
		# __FILE_EXTS txt, ini; # set suffice of files to be processed (* matches all)
		# __INCLUDE_SUB_DIRS;   # process files under sub-directories
		# __OVERWRITE_FILE;     # OVERWRITE text files. In this case,
						                #   1) print[f] argv1,argv2,... will output to file
						                #   2) print[f](argv1,argv2,...) will output to screen
			__BACKUP_FILES;       # comment it so as not to backup original files;
		# __RESTORE_FROM_BACKUP;# restore files (ignore code except BEGIN and END)
		# __DELETE_BACKUP_FILES;# delete backup (ignore code except BEGIN and END)

		# __PROCESS_DIRS_ONLY;  # all above options but __INCLUDE_SUB_DIRS are invalid

		# BEGIN {} # executed before processing any file
		# END {}   # executed after processing all files

		# process files in specific folder other than current file's folder
		# BEGIN { $__path = 'your directory'; }

		# your code goes hereafter threaded
		# my $txt = join('', <FILE>); # treat whole text as one string
		while (<FILE>) { # process text line by line
		}
?>
]]
		if doc then doc:set_selections(1, 1, 1); doc:text_input(template) end
	end
})

local function perl_or_pis(pis)
	local doc = core.active_view.doc
	if doc then
		if lua_started_q then stop_lua() end
		local fn = doc.abs_filename
		if fn then
			send_code_to_terminal(perl .. ' -w \'' .. pis .. fn .. '\'', 'bash')
		else
			send_code_to_terminal('echo Please save current file first!', 'bash')
		end
	end
end

command.add(nil, {
	["mathly:run-pis"] = function() perl_or_pis(pis_engine .. '\' \'') end
})

command.add(nil, {
	["mathly:run-perl"] = function() perl_or_pis('') end
})

command.add(nil, { -- open help on current function/keyword
	["mathly:perl-help"] = function()
		local w, url = get_current_word(), pis_idx
		if w and w ~= '' then url = pis_url .. '#' .. w end
		system.exec(format_url(url))
	end
})

--[[ -- useless b/c Lite XL can only take a super tiny dictionary
command.add(nil, { -- open dictionary for word completion
	["mathly:open-dictionary"] = function()
		local d1, d2 = core.active_view.doc, core.open_doc(dictionary)
		core.root_view:open_doc(d2)
		core.root_view:open_doc(d1)
	end
})
]]
-------------- for Perl Inline Scripting --------------

local keymap = require "core.keymap"
keymap.add_direct {
	["f1"] = "mathly:send-lua-help",
	["f2"] = "mathly:start-interpreter",

	["ctrl+,"]       = "mathly:send-selection",
	["ctrl+."]       = "mathly:send-all",
	["shift+return"] = "mathly:send-selection", -- not a good choice while starting Firefox
	["ctrl+return"]  = "mathly:send-all",
	["ctrl+t"]       = "mathly:insert-mathly-plot-template",

	["ctrl+shift+l"] = "mathly:lower-case",
	["ctrl+shift+u"] = "mathly:upper-case",

	["ctrl+shift+r"] = "trim-whitespace:trim-trailing-whitespace",
	["ctrl+shift+a"] = "trim-whitespace:trim-empty-end-lines",

	["ctrl+0"]       = "bracket-match:move-to-matching",
	["ctrl+shift+0"] = "bracket-match:select-to-matching",

	["ctrl+shift+e"] = "find-replace:select-add-all",

	-- ["ctrl+shift+alt+d"] = "mathly:open-dictionary",
	["ctrl+shift+alt+h"] = "mathly:perl-help",
	["ctrl+shift+alt+i"] = "mathly:insert-pis-template",
	["ctrl+shift+alt+p"] = "mathly:run-perl",
	["ctrl+shift+alt+r"] = "mathly:run-pis",
}

