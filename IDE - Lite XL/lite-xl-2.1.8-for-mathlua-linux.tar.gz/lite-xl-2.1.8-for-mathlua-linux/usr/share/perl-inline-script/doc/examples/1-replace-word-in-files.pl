<?perl
    __FILE_EXTS html, htm; # search and replace files, *.html and *htm.
    __INCLUDE_SUB_DIRS;
    __OVERWRITE_FILE;

    while (<FILE>) {
        s/integrade/integrate/ig; 
        print;
    }
?>
