# This inline script displays all pairs of <A ...> and </A> which are not
# on the same line, and their line numbers.
<?perl
	my $x = 14;
    while (<FILE>) {
    	$x++;
    	if (/<a\s+name\s*=\s*(.*?)>/i) {
    		if (/<a\s+name\s*=\s*$1>.*?<\/a>/i) {
    		} else {
    			print "$x: $_";
    		}
    	}
    }
?>
You may insert the above code PLUS the first two comment lines at the head of
any HTML document, for example, /usr/share/doc/kde/HTML/en/kile/latexhelp.html.

