# convert text files in present folder into html documents
<?perl
	__FILE_EXTS txt;
	# __INCLUDE_SUB_DIRS;

    BEGIN { $__x = 0; }
	END { print "Done! ($__x files converted)"; }

    # convert each file
	$__x++;
	&HTML_output;

	# Paragraphs are separated by empty lines. First line is taken as title of a document.
	#
	# This code convert normal text file into HTML format. Using ((( and ))) can control output format.
	# They sound like <PRE> and </PRE>.
	sub HTML_output {
		my $txtfile = $__pname;
		my $htmfile = $__pname;
		$htmfile =~ s/txt$//i;
		$htmfile .= 'html';

		open FILE, "<$txtfile";
		open OUTFILE, ">$htmfile";
		my $title = <FILE>;
		chomp $title;

		print OUTFILE << "HTML";
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD><TITLE>$title</TITLE>
<META http-equiv=Content-Type content="text/html; charset=ISO-8859-1">
</HEAD>
<BODY vLink=blue aLink=blue link=blue bgColor=white leftMargin=0 topMargin=0>
<TABLE cellSpacing=0 cellPadding=5 width=754 align=center border=0>
  <TBODY>
  <TR>
    <TD style="color: navy">
      <CENTER><BR><SPAN style="font-size: 16pt; line-height: 18pt"><B>$title</B></SPAN></CENTER><P>
      <SPAN style="font-size: 12pt; line-height: 18pt; letter-spacing: normal">
HTML

		my $BRflag = 0;	# use <BR> to interpret lines within ((( and )))

		my ($line, $flag);
		$flag = 0; # indicate if a paragraph will possiblely end
		while ($line = <FILE>) {
			chomp $line;
			if ($line =~ /\s*\({3,}\s*$/) {
				$BRflag = 1;
				next;
			} elsif ($line =~ /^\s*\){3,}\s*$/) {
				$BRflag = 0;
				next;
			}

			$line =~ s/^\s+//;
			$line =~ s/\s+$//;
			$line =~ s/\s\s+/ /g;

			$line =~ s/</&lt;/g;	# forbid any HTML tag!
			$line =~ s/>/&gt;/g;
			if ($line eq '') {
				if ($flag) {
					if ($BRflag) {
						print OUTFILE "<BR>\n";
					} else {
						print OUTFILE "<P>\n\n";
					}
					$flag = 0;
				}
			} else {
				print OUTFILE "<BR>\n" if $BRflag;
				print OUTFILE "$line\n";
				$flag = 1;
			}
		}
		close FILE;

		print OUTFILE << "HTML";
      </SPAN><BR>
    </TD>
  </TR>
  </TBODY>
</TABLE>
<P></P>
</BODY></HTML>
HTML
	}
?>
