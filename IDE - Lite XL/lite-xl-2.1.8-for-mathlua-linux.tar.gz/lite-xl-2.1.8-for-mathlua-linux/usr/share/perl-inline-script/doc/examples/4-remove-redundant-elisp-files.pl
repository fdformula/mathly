# remove redundant elisp programs under /usr/.
<?perl
    __FILE_EXTS el;
    __INCLUDE_SUB_DIRS;
    BEGIN { $__path = '/usr/'; }

    if (-f "${__pname}c") {
        unlink $__pname;
    }
?>
