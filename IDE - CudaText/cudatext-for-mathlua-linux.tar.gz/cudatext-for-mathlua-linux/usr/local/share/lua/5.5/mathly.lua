--[[

LUA MODULE

	MathLua - Turning Lua into a Tiny, Free but Powerful MATLAB and More

DESCRIPTION

	With provided functions, it is much easier and faster to do math,
	especially linear algebra, and plot graphs of functions.

	Part of modules dkjson.lua, http://dkolf.de/dkjson-lua, and plotly.lua,
	https://github.com/kenloen/plotly.lua, is merged into this project
	to reduce dependecies and make it easier for users to download and use
	MathLua. Though some changes have been made, full credit belongs to
	the original authors for whom I am grateful.

FUNCTIONS PROVIDED IN THIS MODULE

	all, any, apply, cc, clc, clear, copy, cross, det, diag, diff (or diff1), diff2,
	disp, display, dot, expand, eye, factorial, ff, findroot, flatten, fliplr, flipud,
	format, fzero, hasindex, help, horzcat, integral, integral2, integral3, inv,
	isempty, iseven, isinteger, ismatrix, ismember, isodd, isvector, lagrangepoly,
	length, linsolve, linspace, lu, map, map1, match, max, mean, merge, min,
	namedargs, nchoosek, nck, newtonpoly, norm, npk, ones, polynomial, polyval,
	printf, prod, qq, qr, rand, randi, range, remake, repmat, reshape, round, rr,
	rref, save, seq, size, sleep, sort, sprintf, std, strcat, submatrix, subtable,
	sum, table1, tblcat, text, tic, toc, transpose, tt, unique, var, vectorangle,
	vertcat, who, zeros

	plus, minus, times, divide; div, mod; eq, ge, gt, le, lt

	dec2bin, dec2hex, dec2oct, bin2dec, bin2hex, bin2oct, oct2bin, oct2dec,
	oct2hex, hex2bin, hex2dec, hex2oct

	cat, isdir, isfile, iswindows, ls (or dir), mv, pwd, rm

	arc, circle, contourplot, directionfield, dotplot, line, parametriccurve2d, point,
	polarcurve, polygon, scatter, text, wedge; boxplot, freqpolygon, hist, hist1,
	histfreqpolygon, pareto, pie, slopefield, vectorfield2d ← Graphics objects passed to 'plot'.

	plot; plotparametriccurve2d, plotparametriccurve3d, plotpolarcurve; plot3d,
	plotparametricsurface, plotsphericalsurface; animate, manipulate

	axissquare, axisnotsquare; showaxes, shownotaxes; showxaxis, shownotxaxis;
	showyaxis, shownotyaxis; showgridlines, shownotgridlines;
	showlegend, shownotlegend

	See code and mathly.html.

HOME PAGE

	https://mathlua.github.io, https://github.com/fdformula/mathly

LICENSE

	Licensed under MIT license and/or the same terms as Lua itself.

	Developers:

		David Wang - original author

--]]

require 'browser-setting'

local mathly = {_TYPE='module', _NAME='mathlua', _VERSION='09.30.2026.1'}

local mathly_meta = {}

e = math.exp(1)
eps = 2.220446049250313e-16	-- machine epsilon
phi = 1.618033988749895			-- golden radio
pi = math.pi
T = 'T' -- reserved by MathLua, transpose of a matrix, A^T

function abs(x)		 return map(math.abs, x) end
function random(x) return map(math.random, x) end
function sqrt(x)	 return map(math.sqrt, x) end
function exp(x)		 return map(math.exp, x) end
function log(x)		 return map(math.log, x) end
function ceil(x)	 return map(math.ceil, x) end
function floor(x)	 return map(math.floor, x) end
function cos(x)		 return map(math.cos, x) end
function sin(x)		 return map(math.sin, x) end
function tan(x)		 return map(math.tan, x) end
function acos(x)	 return map(math.acos, x) end
function asin(x)	 return map(math.asin, x) end
function atan(x)	 return map(math.atan, x) end
function deg(x)		 return map(math.deg, x) end
function rad(x)		 return map(math.rad, x) end

function log10(x)	 return map(function(x) return math.log(x)/math.log(10) end, x) end
function sec(x)		 return map(function(x) return 1/math.cos(x) end, x) end
function csc(x)		 return map(function(x) return 1/math.sin(x) end, x) end
function cot(x)		 return map(function(x) return 1/math.tan(x) end, x) end
function acot(x)	 return map(function(x) return math.atan(1/x) end, x) end

local function _map2(f, a, d)
	if type(f) == 'string' then f = ff(f) end
	if type(a) ~= 'table' and type(d) ~= 'table' then
		return f(a, d)
	else
		local v, q
		if type(a) == 'table' then
			q = getmetatable(a) == mathly_meta or ismatrix(a)
			if type(d) == 'table' then
				local f = function(x, y) return f(x, y) end
				v = map(f, a, d)
				q = q or getmetatable(d) == mathly_meta or ismatrix(d)
			else
				local f = function(x) return f(x, d) end
				v = map(f, a)
			end
		else
			q = getmetatable(d) == mathly_meta or ismatrix(d)
			local f = function(x) return f(a, x) end
			v = map(f, d)
		end
		if q then setmetatable(v, mathly_meta) end
		return v
	end
end
function div(a, d) return _map2('@(x, y) x // y', a, d) end
function mod(a, d) return _map2('@(x, y) x % y', a, d) end
function plus(a, d) return _map2('@(x, y) x + y', a, d) end
function minus(a, d) return _map2('@(x, y) x - y', a, d) end
function times(a, d) return _map2('@(x, y) x * y', a, d) end
function divide(a, d) return _map2('@(x, y) x / y', a, d) end
-- functions like mathly.matlabvmul may be rewritten through these functions??? 9/8/26

-- eq, le, ge, lt, gt: behave like ==, <=, >=, <, > in MATLAB for matrics
-- NO meaningful ==, <=, >=, <, > on tables in Lua b/c results are "always converted to a boolean" (see: manual.html#2.4)
local function _eq_(x, y)
	local v
	if math.type(x) == 'integer' and math.type(y) == 'integer' then
		v = x == y
	else
		v = math.abs(x - y) < 100*eps
	end
	if v then return 1 else return 0 end
end
function eq(a, b) return _map2(_eq_, a, b) end
function ge(a, b) return _map2(function(x, y) if _eq_(x, y) == 1 or	x > y then return 1 else return 0 end end, a, b) end
function gt(a, b) return _map2(function(x, y) if _eq_(x, y) == 0 and x > y then return 1 else return 0 end end, a, b) end
function le(a, b) return ge(b, a) end
function lt(a, b) return gt(b, a) end

function	printf(...) io.write(string.format(table.unpack{...})) end
function sprintf(...) return string.format(table.unpack{...}) end

function demathlua(x) return setmetatable(x, nil) end -- x is no more a mathly matrix
demathly = demathlua

function eval(str, msg)
	local s, v = pcall(load, 'return ' .. str)
	if s then s, v = pcall(v) end
	if s then
		return v
	else
		if msg ~= nil then
			error(msg)
		else
			v = string.sub(v, 17)
			if #v < 12 then
				error('eval("' .. str .. '"): ' .. v)
			else
				error('["' .. v)
			end
		end
	end
end

function input(prompt, s)
	local ans
	io.write(prompt)
	ans = io.read()
	if s == 's' then
		return ans
	else
		return eval(ans)
	end
end

function iseven(x) return x % 2 == 0 end
function isodd(x)	 return x % 2 == 1 end

local function _set_matrix_meta(A, vecq)
	if type(A) ~= 'table' then return A end
	if vecq == nil then vecq = true end
	if #A == 1 then
		if vecq and type(A[1]) == 'table' then A = A[1] end
	elseif type(A[1]) == 'table' then
		for i = 1, #A do setmetatable(A[i], mathly_meta) end
	end
	if type(A) == 'table' then setmetatable(A, mathly_meta) end
	return A
end

function round(x, dplaces)
	dplaces = dplaces or 0
	local function round1(x)
		local negativeq = false
		if x < 0 then negativeq = true; x = -x end
		if dplaces == 0 then
			x = math.tointeger(math.floor(x + 0.5))
		else
			local tmp = 10 ^ dplaces
			x = math.floor(x * tmp + 0.5) / tmp
		end
		if negativeq then x = -x end
		return x
	end
	if type(x) ~= 'table' then
		return round1(x)
	else
		return _set_matrix_meta(map(round1, x))
	end
end

-- r: {start, stop[, step]}; -1 --> #x
local function _index_range(R, x)
	local r = copy(R)
	if r == nil or r == '*' then
		r = {1, #x, 1}
	elseif type(r) == 'number' then
		r = {r, r, 1}
	end
	if r[1] < 0 then r[1] = #x + r[1] + 1 end
	if r[2] < 0 then r[2] = #x + r[2] + 1 end
	if r[1] < 0 or r[2] < 0 or (#x > 0 and (r[1] > #x or r[2] > #x)) then -- #x>0 new!!!
		error('Invalid range {start, stop, step}: start or stop are out of boundary.')
	end
	if r[3] == nil then
		if r[1] < r[2] then r[3] = 1 else r[3] = -1 end
	elseif r[1] < r[2] and r[3] < 0 then
		error('Invalid range {start, stop, step}: if start < stop, step must be positive.')
	elseif #x > 0 and r[1] > r[2] and r[3] > 0 then -- #x>0, new!!!
		error('Invalid range {start, stop, step}: if start > stop, step must be negative.')
	end
	assert(isinteger(r[1]) and isinteger(r[2]) and isinteger(r[3]), 'Invalid range {start, stop, step}: start, stop, and step must be all integers.')
	return r
end

local function _mathly_matrix(A, msg)
	if getmetatable(A) ~= mathly_meta then
		if ismatrix(A) then
			setmetatable(A, mathly_meta)
		else
			error(msg .. ': A must be a matrix.')
		end
	end
end

-- rr(x):						 make x a row vector and return it
-- rr(x, i):				 return the ith row of x
-- rr(x, i, irange): return ith row on specified columns
--
-- if i is a list of indice, return rows defined in the list and in order (the latter allows rearrangement and repetition of rows)
--
-- i = -1, last row; i = -2, the row before the last row; ... similar with start and stop
function rr(x, I, irange)
	if I == nil then
		return setmetatable({flatten(x)}, mathly_meta) -- convert x to a row vector
	else
		local matrixq = type(x[1]) == 'table'
		_mathly_matrix(x, 'rr(A)')
		irange = _index_range(irange or '*', qq(matrixq, x[1], x))
		local rows = {}
		if type(I) ~= 'table' then I = { I } end
		local X = qq(matrixq, x, {x})
		for m = 1, #I do
			local i, siz = I[m], #X
			if i < 0 then i = siz + i + 1 end -- i = -1, -2, ...
			if i > 0 and i <= siz then
				local y = {}
				for j = irange[1], irange[2], irange[3] do
					y[#y + 1] = X[i][j]
				end
				rows[m] = y
			else
				error('rr(x, i...): i = ' .. tostring(i) .. ' is out of range.')
			end
		end
		return setmetatable(rows, mathly_meta)
	end
end

-- cc(x):						 make x a column vector and return it
-- cc(x, i):				 return the ith column of x
-- cc(x, i, irange): return ith column with on specified rows
--
-- if i is a list of indice, return columns defined in the list and in order (the latter allows rearrangement and repetition of columns)
-- i = -1, last columns; i = -2, the column before the last column; ...
function cc(x, I, irange)
	if I == nil then
		return setmetatable(map(function(x) return {x} end, flatten(x)), mathly_meta) -- convert x to a column vector
	else
		_mathly_matrix(x, 'cc(A)')
		irange = _index_range(irange, x)
		if type(I) ~= 'table' then I = { I } end
		local cols = mathly(math.ceil((math.abs(irange[2] - irange[1]) + 1) / math.abs(irange[3])), #I, 0)
		for jj = 1, #I do
			local j, siz = I[jj], #x[1]
			if j < 0 then j = siz + j + 1 end -- j = -1, -2, ...
			if j > 0 and j <= siz then
				local ii = 1
				for i = irange[1], irange[2], irange[3] do
					cols[ii][jj] = x[i][j]
					ii = ii + 1
				end
			else
				error('cc(x, i...): i = ' .. tostring(i) .. ' is out of range.')
			end
		end
		return setmetatable(cols, mathly_meta)
	end
end

-- convert x to a table (columnwisely if it's a mathly matrix) or flatten it first
-- and return a slice of it
-- want row wise? see flatten(t)
--
-- tt or subtable? tt converts first, while subtable doesn't.
function tt(x, irange) -- make x an ordinary table
	local y = {}
	if getmetatable(x) == mathly_meta then -- column wise
		if #x == 1 then -- row vector
			y = x[1]
		else
			if type(x[1]) == 'table' then
				for j = 1, #x[1] do
					for i = 1, #x do y[#y + 1] = x[i][j] end
				end
			else
				for i = 1, #x do y[i] = x[i] end
			end
		end
	elseif type(x) == 'table' then
		y = flatten(x)
	else
		return {x}
	end

	irange = _index_range(irange, y)
	local z = {}
	for i = irange[1], irange[2], irange[3] do
		z[#z + 1] = y[i]
	end
	return setmetatable(z, mathly_meta)
end

local function _max_min_shared(f, x) -- column wise if x is a matrix
	if type(x) == 'table' then
		if type(x[1]) == 'table' then -- a matrix
			if #x == 1 then return _max_min_shared(f, x[1]) end -- mathly{1, 2} gives {{1,2}}
			local maxs = {}
			for j = 1, #x[1] do
				local col = {}
				for i = 1, #x do col[i] = x[i][j] end
				maxs[j] = f(table.unpack(col))
			end
			if #maxs == 1 then
				return maxs[1]
			else
				return maxs
			end
		else
			return f(table.unpack(x))
		end
	else
		return x
	end
end

function max(x) return _max_min_shared(math.max, x) end
function min(x) return _max_min_shared(math.min, x) end

-- convert a MATLAB-style anonymous function in string to a function
function ff(s, mapq) -- mapq? by default, automatically apply a function to elements of a table recursively. add it for map1(...). not for users
	mapq = mapq == nil
	s = string.gsub(s, '%s+', ' ')
	local head, body = string.match(s, '^%s*@%s*(%(%s*[%w,%s]*%))%s*(.+)%s*$')
	if head ~= nil then
		local v1 = string.match(head, '^%((.-),')
		if v1 == nil then v1 = head end
		local vars = string.match(head, '^%((.*)%)')
		assert(vars ~= '' and vars ~= ' ', '@(...) needs at least 1 argument')
		if mapq then
			body = 'function' .. head .. ' local function _f' .. head .. ' return ' .. body .. ' end; if type(' .. v1 .. ') == \'table\' then return map(_f,' .. vars .. ') else return _f' .. head .. ' end end'
		else
			body = 'function' .. head .. ' return ' .. body .. ' end'
		end
		return eval(body, '"' .. s .. '": ' .. body .. ', poor expression')
	else
		error('Poor expression: ' .. s .. ". E.g., '@(x) 3*x^2 - 5*x + 1'")
	end
end
fstr2f = ff -- deprecated

-- apply a function to each group of atomic entries in tables, and the result keeps the structure of the tables
local function _map(f, ...)
	local args = {}
	for _, v in pairs{...} do
		args[#args + 1] = v
	end
	if type(args[1]) ~= 'table' then
		return f(table.unpack(args))
	else
		local y = {}
		for k, v in pairs(args[1]) do
			local arg = {}
			for j = 1,#args do
				if type(args[j]) ~= 'table' then
					arg[#arg + 1] = args[j] -- 6/5/25
				else
					arg[#arg + 1] = args[j][k]
				end
			end
			if type(v) ~= 'table' then
				y[k] = f(table.unpack(arg))
			else
				y[k] = _map(f, table.unpack(arg))
			end
		end
		return y
	end
end

function map(f, ...) -- recursive, x of f(x) is an atomic element of a table
	if type(f) == 'string' then f = ff(f) end
	local x = _map(f, ...)
	if isvector(x) or ismatrix(x) then x = _set_matrix_meta(x) end
	return x
end

function map1(f, ...) -- non-recursive, good for tables of same-type elements
	if type(f) == 'string' then f = ff(f, false) end
	local args = {}
	for _, v in pairs{...} do
		args[#args + 1] = v
	end
	local x = {}
	for k, v in pairs(args[1]) do
		local _args = {}
		for i = 1, #args do _args[i] = args[i][k] end
		x[#x + 1] = f(table.unpack(_args))
	end
	if isvector(x) or ismatrix(x) then x = _set_matrix_meta(x) end
	return x
end

-- call a function with arguments
function apply(f, args)
	if type(f) == 'string' then f = ff(f) end
	return f(table.unpack(args))
end

-- make a COPY of A, or COPY to A from B
function copy(A, rrange, crange, B, rrange1, crange1)
	local function _copy(x) -- for general purpose
		local y = {}
		for k, v in pairs(x) do
			if type(v) ~= 'table' then
				y[k] = v
			else
				y[k] = _copy(v)
			end
		end
		return y
	end

	if type(A) ~= 'table' then return A end
	if type(A[1]) ~= 'table' then crange, B, rrange1 = nil, crange, B end
	local mathlyq = getmetatable(A) == mathly_meta
	local v
	if B == nil then -- make a copy of A
		if not mathlyq and rrange == nil and crange == nil then
			v = _copy(A)
			goto endcopy
		else
			local y, I = {}, 1
			rrange = _index_range(rrange or {1, -1, 1}, A)
			if crange == nil then
				for i = rrange[1], rrange[2], rrange[3] do
					if type(A[i]) ~= 'table' then y[I] = A[i] else y[I] = _copy(A[i]) end
					I = I + 1
				end
			else
				crange = _index_range(crange, A[1])
				for i = rrange[1], rrange[2], rrange[3] do
					local J = 1
					y[I] = {}
					for j = crange[1], crange[2], crange[3] do
						y[I][J] = A[i][j]; J = J + 1
					end
					I = I + 1
				end
			end
			v = y
			goto endcopy
		end
	end

	-- copy to A from B
	rrange = _index_range(rrange, A)
	if type(A[1]) == 'table' then
		crange = _index_range(crange, A[1])
		if type(B) == 'table' then
			local b
			if getmetatable(B) ~= mathly_meta then
				if rrange[1] == rrange[2] then
					b = rr(B); crange1 = rrange1; rrange1 = {1, 1, 1}
				elseif crange[1] == crange[2] then
					b = cc(B); crange1 = {1, 1, 1}
				else
					b = mathly(B)
				end
			else
				b = B
			end
			rrange1 = _index_range(rrange1, b)
			crange1 = _index_range(crange1, b[1])
			if math.ceil((rrange[2] - rrange[1] + 1) / rrange[3]) > math.ceil((rrange1[2] - rrange1[1] + 1) / rrange1[3]) or
				 math.ceil((crange[2] - crange[1] + 1) / crange[3]) > math.ceil((crange1[2] - crange1[1] + 1) / crange1[3]) then
				error('copy(A, rrange, crange, B, rrange1, crange1): not enough data in B for the copy.')
			end
			local I, J
			I = rrange1[1]
			for i = rrange[1], rrange[2], rrange[3] do
				J = crange1[1]
				for j = crange[1], crange[2], crange[3] do
					A[i][j] = b[I][J]
					J = J + crange1[3]
				end
				I = I + rrange1[3]
			end
		else
			for i = rrange[1], rrange[2], rrange[3] do
				for j = crange[1], crange[2], crange[3] do A[i][j] = B end
			end
		end
	else -- treat A and B as a simple table: copy(A, rrange, B, rrange1)
		if type(B) == 'number' then
			for i = rrange[1], rrange[2], rrange[3] do A[i] = B end
		else
			rrange1 = _index_range(rrange1, B)
			if math.ceil((rrange[2] - rrange[1] + 1) / rrange[3]) > math.ceil((rrange1[2] - rrange1[1] + 1) / rrange1[3]) then
				error('copy(A, irange, B, irange1): not enough data in table B for the copy.')
			end
			local I = rrange1[1]
			for i = rrange[1], rrange[2], rrange[3] do
				A[i] = B[I]; I = I + rrange1[3]
			end
		end
	end
	v = A
::endcopy::
	if mathlyq or isvector(v) or ismatrix(v) then _set_matrix_meta(v, false) end
	return v
end -- copy

-- Return the same data as in t but with no repetitions.
function unique(t)
	if type(t) ~= 'table' then return t end
	local x = copy(t)
	table.sort(x)
	local y
	if #x > 0 then y = {x[1]} else return {} end
	for i = 2, #x do
		if math.abs(x[i] - x[i - 1]) > eps then -- not equal
			y[#y + 1] = x[i]
		end
	end
	return setmetatable(y, mathly_meta)
end

--// format(fmt)
-- Reset or specify the format of the output of disp(...)
-- fmt:
--	 'bank',	2 decimal places
--	 'short', 4 decimal places (default)
--	 'long', 15 decimal places
local _int_fmt		= "%12d"	 -- 'global' for disp(...)
local _float_fmt	= "%12.4f" --
local _str_fmt		= "%12s"

local _int_fmt1 	= "%d"		 -- 'global' for display(...)
local _float_fmt1 = "%.4f"	 --

local _disp_format	 = 'short'	-- 'global'
function format(fmt)
	if fmt == 'long' or fmt == 'bank' then
		_disp_format = fmt
	else
		_disp_format = 'short'
	end
end

-- x is a table or row/column vector: return 1 if all elements of the table make f(x) true.
-- x is a mathly matrix: return a row vector of 1's and 0's with each element indicating
--	 if all of the elements of the corresponding column of the matrix make f(x) true.
--
-- f(x) return true or false (default to: x ~= 0)
--
-- mathlymatrixq? usually, ignore it. if just need yes (1) or no (0), set it to false.
function all(x, f, mathlymatrixq)
	if mathlymatrixq == nil then mathlymatrixq = true end
	if f == nil then
		f = function(x) return math.abs(x) > eps end	-- x ~= 0
	elseif type(f) == 'string' then
		f = ff(f)
	end
	local function traverse(x)
		for i = 1, #x do
			if type(x[i]) == 'table' then
				if traverse(x[i]) == 0 then return 0 end
			elseif not f(x[i]) then return 0 end
		end
		return 1
	end

	if mathlymatrixq then
		if getmetatable(x) == mathly_meta then
			local m, n = size(x)
			if m > 1 and n > 1 then
				local y = zeros(1, #x[1])
				for j = 1, #x[1] do
					local i = 1
					while i <= #x do
						if not f(x[i][j]) then break end
						i = i + 1
					end
					if i > #x then y[j] = 1 end
				end
				return setmetatable(y, mathly_meta)
			end
		end
	end

	if type(x) == 'table' then
		return traverse(x)
	else
		error('all(x, f): x must be a table or mathly matrix.')
	end
end -- all

-- x is a table or row/column vector: return 1 if there is any element of the table which makes f(x) true.
-- x is a mathly matrix: return a row vector of 1's and 0's with each element indicating
--	 if there is any element of the corresponding column of the matrix which makes f(x) true.
--
-- f(x) return true or false (default to: x ~= 0)
--
-- mathlyq? usually, ignore it. if just need yes (1) or no (0), set it to false.
function any(x, f, mathlyq)
	if mathlyq == nil then mathlyq = true end
	if f == nil then
		f = function(x) return math.abs(x) > eps end	-- x ~= 0
	elseif type(f) == 'string' then
		f = ff(f)
	end
	local function traverse(x)
		for i = 1, #x do
			if type(x[i]) == 'table' then
				if traverse(x[i]) == 1 then return 1 end
			elseif f(x[i]) then return 1 end
		end
		return 0
	end

	if mathlyq then
		if getmetatable(x) == mathly_meta then
			local m, n = size(x)
			if m > 1 and n > 1 then
				local y = zeros(1, #x[1])
				for j = 1, #x[1] do
					for i = 1, #x do
						if f(x[i][j]) then y[j] = 1; break end
					end
				end
				return setmetatable(y, mathly_meta)
			end
		end
	end

	if type(x) == 'table' then
		return traverse(x)
	else
		error('any(x, f): x must be a table or mathly matrix.')
	end
end -- any

-- Return elements of A that satisfy specified conditions. (f defaults to A).
--
-- If f is a boolean function, return 1) a table of elements of A (rowwisely) that satisfy
--	 f(x) and 2) a table of elements of A with those elements replaced by 0 when
--	 they fail to satisfy f(x).
--
-- If f is a table/matrix, return 1) a table of elements of A (rowwisely) that correspond
-- to nonzero elements of f and 2) A with entries replaced with corresponding zero elements of f.
--
-- note: 'select' seems to be a better name. however, Lua already uses it.
function match(A, f)
	if type(A) ~= 'table' then error('match(A, ...): A must be a table.') end
	if type(f) == 'string' then f = ff(f) end
	local B
	local abs = math.abs
	if f == nil then
		B = A
	elseif type(f) == 'function' then
		B = map(function(x) if f(x) then return x else return 0 end end, A)
	elseif type(f) == 'table' then
		B = map(function(x, y) if abs(x) > 10*eps then return y else return 0 end end, f, A)
	else
		error('match(A, f): f must be a boolean function or a table.')
	end

	local X, k = {}, 1
	map(function(x, y) if abs(x) > 10*eps then X[k] = y; k = k + 1 end end, B, A)
	return X, B
end

local function _dec2bho(x, title, f)
	if isinteger(x) then
		return f(x)
	elseif type(x) == 'table' then
		return map(f, x)
	else
		error(title .. '(x): x must be an integer or a table of integers.')
	end
end

--// calculate the (64-bit) binary expansion of signed decimal integer x
function dec2bin(x)
	local function _dec2bin(x)
		local s = ''
		while x ~= 0 do
			s = (x & 1) .. s
			x = x >> 1
		end
		if s == '' then s = '0' end
		return s
	end
	return _dec2bho(x, 'dec2bin', _dec2bin)
end

--// calculate the hexadecimal expansion of signed decimal integer x
function dec2hex(x) return _dec2bho(x, 'dec2hex', function(x) return sprintf('%x', x) end) end

--// calculate the octal expansion of signed decimal integer x
function dec2oct(x) return _dec2bho(x, 'dec2oct', function(x) return sprintf('%o', x) end) end

--// convert unsigned binary/octal/hexadecimal integer x to decimal integer
local function _bho2dec(x, title, base)
	local function __bho2dec(x)
		local val = 0
		x = string.lower(x) -- unnecessary in Lua 5.4.6
		for i = 1, #x do
			local v = string.sub(x, i, i)
			if v >= '0' and v <= '9' then
				v = string.byte(v) - string.byte('0')
				if base == 2 and v > 1 then
					error(x .. ': invalid binary number.')
				elseif base == 8 and v > 7 then
					error(x .. ': invalid octal number.')
				end
			elseif base == 16 then
				if v >= 'a' and v <= 'f' then
					v = string.byte(v) - string.byte('a') + 10
				else
					error(x .. ': invalid hexadecimal number.')
				end
			else
				error(x .. ': invalid number.')
			end
			val = val * base + v -- Lua 5.4.6, 1 + '67' = 68
		end
		return val
	end

	if type(x) == 'string' then
		return __bho2dec(x)
	elseif type(x) == 'table' then
		return map(__bho2dec, x)
	else
		error(title .. '(x): x must be a string or a table of strings.')
	end
end -- _bho2dec

function bin2dec(x) return _bho2dec(x, 'bin2dec', 2) end
function oct2dec(x) return _bho2dec(x, 'oct2dec', 8) end
function hex2dec(x) return _bho2dec(x, 'hex2dec', 16) end

function bin2oct(x) return dec2oct(bin2dec(x)) end
function bin2hex(x) return dec2hex(bin2dec(x)) end
function oct2bin(x) return dec2bin(oct2dec(x)) end
function oct2hex(x) return dec2hex(oct2dec(x)) end
function hex2bin(x) return dec2bin(hex2dec(x)) end
function hex2oct(x) return dec2oct(hex2dec(x)) end

--// calculate the greatest common divisor
function gcd(x, y)
	local function __gcd(x, y) -- euclidean algorithm
		while y ~= 0 do
			x, y = y, x % y
		end
		return x
	end
	local function _gcd(x, y)
		assert(isinteger(x) and x >= 0 and isinteger(y) and y >= 0,
					 'gcd(x, y): x and y must be nonnegative integers.')
		if x < y then x, y = y, x end
		return __gcd(x, y)
	end
	if type(x) == 'number' then
		return _gcd(x, y)
	elseif type(x) == 'table' then
		return map(_gcd, x, y)
	else
		error('gcd(x, y): x and y must be nonnegative integers or tables of nonnegative integers with the same structure.')
	end
end

--// calculate b^n mod m
function powermod(b, n, m)
	assert(isinteger(b) and b >= 0 and
				 isinteger(n) and n >= 0 and
				 isinteger(m) and m > 0,
				 'powermod(b, n, m): b, n, and m must be nonnegative integers with m > 0.')
	if b == 0 or m == 1 then return 0 end
	local x, p = 1, b % m
	local a = dec2bin(n) --	binary modular exponentiation
	for i = #a, 1, -1 do
		if string.sub(a, i, i) == '1' then x = (x * p) % m end
		p = (p * p) % m
	end
	return x
end

-- find largest width of integers/strings and if all are integer
local function _largest_width_dplaces(t)
	if type(t) ~= 'table' then t = {t} end
	local allintq, width, fwidth, slen, sign, w, fw, s, tmp, sgn, x = true, 0, 0, 0, 0, 0, 0, 0
	for _, v in pairs(t) do
		if type(v) == 'table' then
			w, fw, tmp, s, sgn = _largest_width_dplaces(v)
			if allintq then allintq = tmp end
			if sgn == 1 then sign = 1 end
		elseif type(v) == 'string' then
			s, x = string.gsub(v, '"', '\\"')
			s = #v + 2 + x
		elseif type(v) == 'boolean' then
			s = qq(v, 4, 5)
		else
			x = v
			if x < 0 then sign = 1; x = -x end
			if math.type(x) == 'integer' then
				w = #tostring(x)
			else
				fw = #tostring(math.floor(x))
				allintq = false
			end
		end
		if w > width then width = w end
		if s > slen then slen = s end
		if fw > fwidth then fwidth = fw end
	end
	return width, fwidth, allintq, slen, sign
end

local function _set_disp_format(t)
	local dplaces = qq(_disp_format == 'long', 13, qq(_disp_format == 'bank', 2, 4))
	local iwidth, fwidth, allintq, slen, sign = _largest_width_dplaces(t)
	local fmt = string.format
	local w = math.max(iwidth + sign, slen)
	if not allintq then w = math.max(w, fwidth + dplaces + 1 + sign) end
	_float_fmt	= fmt('%%%d.%df', w, dplaces)
	_float_fmt1 = fmt('%%.%df', dplaces)
	_int_fmt = fmt('%%%dd', w)
	_str_fmt = fmt('%%%ds', w)
	_int_fmt1 = '%d'
end

local function _disp_str(s) return '\"' .. string.gsub(s, '"', '\\"') .. '\"' end

local function _tostring(x)
	if isinteger(x) then
		return string.format(_int_fmt, x)
	elseif type(x) == 'string' then
		return string.format(_str_fmt, _disp_str(x))
	elseif type(x) == 'number' then
		return string.format(_float_fmt, x)
	else
		return string.format(_str_fmt, tostring(x))
	end
end

-- list all user defined variables (some may be defined by some loaded modules)
-- if a list of variables are needed by other code, pass false to it: who(false)
function who(userq) -- R
	if userq == nil then userq = true end
	local list = {}
	for k,v in pairs(_G) do
		if type(v) ~= 'function' then
			if not ismember(k,
				{'e', 'eps', 'pi', 'phi', 'T', 'mathlua', 'mathly', 'mlua', '_G', 'coroutine', 'utf8',
				 '_VERSION', 'io', 'package', 'os', 'arg', 'debug', 'string', 'table', 'math',
				 'linux_browser', 'mac_browser', 'win_browser', 'doc_folder', 'plotly_engine',
				 'tmp_plot_html_file'}) then
				list[#list + 1] = k
			end
		end
	end
	if userq then -- print the list
		if #list >= 1 then io.write(list[1]) end
		for i = 2, #list do
			io.write(', ', list[i])
		end
		io.write('\n')
	else
		return list
	end
end

local function _trim_2tail_spaces(x)
	return string.match(_tostring(x), "^%s*(.+)%s*$")
end

local function _disp(t, ind, col, strq, niceq, sav) -- strq: return a string version? niceq: pretty print?
	if col == -1 or not niceq then col = -1; _str_fmt = '%s' end
	local keys, n, newlined, str = {}, col, false, ''
	local function proc(s) if strq then str = str .. s else io.write(s) end end
	local align = function() if niceq then proc(string.rep(" ", ind + 2)) end end
	local newline = function()
		if niceq and not newlined then proc('\n'); newlined = true; align() end
		n = col
	end

	for k in pairs(t) do table.insert(keys, k) end
	table.sort(keys, function(a, b)
		if type(a) == type(b) then return a < b end
		return tostring(a) < tostring(b)
	end)

	proc("{"); if niceq then proc("\n") end
	for _, k in ipairs(keys) do
		local v, tq, fieldq = t[k], false, type(k) == 'string'
		if n == 0 then newline() end
		if fieldq then
			if not newlined then
				if k ~= keys[1] then newline() else align() end
			end
			proc(k .. " = ")
		end
		if type(v) == "table" then
			if not fieldq then
				if k ~= keys[1] then newline() end
				if not newlined then align() end
			end
			proc(_disp(v, ind + 2, col, strq, niceq))
			tq = true
		else
			if not fieldq and k == keys[1] and not newlined then align() end
			local s = _tostring(v)
			if type(v) == 'number' then
				if v == math.huge or v == -math.huge then
					local w = qq(v == math.huge, '', '-')
					if sav then w = w .. qq(sav == ".m", "Inf", "math.huge") else w = w .. "inf" end
					s = sprintf(_str_fmt, w)
				elseif col < 0 or fieldq then
					s = string.match(s, "[%d%.%+%-]+")
				end
			end
			proc(s)
		end
		if k ~= keys[#keys] then proc(", ") end
		newlined = false
		n = n - 1
		if tq or fieldq then
			if not fieldq and k ~= keys[#keys] then newline(); end
			n = col
		end
	end
	if niceq then proc("\n" .. string.rep(" ", ind) .. "}") else proc("}") end
	return qq(strq, str, "")
end -- _disp

-- print a table with its structure while disp(x) prints a matrix
local _disp_col, _disp_flat = -1, nil
function display(t, col, flat, strq, sav) -- strq: return a string version? not for users
	if col and type(col) ~= 'number' then flat = col; col = -1 end
	if strq then
		col, flat = _disp_col, _disp_flat
	else
		_disp_col, _disp_flat = col, flat
	end

	local s
	if t == nil then
		s = 'nil'
	else
		_set_disp_format(t)
		if flat or (col and type(col) ~= 'number') then flat = true end
		if type(t) == 'table' then
			s = _disp(t, 0, col or -1, strq, flat == nil, sav)
		elseif type(t) == 'string' then
			s = _disp_str(t)
		elseif type(t) == 'number' then
			s = _trim_2tail_spaces(t)
		else
			s = tostring(t)
		end
	end
	if strq then return s else io.write(s); return "" end
end

-- print a mathly matrix while display(x) prints a table with its structure
function disp(A, flat)
	if flat == nil and getmetatable(A) == mathly_meta then
		io.write(mathly.tostring(A))
	elseif type(flat) == 'number' then
		display(A, flat)
	else
		display(A, -1, '')
	end
	print()
end

-- return string version of a variable x starting with 'x = '
local function _vartostring_lua(x, sav)
	local v = eval(x)
	if sav == '.m' and type(v) == 'table' and not (type(v) == mathly_meta or ismatrix(v)) then v = flatten(v) end
	return x .. ' = ' .. display(v, _disp_col, _disp_flat, true, sav) .. '\n\n'
end

-- return true if x is a row/column vector of two or more numbers
function isvector(x)
	if type(x) ~= 'table' or #x < 2 then return false end
	for k, v in pairs(x) do
		if type(k) ~= 'number' then return false end -- {1, 2, size = 5, ...}
	end
	if type(x[1]) == 'number' then -- {1, 2, ...}
		for i = 2, #x do
			if type(x[i]) ~= 'number' then return false end
		end
		return true
	elseif type(x[1]) == 'table' and #x[1] == 1 and type(x[1][1]) == 'number' then -- {{1}, {2}, ...}
		for i = 2, #x do
			if type(x[i]) ~= 'table' or #x[i] ~= 1 or type(x[i][1]) ~= 'number' then return false end
		end
		return true
	end
	return false
end

-- test if x is a matrix simply by type(x) == 'table' and type(x[1]) == 'table'
-- ismatrix(x) is time consuming but usually not necessary
function ismatrix(x)
	if type(x) ~= 'table' or type(x[1]) ~= 'table' then return false end
	local n = #x[1]
	for i = 1, #x do
		if type(x[i]) ~= 'table' or #x[i] ~= n then return false end
		for j = 1, #x[i] do
			if type(x[i][j]) ~= 'number' then return false end
		end
	end
	return true
end

-- generate the string version of MATLAB variable y starting with 'y ='
local function _vartostring_matlab(x, sav)
	local col, flat = _disp_col, _disp_flat
	_disp_col, _disp_flat = -1, true
	local s = _vartostring_lua(x, sav)
	x = load('return ' .. x)()
	if getmetatable(x) == mathly_meta or ismatrix(x) then
		s = string.gsub(s, "}, {", ";\n")
	end
	s = string.gsub(s, "}+", "]")
	s = string.gsub(s, "{+", "[")
	_disp_col, _disp_flat = col, flat
	return s
end

-- save variables and their values to a Lua or MATLAB script file
function save(fname, ...)
	local vars = {}
	for _, v in pairs{...} do
		if type(v) == 'table' then
			for i = 1, #v do vars[#vars + 1] = v[i] end
		else
			vars[#vars + 1] = v
		end
	end
	if #vars == 0 then vars = sort(who(false)) end

	local matlabq = string.lower(string.sub(fname, #fname - 1)) == '.m'
	local file = io.open(fname, "w")
	if file ~= nil then
		local stamp = ' MathLua saved on ' .. os.date() .. '\n\n'
		if not matlabq then
			file:write('--' .. stamp .. "mathly = require('mathly')\n\n")
		else
			file:write('%' .. stamp)
		end
		local sav = qq(matlabq, ".m", ".lua")
		for i = 1, #vars do
			local x = load('return ' .. vars[i])()
			if x == nil then
				print(vars[i] .. ' is undefined.')
			else
				if matlabq then
					file:write(_vartostring_matlab(vars[i], sav))
				else
					file:write(_vartostring_lua(vars[i], sav))
					if getmetatable(x) == mathly_meta then
						file:write(vars[i] .. ' = mathly(' .. vars[i] .. ')\n\n')
					end
				end
			end
		end
		file:close()
	else
		error(string.format("Failed to create %s. The device might not be writable.", fname))
	end
end -- save

-- clear LUA console
function clc()
	local x = os.execute("cls") or os.execute('clear')
end

-- Ternary "operator" ~ C/C++ ? :
function qq(c, t, f) return (c and t) or f end -- if c then return t else return f end

local __is_windows = package.config:sub(1,1) == '\\'
function iswindows() return __is_windows end

--↓↓↓↓↓↓ basic file system commands ↓↓↓↓↓↓--
function pwd() return os.getenv("PWD") or io.popen("cd"):read() end

function isfile(fname)
	if __is_windows then
		local cmd1 = 'dir "' .. fname .. '" > nul 2>&1'
		local cmd2 = 'dir /A:D "' .. fname .. '" > nul 2>&1'
		return os.execute(cmd1) ~= nil and os.execute(cmd2) == nil
	else
		return os.execute('test -f "' .. fname .. '" > /dev/null') ~= nil
	end
end

function isdir(fname)
	local cmd
	if __is_windows then
		cmd = 'dir /A:D "' .. fname .. '" > nul 2>&1'
	else
		cmd = 'test -d "' .. fname .. '" > /dev/null 2>/dev/null'
	end
	return os.execute(cmd) ~= nil
end

-- allow characters ? and * in file names
function ls(path, re, printq)
	local files, folders = {}, {}
	if path == nil then
		path = pwd()
		if re == nil then re = '*' end
	elseif path:match('[%?|%*]') == nil and isdir(path) then
		if re == nil then re = '*' end
	end
	if printq == nil then printq = true end
	local sep = qq(iswindows(), '\\', '/')
	local rootq = path:sub(1, 1) == sep

	if re == nil then
		re = ''
		local path1 = ''
		for x in path:gmatch('([^' .. sep .. ']+)') do
			if path1 == '' then
				path1 = re
			else
				path1 = path1 .. sep .. re
			end
			re = x
		end
		if path1 == '' then path = pwd() else path = path1 end
		if rootq and not __is_windows then path = sep .. path end
	end
	re = re:gsub('%.', '%%.')
	re = re:gsub('%?', '.')
	re = re:gsub('%*', '.*')
	re = '^' .. re

	local lst = io.popen(qq(__is_windows, "dir /b ", "ls -pa ") .. '"'.. path .. '"'):lines()
	if lst ~= nil then
		for f in lst do
			if f == './' or f == '../' then -- linux
			elseif isdir(path .. sep .. f) then
				folders[#folders + 1] = f
			elseif f:match('^%.+/$') == nil and f:match(re) ~= nil then
				files[#files + 1] = f
			end
		end
	end
	if printq then
		for i = 1, #files do print('   ' .. files[i]) end
	end
	return files, path, folders
end
dir = ls

function cat(file)
	local f = io.open(file, "r")
	if f ~= nil then
		io.close(f)
		for x in io.lines(file) do print(x) end
	else
		print("File not found.")
	end
end

-- function cd(path) -- doesn't work
mv = os.rename
rm = os.remove
--↑↑↑↑↑↑ basic file system commands ↑↑↑↑↑↑--

-- clear user-defined variables
function clear()
	local vars = who(false)
	for i = 1, #vars do
		load(string.format("%s = nil", vars[i]))()
	end
	if _ ~= nil then _ = nil end
	axisnotsquare()
	showaxes()
	showgridlines()
	shownotlegend()
end

-- generates an evenly spaced sequence/table of 'len' numbers on the interval [from, to].
function linspace(from, to, len)
	assert(from ~= to, 'linspace(from, to, len): FROM can\'t equal to TO.')
	len = len or 100
	assert(len > 2, "linspace(from, to, len): len must be greater than 2.")
	local lst, step, i = {}, (to - from) / (len - 1), 1
	if from > to then from, to = to, from end
	while i <= len do
		lst[i] = from
		from = from + step
		i = i + 1
	end
	return setmetatable(lst, mathly_meta)
end

-- calculates the product of all elements of a table
-- calculates the product of all elements of each column in a matrix
function prod(x)
	if type(x) == 'number' then
		return x
	elseif type(x) == 'table' then
		if type(x[1]) == 'table' then -- a "matrix"
			local prods = {}	-- column wise
			for j = 1,#x[1] do
				prods[j] = 1
				for i = 1,#x do prods[j] = prods[j] * x[i][j] end
			end
			return setmetatable(prods, mathly_meta)
		else
			local s = 1
			for i = 1,#x do s = s * x[i] end
			return s
		end
	else
		return 0
	end
end

-- calculates the sum of all elements of a table
-- calculates the sum of all elements of each column in a matrix
function sum(x)
	if type(x) == 'number' then
		return x
	elseif type(x) == 'table' then
		if type(x[1]) == 'table' then -- a "matrix"
			if #x == 1 then -- {{1, 2, ...}} b/c mathly{1, 2, 3} gives {{1, 2, 3}}
				 return sum(x[1])
			end
			local s = {}	-- column wise
			for j = 1,#x[1] do
				s[j] = 0
				for i = 1,#x do s[j] = s[j] + x[i][j] end
			end
			if #s == 1 then
				return s[1]
			else
				return setmetatable(s, mathly_meta)
			end
		else
			local s = 0
			for i = 1,#x do s = s + x[i] end
			return s
		end
	else
		return 0
	end
end

-- // function strcat(s1, s2, ...)
function strcat(...)
	local s = ''
	for _, v in pairs{...} do
		if type(v) == 'string' then
			s = s .. v
		elseif type(v) == 'number' then
			s = s .. string.char(v)
		elseif type(v) == 'table' then
			s = s .. strcat(table.unpack(v))
		end
	end
	return s
end

function factorial(n)
	assert(isinteger(n) and n >= 0, 'factorial(n): n must be a nonnegative integer')
	local v = 1.0
	for i = 2, n do v = v * i end
	if v < math.maxinteger then v = math.floor(v + 0.5) end
	return v
end

function nchoosek(n, k, permq) -- combination & permutation
	assert(isinteger(n) and isinteger(k) and n >= k, 'nchoosek(n, k, ...): n and k must be nonnegative integers with n >= k')
	local v = 1.0
	if permq ~= nil then
		for i = n - k + 1, n do v = v * i end
	else
		local m = n - k
		if m < k then m, k = k, m end
		for i = m + 1, n do v = v * i end
		v = v / factorial(k)
	end
	if v < math.maxinteger then v = math.floor(v + 0.5) end
	return v
end
nck = nchoosek
function npk(n, k) return nchoosek(n, k, 1) end

-- calculates the mean of all elements of a table
-- calculates the mean of all elements of each column in a matrix
function mean(x)
	if type(x) == 'number' then
		return x
	elseif type(x) == 'string' then
		return mean(table.pack(string.byte(x, 1, #x)))
	elseif type(x) == 'table' then
		if type(x[1]) == 'number' then
			local s = 0
			for i = 1, #x do s = s + x[i] end
			return s / #x
		elseif type(x[1]) == 'string' then
			return mean(strcat(table.unpack(x)))
		else
			_mathly_matrix(x, 'mean(A)')
			local m, n = size(x)
			if m == 1 then
				return mean(x[1])
			elseif n == 1 then
				return mean(flatten(x))
			end

			local means = {}	-- column wise
			for j = 1, n do
				means[j] = 0
				for i = 1, m do means[j] = means[j] + x[i][j] end
				means[j] = means[j] / #x
			end
			return setmetatable(means, mathly_meta)
		end
	end
end

local function _stdvar(x, opt, sqrtq)
	opt = opt or 0
	if type(x) == 'number' then
		return 0
	elseif type(x) == 'table' then
		if type(x[1]) == 'number' then
			local avg = mean(x)
			local s = sum((rr(x) - avg) ^ 2)
			if opt == 0 then
				s = s / (#x - 1)
			else
				s = s / #x
			end
			if sqrtq then s = math.sqrt(s) end
			return s
		else -- a "matrix"
			_mathly_matrix(x, 'std(A)')
			local m, n = size(x)
			if m == 1 then
				return _stdvar(x[1], opt, sqrtq)
			elseif n == 1 then
				return _stdvar(flatten(x), opt, sqrtq)
			end

			local s = {}	--	column wise
			for j = 1, n do
				local avg = mean(copy(x, '*', j))
				s[j] = 0
				for i = 1, m do
					s[j] = s[j] + (x[i][j] - avg)^2
				end
				if opt == 0 then
					s[j] = s[j] / (m - 1)
				else
					s[j] = s[j] / m
				end
				if sqrtq then s[j] = math.sqrt(s[j]) end
			end
			return setmetatable(s, mathly_meta)
		end
	else
		error('std(x): x must be a table or matrix of numbers.')
	end
end -- _stdvar

-- calculates the standard deviation (or variance) of all elements of a table or
-- each column of a matrix
--
-- if opt = 0 (default), find the standard deviation (or variance) of a population
-- otherwise, find that of a sample
function std(x, opt) return _stdvar(x, opt, true) end
function var(x, opt) return _stdvar(x, opt, false) end

-- calculate the dot/inner product of two vectors
function dot(a, b)
	local t1, t2 = flatten(a), flatten(b)
	assert(#t1 == #t2, 'dot(a, b): a and b must be vectors of same size.')
	return sum(t1 * t2)
end

-- calculate the cross product of two vectors
function cross(a, b)
	local t1, t2 = flatten(a), flatten(b)
	assert(#t1 == 3 and #t2 ==3, 'cross(a, b): a and b must be 3D vectors.')
	return setmetatable({a[2] * b[3] - a[3] * b[2], a[3] * b[1] - a[1] * b[3], a[1] * b[2] - a[2] * b[1]}, mathly_meta)
end

-- calculate the angle between two vectors
function vectorangle(a, b)
	local t1, t2 = flatten(a), flatten(b)
	assert(#t1 == #t2, 'vectorangle(a, b): a and b must be vectors of same size.')
	local x = acos(dot(t1, t2) / (norm(t1) * norm(t2)))
	return x, '(' .. tostring(deg(x)) .. ' degree)'
end

-- generate an evenly spaced sequence/table of numbers starting at 'start' and likely ending at 'stop' by 'step'.
function range(start, stop, step) -- Python, but inclusive
	assert(start ~= nil, 'range(start, stop, step): no input.')
	if stop == nil then
		stop = start
		if start > 0 then start = 1 else start = -1 end
	end
	if step == nil then
		if start < stop then step = 1 else step = -1 end
	end
	local msg = "range(" .. start .. ", " .. stop .. ", step): step must be "
	if start < stop and step < 0 then
		error(msg .. "positive")
	elseif start > stop and step > 0 then
		error(msg .. "negative")
	end

	local v, k = {}, 1
	if step > 0 then
		while start <= stop + 100*eps do
			v[k] = start; k = k +1
			start = start + step
		end
	else
		while start >= stop - 100*eps do
			v[k] = start; k = k +1
			start = start + step
		end
	end
	return setmetatable(v, mathly_meta)
end -- range
seq = range -- R

--// find and return the zero/root of function f on specified interval
function fzero(f, intv, tol) -- matlab
	if type(f) == 'string' then f = ff(f) end
	if type(intv) == 'number' then intv = {intv - 1, intv + 1} end
	if type(f) ~= 'function' or type(intv) ~= 'table' then
		error('fzero(f, interval): f must be a function, and interval must be specified.')
	end

	local a, b = intv[1], intv[2]
	if b < a then a, b = b, a end
	local fa = f(a)
	if fa * f(b) > 0 then
		error('fzero(f, {a, b} ...): f(x) must have different signs at x=a and x=b.')
	end

	tol = tol or eps
	if tol < 0 then tol = -tol end
	local mid, fmid
	repeat
		mid = (a + b) / 2; fmid = f(mid)
		if fa * fmid > 0 then
			a = mid; fa = fmid
		else
			b = mid
		end
	until math.abs(fmid) < eps or b - a < tol
	return mid
end

function findroot(f, i, t) return fzero(f, i, t) end -- mathematica

--// for lagrangepoly, newtonpoly, polynomial, and scatter(...)
local function _poly_input(data) -- {{x1, y1}, {x2, y2}, ...}
	local x, y = {}, {}
	if type(data) == 'table' and type(data[1]) == 'table' then
		for i = 1, #data do
			x[i], y[i] = data[i][1], data[i][2]
		end
	end
	return x, y
end

--// lagrangepoly(x, y, xx)
-- return the Lagrange function or the value(s) of the Lagrange function defined by data x and y, tables of numbers
--
-- if xx is provided, return the value(s) of the Lagrange polynomial for data (x, y)'s
-- otherwise, return the string of the Lagrange polynomial for data (x, y)'s, e.g, 'function f(x) return -3*(x - 2) + 4*(x - 1) end'
function lagrangepoly(x, y, xx)
	local X, Y = _poly_input(x)
	if #X ~= 0 then xx = y; x, y = X, Y end
	assert(type(x) == 'table' and type(y) == 'table' and #x == #y, 'lagrangepoly(x, y ...): x and y must be tables of the same size.')
	local coefs, k, abs = {}, 1, math.abs
	for i = 1, #x do
		local tmp = y[i]
		if abs(tmp) > 10*eps then -- tmp ~= 0
			for j = 1, #x do
				if j ~= i then tmp = tmp / (x[i] - x[j]) end
			end
		else
			tmp = 0
		end
		coefs[k] = tmp; k = k + 1
	end

	local s, non1stq = '', false
	for i = 1, #x do
		if coefs[i] ~= 0 then
			local op, coef = ' + ', coefs[i]
			if abs(coef) > 10*eps then
				 if coef < 0 then
					if non1stq then s = s .. ' - ' else s = s .. ' -' end
					coef = -coef
				else
					if non1stq then s = s .. ' + ' end
				end
				if abs(coef - 1) > 10*eps then s = s .. tostring(coef) .. '*' end
				non1stq = true
				local firstq = true
				for j = 1, #x do
					if j ~= i then
						if not firstq then s = s .. '*' end
						if abs(x[j]) > 10*eps then
							if x[j] > 0 then
								s = s .. '(x - ' .. tostring(x[j]) .. ')'
							else
								s = s .. '(x + ' .. tostring(-x[j]) .. ')'
							end
						else
							s = s .. 'x'
						end
						firstq = false
					end
				end
			end
		end
	end
	if xx == nil then return s end
	return _set_matrix_meta(map(ff('@(x) ' .. s), xx))
end -- lagrangepoly

-- if xx is provided, return the value(s) of the Newton interpolating polynomial for data (x, y)'s;
-- otherwise, return the polynomial, e.g, 'function f(x) return -3*(x - 1) + 4*(x - 1)*(x-2) end'
function newtonpoly(x, y, xx)
	local X, Y = _poly_input(x)
	if #X ~= 0 then xx = y; x, y = X, Y end
	assert(type(x) == 'table' and type(y) == 'table' and #x == #y, 'newtonpoly(x, y ...): x and y must be tables of the same size.')

	local n = length(x)
	local a = zeros(1, n)
	-- calculate coefs a(i) as in a1 + a2(x -x1) + a3(x-x1)(x-x2) + ... + an(x-x1)...
	a[1] = y[1]
	local f = copy(y)
	for column = 2, n do
		-- calculate a(i) and update fval
		local row = 1
		for i = column, n do
			f[row] = (f[row + 1] - f[row]) / (x[row + column - 1] - x[row])
			row = row + 1
		end
		a[column] = f[1]
	end

	-- prepare the string of the polynomial: a1 + a2(x -x1) + a3(x-x1)(x-x2) + ... + an(x-x1)...
	local s, abs = '', math.abs
	for i = 1, n do -- coef a[i]
		local skipq = false -- Lua 5.4.6 doesn't provide 'continue'
		if i == 1 then
			s = s .. tostring(a[i]) -- sprintf("%g", a[i])
		else
			if abs(a[i]) < 10*eps then -- a[i] = 0
				skipq = true
			elseif a[i] > 0 then
				s = s .. ' + '
				if abs(a[i] - 1) > 10*eps then -- don't output 1
					s = s .. tostring(a[i]) .. '*'
				end
			else
				s = s .. ' - '
				if abs(a[i] + 1) > 10*eps then -- don't output 1
					s = s .. tostring(-a[i]) .. '*'
				end
			end
		end

		if not skipq then -- skip terms with coef 0
			local non1stq = false
			for j = 1, i - 1 do
				if non1stq then s = s .. '*' end
				if abs(x[j]) < 10*eps then -- x = 0
					s = s .. "x"
				elseif x[j] > 0 then
					s = s .. '(x - ' .. tostring(x[j]) .. ')' -- sprintf("(x - %g)", x[j])
				else
					s = s .. '(x + ' .. tostring(-x[j]) .. ')'
				end
				non1stq = true
			end
		end
	end
	if xx == nil then return s end
	return _set_matrix_meta(map(ff('@(x) ' .. s), xx))
end -- newtonpoly

local function _polystring(B)
	local s, not1stq, abs = '', false, math.abs
	for i = 1, #B do
		if abs(B[i]) > 10*eps then -- B[i] ~= 0
			local coef = B[i]
			if coef < 0 then
				if not1stq then s =	s .. ' - ' else s = s .. ' -' end
				coef = -coef
			else
				if not1stq then s = s .. ' + ' end
			end
			if abs(coef - 1) < eps then -- coef == 1
				if i == #B then coef = '1' else coef = '' end -- no 1*x^n
			else
				coef = tostring(coef)
				if i ~= #B then coef = coef .. '*' end
			end
			if i == #B then
				s = s .. coef
			elseif i == #B - 1 then
				s = s .. coef .. 'x'
			else
				s = s .. coef .. 'x^' .. tostring(#B - i)
			end
			not1stq = true
		end
	end
	return s
end

-- if xx is provided, return the value(s) of a polynomial, defined by data (x, y)'s, at xx;
-- otherwise, return the string and the coefficeints of the polynomial
function polynomial(x, y, xx)
	local X, Y = _poly_input(x)
	if #X ~= 0 then xx = y; x, y = X, Y end
	assert(type(x) == 'table' and type(y) == 'table' and #x == #y and #x > 1,
				 'polynomial(x, y...): x and y must be tables of the same size (≥ 2).')
	local A = {}
	for i = 1, #x do
		A[i] = {}
		for j = 1, #x-2 do A[i][j] = x[i] ^ (#x - j) end
		A[i][#x - 1], A[i][#x] = x[i], 1
	end
	local B = linsolve(mathly(A), y) -- coefs of polynomial
	local s = _polystring(B)
	if xx == nil then return s, B end
	return _set_matrix_meta(map(ff('@(x) ' .. s), xx))
end

-- use a polynomial of degree n to curve fit data with least sum of squares of errors
function polyfit(x, y, n, xx)
	local X, Y = _poly_input(x)
	if #X ~= 0 then xx, n = n, y; x, y = X, Y end
	assert(type(x) == 'table' and type(y) == 'table' and #x == #y and #x > 1, 'polyfit(x, y, n): x and y must be tables of the same size (≥ 2).')
	assert(n > 0 and isinteger(n), 'polyfit(x, y, n): n must be a positive integer.')
	assert(n < #x, "polyfit(x, y, n): n is >= number of data points. Add points with distinct x values or reduce n.")

	x = tt(x)
	local n2, N, I = 2 * n, n + 1, 1
	local S, A, B = zeros(1, n2 + 1), zeros(N), zeros(1, N)
	for i = n2, 0, -1 do S[I] = sum(x^i); I = I + 1 end

	for i = 1, N do
		I = i
		for j = 1, N do A[i][j] = S[I]; I = I + 1 end
	end

	I = 1
	for i = n, 0, -1 do B[I] = sum(x^i * y); I = I + 1 end

	B = linsolve(A, B) -- coefs of polynomial
	local s = _polystring(B)
	if xx == nil then return s, B end
	return _set_matrix_meta(map(ff('@(x) ' .. s), xx))
end

-- calculate linear correlation coefficient
function corr(x, y)
	function c(x, y)
		local n, Sx, Sy = #x, sum(x), sum(y)
		local Sxx, Syy, Sxy = sum(x*x), sum(y*y), sum(x*y)
		return (n * Sxy - Sx * Sy) / sqrt((n * Sxx - Sx^2) * (n * Syy - Sy^2))
	end
	if isvector(x) or (ismatrix(x) and #x[1] <= 2) then
		local X, Y = _poly_input(x)
		if #X ~= 0 then x, y = X, Y end
		assert(type(x) == 'table' and type(y) == 'table' and #x == #y and #x > 1, 'corr(x, y): x and y must be tables of the same size (≥ 2).')
		return c(tt(x), tt(y))
	end
	if ismatrix(x) then
		local A, B = transpose(x), {}
		for i = 1, #A do
			B[i] = {}; B[i][i] = 1.0;
			for j = i + 1, #A do B[i][j] =	c(A[i], A[j]) end
			for j = 1, i - 1 do B[i][j] = B[j][i] end
		end
		return setmetatable(B, mathly_meta)
	else
		error('corr(A): A must be a matrix.')
	end
end

-- evaluate a polynomial p at x
function polyval(p, x)
	assert(type(p) == 'table', 'polyval(p, x): invalid p. It must be a table of the coefficients of a polynomial.')
	p = tt(p)
	if type(x) ~= 'table' then
		x = { x }
	elseif type(x[1]) == 'table' then
		x = flatten(x)
	end
	local vs = {}
	for j = 1, #x do
		local v = 0
		for i = 1, #p do
			v = v + p[i] * x[j] ^ (#p - i)
		end
		vs[#vs + 1] = v
	end
	return _set_matrix_meta(vs)
end

-- calculate the Euclidean/Frobenius norm of a vector/matrix
-- if x is a mxn matrix with m, n ≥ 2, MATLAB: norm(x, "fro")
function norm(x)
	if type(x) ~= 'number' and type(x) ~= 'table' then
		error('norm(x): x must be a table, vector or matrix of numbers.')
	end
	local v = flatten(x)
	return math.sqrt(dot(v, v))
end

-- https://en.wikipedia.org/wiki/Box-Muller_transform
_next_gaussian_rand = nil -- reset
local function _gaussian_rand()
	if _next_gaussian_rand ~= nil then
		local tmp = _next_gaussian_rand
		_next_gaussian_rand = nil
		return tmp
	end

	local theta, rho = 2 * pi * math.random(), math.sqrt(-2 * math.log(1 - math.random()))
	local x, y = rho * math.cos(theta), rho * math.sin(theta)
	_next_gaussian_rand = y
	return x
end

-- generates a table of r subtables of which each has c elements, with each element equal to val
-- if c == nil, c = r;
-- if r == 1 or c == 1, return a simple table (so that it can be accessed like a[i] as in MATLAB)
-- if val == nil, it is a random number.
local function _create_table(r, c, val)
	local x = {}
	local function f()
		if val == nil or val == 'random' then
			return math.random() -- math.randomseed(os.time()) -- keep generating same seq? Lua 5.4.6
		elseif val == 'gaussian' then
			return _gaussian_rand()
		else
			return val
		end
	end
	if c == nil then c = r end
	for i = 1, r do
		x[i] = {}
		for j = 1,c do x[i][j] = f() end
	end
	return _set_matrix_meta(x)
end

-- check "rigourously" if t can be a mathly ovject, a vector or a matrix
-- igore input like t = {1, 2, 3, date=19890604}
function mathly:new(t, c, val)
	if type(t) == "table" then -- check for a given matrix
		if c ~= nil then return reshape(t, c, val) end
		local n = -1 -- t is a flat table
		for _, v in pairs(t) do
			if type(v) == 'table' then n = #v; break end
		end
		if n < 0 then
			for i = 1, #t do
				if type(t[i]) ~= 'number' then error('mathly:new: invalid input', t[i]) end
			end
			return setmetatable(t, mathly_meta) -- a mathly table
		else
			for i = 1, #t do
				assert(type(t[i]) == 'table' and #t[i] == n,'mathly: invalid input:')
				for j = 1, #t[i] do
					if type(t[i][j]) ~= 'number' then
						error('mathly:new: invalid input', t[i][j])
					end
				end
			end
			-- return _set_matrix_meta(rows) -- let mathly{{1, 2}} be a mathly matrix
			for i = 1, #t do setmetatable(t[i], mathly_meta) end -- t is a mathly matrix
			return setmetatable(t, mathly_meta)
		end
	end
	assert(isinteger(t) and isinteger(c), 'mathly(rows, columns, ...): rows and columns must be integer.')
	return _create_table(t, c, val)
end

-- generates a special table, i.e., a rxr identity matrix
function eye(row)
	local A = {}
	for i = 1, row do
		A[i] = {}
		for j = 1, row do A[i][j] = 0 end
		A[i][i] = 1
		setmetatable(A[i], mathly_meta)
	end
	return setmetatable(A, mathly_meta)
end

-- return a rxc mathly matrix with each entry = 1 (c defaults to r)
function ones(r, c) return _create_table(r, c, 1) end

-- return a rxc mathly matrix with each entry = 0 (c defaults to r)
function zeros(r, c) return _create_table(r, c, 0) end

-- return a rxc mathly matrix with each entry = random number (c defaults to r)
function rand(r, c) if r == nil then return math.random() else return _create_table(r, c, 'random') end end

-- return a mathly matrix with normally distributed random numbers
-- mu and sigma default to 0 and 1, respectively
function randn(r, c, mu, sigma)
	mu = mu or 0
	sigma = sigma or 1
	_next_gaussian_rand = nil -- 'global', reset
	local x = _create_table(r, c, 'gaussian')
	if mu == 0 and sigma == 1 then
		return x
	else
		return map(function(x) return mu + sigma * x end, x)
	end
end

--// randi(imax, m, n), randi({imin, imax}, m, n)
-- generate a mxn matrix of which each entry is a random integer in [1, imax] or [imin, imax]
function randi(imax, m, n)
	local imin = 1
	if type(imax) == 'number' then
		if imax < 1 then imin = 0 end
	elseif type(imax) == 'table' then
		imin, imax = imax[1], imax[2]
	else
		imax = 100
	end
	assert(isinteger(imin) and isinteger(imax), 'randi(imax, m, n), randi({imin, imax}, m, n): imin and imax must be integer.')
	if imin > imax then imin, imax = imax, imin end
	if m == nil then return math.random(imin, imax) end
	if n == nil then n = m end

	local B = {}
	-- math.randomseed(os.time()) -- keep generating same seq? Lua 5.4.6
	for i = 1, m do
		B[i] = {}
		for j = 1, n do
			B[i][j] = math.random(imin, imax)
		end
	end
	return _set_matrix_meta(B)
end

--// tic()
local _tictime = nil
-- os.clock() behaves differently in various platforms!!!
local clock = qq(__is_windows, os.clock, os.time)
function tic() _tictime = clock() end

-- return elapsed time from last calling tic()
function toc()
	if _tictime == nil then
		print("Please call tic() first.")
		return 0, ''
	end
	return round((clock() - _tictime)*1000)/1000, 'secs.'
end

function sleep(n)
	local t = clock()
	while clock() - t <= n do end
end

-- remove the structure of a table and returns the resulted table.
-- if t is a mathly matrix, the result is row wise (rather than column wise)
-- want column wise? use tt(t)
function flatten(x)
	local y, j = {}, 1
	local function flat(x)
		if type(x) == 'table' then
			for k, v in pairs(x) do
				if type(v) == 'table' then
					flat(v)
				elseif v ~= nil then
					y[j] = v; j = j + 1
				end
			end
		elseif x ~= nil then
			y[j] = x; j = j + 1
		end
	end
	flat(x)
	return setmetatable(y, mathly_meta)
end

-- if t table has recursively an index, idx, return true.
function hasindex(t, idx)
	if type(t) ~= 'table' then
		return false
	elseif t[idx] ~= nil then
			return true
	else
		for _, v in pairs(t) do
			if type(v) == 'table' and hasindex(v, idx) then
				return true
			end
		end
		return false
	end
end

local function _hasanyindex(t, indice)
	for i = 1, #indice do
		if hasindex(t, indice[i]) then return true end
	end
	return false
end

function isinteger(x) return math.type(x) == 'integer' end

-- return true if x is an entry of a vector, e.g., ismember(5, {1,2,3,4,5,6}),
-- ismember('are', {'We', 'are', 'the', 'world'})
function ismember(x, v)
	for _, val in pairs(v) do
		if x == val then return true end
	end
	return false
end

local _axis_equalq, _xaxis_visibleq, _yaxis_visibleq = false, true, true
local _gridline_visibleq, _specific_gridq = true, false
local _showlegendq, _vecfield_annotations = false, nil

-- 12-point and 13-point central finite difference formulas for f'(x) and f''(x)
-- generated by https://github.com/fdformula/FiniteDifferenceFormula.jl
function diff(f, x0)
	if type(f) == 'string' then f = ff(f) end
	local h = 0.01
	local x = linspace(x0 - 6*h, x0 + 6*h, 13)
	return (
	 0.0001803751803752*f(x[1])	- 0.0025974025974026*f(x[2])	+ 0.0178571428571429*f(x[3])	-
	 0.0793650793650794*f(x[4])	+ 0.2678571428571428*f(x[5])	- 0.8571428571428571*f(x[6])	+
	 0.8571428571428571*f(x[8])	- 0.2678571428571428*f(x[9])	+ 0.0793650793650794*f(x[10]) -
	 0.0178571428571429*f(x[11]) + 0.0025974025974026*f(x[12]) - 0.0001803751803752*f(x[13])) / h
end
diff1 = diff

function diff2(f, x0)
	if type(f) == 'string' then f = ff(f) end
	local h = 0.01
	local x = linspace(x0 - 6*h, x0 + 6*h, 13)
	return (
	 -0.0000601250601251*f(x[1])	+ 0.0010389610389610*f(x[2])	- 0.0089285714285714*f(x[3])	+
		0.0529100529100529*f(x[4])	- 0.2678571428571428*f(x[5])	+ 1.7142857142857142*f(x[6])	-
		2.9827777777777778*f(x0) +
		1.7142857142857142*f(x[8])	- 0.2678571428571428*f(x[9])	+ 0.0529100529100529*f(x[10]) -
		0.0089285714285714*f(x[11]) + 0.0010389610389610*f(x[12]) - 0.0000601250601251*f(x[13])) / h^2
end

-- Gauss quadrature of 12 nodes
-- generated by https://github.com/fdformula/mathly/blob/main/examples/gauss_quadrature_by_legendre_polynomial.lua
local _Gw = {
	0.2491470458134028, 0.2491470458134028, 0.2334925365383548, 0.2334925365383548,
	0.2031674267230658, 0.2031674267230658, 0.1600783285433463, 0.1600783285433463,
	0.1069393259953186, 0.1069393259953186, 0.0471753363865122, 0.0471753363865122
}

local _Gx = {
 -0.1252334085114689, 0.1252334085114689, -0.3678314989981802, 0.3678314989981802,
 -0.5873179542866175, 0.5873179542866175, -0.7699026741943047, 0.7699026741943047,
 -0.9041172563704748, 0.9041172563704748, -0.9815606342467191, 0.9815606342467191
}

local _MaxIntegralIntervalSize = 3 -- see mathly.html#integral

-- ∫f(x)dx on [a, b]
function integral(f, a, b)
	if type(a) == 'table' then b, a = a[2], a[1] end
	if type(f) == 'string' then
		f = ff(f)
	elseif type(f) == 'number' then
		return (b - a) * f
	end
	local sign = 1
	if a > b then a, b = b, a; sign = -1 end
	local n, A, B, s, siz = 1, a, b, 0, b - a
	if b - a > _MaxIntegralIntervalSize then
		n = ceil((b - a) / _MaxIntegralIntervalSize)
		siz = (b - a) / n
		B = A + siz
	end
	local m = sign * (B - A)/2
	while B <= b do
		local k, h = (B - A)/2, (B + A)/2
		for i = 1, #_Gw do s = s + _Gw[i] * f(k * _Gx[i] + h) end
		A, B = B, B + siz
	end
	return m * s
end

local function _integralF(f)
	if type(f) == 'number' then
		local v = f; return function(x, y, z) return v end -- extra args don't matter
	elseif type(f) == 'string' then
		return ff(f)
	else
		return f
	end
end

-- ∫∫f(x,y)dydx over D:
--	y in [g1(x), g2(x)]
--	x in [a, b]
function integral2(f, g, x)
	local g1, g2, a, b = g[1], g[2], x[1], x[2]
	f, g1, g2 = table.unpack(map(_integralF, {f, g1, g2}))
	local function prep(a, b)
		local sign = 1
		if a > b then a, b = b, a; sign = -1 end
		local n, A, B, s, siz = 1, a, b, 0, b - a
		if b - a > _MaxIntegralIntervalSize then
			n = ceil((b - a) / _MaxIntegralIntervalSize)
			siz = (b - a) / n
			B = A + siz
		end
		return A, B, sign * (B - A)/2, siz, b
	end
	local function F(x) -- F(xi) = integral[f(xi, y), {y, g1(xi), g2(xi)}]
		local y1, y2, s, A, B, m, siz = g1(x), g2(x), 0
		if abs(y2 - y1) < eps then return 0 end
		A, B, m, siz, y2 = prep(y1, y2)
		while B <= y2 do
			local k, h = (B - A)/2, (B + A)/2
			for i = 1, #_Gw do s = s + _Gw[i] * f(x, k * _Gx[i] + h) end
			A, B = B, B + siz
		end
		return m * s
	end
	local A, B, m, siz, s
	A, B, m, siz, b = prep(a, b); s = 0
	while B <= b do
		local k, h = (B - A)/2, (B + A)/2
		for i = 1, #_Gw do s = s + _Gw[i] * F(k * _Gx[i] + h) end
		A, B = B, B + siz
	end
	return m * s
end

-- ∫∫∫f(x,y,z)dzdydx over E:
--	z in [g1(x, y), g2(x, y)]
--	y in [h1[x], h2[y]]
--	x in [a, b]
function integral3(f, g, h, x)
	local g1, g2, h1, h2, a, b = g[1], g[2], h[1], h[2], x[1], x[2]
	f, g1, g2, h1, h2 = table.unpack(map(_integralF, {f, g1, g2, h1, h2}))
	local function prep(a, b)
		local sign = 1
		if a > b then a, b = b, a; sign = -1 end
		local n, A, B, siz = 1, a, b, b - a
		if b - a > _MaxIntegralIntervalSize then
			n = ceil((b - a) / _MaxIntegralIntervalSize)
			siz = (b - a) / n
			B = A + siz
		end
		return A, B, sign * (B - A)/2, siz, b
	end
	local function F(x) -- F(xi) = integral[f(xi, y, z), {z, g1(xi, y), g2(xi, y)}]
		local function G(y)
			local z1, z2, s, A, B, m, siz = g1(x, y), g2(x, y), 0
			if abs(z2 - z1) < eps then return 0 end
			A, B, m, siz, z2 = prep(z1, z2)
			while B <= z2 do
				local k, h = (B - A)/2, (B + A)/2
				for i = 1, #_Gw do s = s + _Gw[i] * f(x, y, k * _Gx[i] + h) end
				A, B = B, B + siz
			end
			return m * s
		end
		local y1, y2, s, A, B, m = h1(x), h2(x), 0
		if abs(y2 - y1) < eps then return 0 end
		A, B, m, siz, y2 = prep(y1, y2)
		while B <= y2 do
			local k, h = (B - A)/2, (B + A)/2
			for i = 1, #_Gw do s = s + _Gw[i] * G(k * _Gx[i] + h) end
			A, B = B, B + siz
		end
		return m * s
	end
	local A, B, m, siz, s;
	A, B, m, siz, b = prep(a, b); s = 0
	while B <= b do
		local k, h = (B - A)/2, (B + A)/2
		for i = 1, #_Gw do s = s + _Gw[i] * F(k * _Gx[i] + h) end
		A, B = B, B + siz
	end
	return m * s
end -- integral3

-- merge two tables, t and t2, of any structure into t
function merge(t, t2)
	if type(t) ~= 'table' then t = {t} end
	if type(t2) ~= 'table' then t2 = {t2} end
	for k, v in pairs(t2) do
		if type(k) == 'string' then
			if t[k] == nil then
				t[k] = copy(t2[k])
			else -- merge
				if type(t[k]) == 'table' and type(v) == 'table' then
					t[k] = merge(t[k], t2[k]) -- merge
				else
					t[k] = copy(v) -- t2 overwrites t
				end
			end
		else -- it's a number index
			if not ismember(v, t) then t[#t + 1] = v end
		end
	end
	return t
end

function isempty(t)
	assert(type(t) == 'table', "bad argument to 'isempty' (table expected, got nil)")
	return next(t) == nil
end

-- plot the graphs of functions in a way like in MATLAB with more features
local _xrange, _yrange = nil, nil
local plotly = {}
function plot(...)
	local axis_equalq = _axis_equalq
	local xaxis_visibleq, yaxis_visibleq = _xaxis_visibleq, _yaxis_visibleq
	local gridline_visibleq, showlegendq = _gridline_visibleq, _showlegendq
	_specific_gridq, _3d_plotq, plotly.layout = false, false, {}

	-- scan for xrange, yrange, and layout
	_xrange, _yrange = nil, nil
	local layout_arg = {}
	for _, v in pairs{...} do
		if type(v) == 'table' and next(v) ~= nil then -- the last one matters
			if v.layout	then merge(layout_arg, v.layout) end
			if v.range	then _xrange = v.range end -- deprecated
			if v.xrange	then _xrange = v.xrange end -- handled by figure.toplotstring(self)
			if v.yrange	then _yrange = v.yrange end
			local opts = {'grid', 'width', 'height', 'title', 'xaxis', 'yaxis', 'margin', 'names'}
			for i = 1, #opts do
				if v[opts[i]] then
					local x = {}; x[opts[i]] = v[opts[i]]
					merge(layout_arg, x)
				end
			end
		end
	end

	local args, x_start, x_stop = {}, nil, nil -- range of x for a plot
	local adjustxrangeq, traces, layout_arg = false, {}, {}
	for _, v in pairs{...} do
		if type(v) == 'function' then
			args[#args + 1], adjustxrangeq = v, true
			goto end_for
		elseif type(v) == 'string' and string.sub(v, 1, 1) == '@' then -- @ is followed by expr in terms of x
			args[#args + 1], adjustxrangeq = ff(v), true
			goto end_for
		end

		if type(v) == 'table' then
			if next(v) == nil then goto end_for end
			if v[1] == 'pareto' then
				for i = 1, #v[#v] do
					traces[#traces + 1] = v[#v][i][2]
				end
				v[#v] = nil
				v[1] = 'graph'
			end

			if v[1] == 'dotplot' or v[1] == 'text' then -- graph object: {'text', trace}
				traces[#traces + 1] = v[2]
			elseif v[1] == 'contour' then -- contourplot graph object: {'contour', x, y, z}
				local trace = {type = 'contour', x = v[2], y = v[3], z = v[4]}
				for k, v in pairs(v[5]) do trace[k] = v end
				traces[#traces + 1] = trace
				x_start, x_stop = v[2][1], v[2][#v[2]]
			elseif v[1] == 'slopefield' then
				x_start, x_stop = v[2][1], v[2][2]
				for i = 1, #v[3] do
					args[#args + 1] = v[3][i][2]
					args[#args + 1] = v[3][i][3]
					args[#args + 1] = v[3][i][4]
				end
				shownotlegend()
			elseif v[1] == 'vectorfield2d' then
				x_start, x_stop = v[2][1], v[2][2]
				traces[#traces + 1] = {type = 'scatter', x = {}, y = {}}
				_vecfield_annotations = v[3]
			elseif v.type == 'pie' then
				if v.layout ~= nil then	layout_arg[#layout_arg + 1] = {layout = v.layout} end
				traces[#traces + 1] = v
			elseif v[1] == 'graph-hist' then -- group histogram graph object: {'graph-hist', x, y}
				for i = 2, #v, 2 do
					traces[#traces + 1] = {v[i], v[i + 1], type = 'bar'}
				end
				layout_arg[#layout_arg + 1] = {layout = {barmode = 'group', bargap = 0.01}}
			elseif v[1] == 'graph-box' then -- boxplot: {'graph-box', 'x', data}, 'x' or 'y'
				local count = #v
				if type(v[count][1]) == 'string' then count = count - 1 end -- it is names
				for i = 3, count do
					local trace = {type = 'box'}
					if v[2] == 'x' then trace['x'] = v[i] else trace['y'] = v[i] end
					traces[#traces + 1] = trace
				end
				if count < #v then args[#args + 1] = {names = v[#v]} end
			elseif v[1] == 'graph' then -- graph objects: {'graph', x, y, style}
				for i = 2, #v, 3 do
					if #v == 5 and i == 5 then break end -- orientation
					if type(v[i]) == 'table' and _hasanyindex(v[i], {'layout', 'names'}) then -- last item as seen in hist1(...)!
						args[#args + 1] = v[i]
						break
					end
					local xmin, xmax = min(v[i]), max(v[i])
					if x_start == nil then
						x_start, x_stop = xmin, xmax
					else
						x_start, x_stop = math.min(xmin, x_start), math.max(xmax, x_stop)
					end
					args[#args + 1] = v[i]		 -- x
					args[#args + 1] = v[i + 1] -- y
					args[#args + 1] = v[i + 2] -- style
				end

				if #v == 5 then -- show orientation of parametric curves
					local points = v[5]
					for i = 1, #points do
						args[#args + 1] = points[i][1] -- x
						args[#args + 1] = points[i][2] -- y
						args[#args + 1] = points[i][3] -- style
					end
				end
			else
				args[#args + 1] = v
			end
		else
			args[#args + 1] = v
		end
::end_for::
	end

	local i = 1
	while i <= #args do
		if type(args[i]) == 'function' then
			args[i] = {0, args[i]}
			table.insert(args, i + 1, {0, 0}) -- pretend to be x, y, ...; to be modified before plotting
		elseif i <= #args and type(args[i]) == 'table' and _hasanyindex(args[i], {'range', 'xrange', 'yrange', 'xranges', 'yranges', 'layout', 'names'}) then
			layout_arg[#layout_arg + 1] = args[i] -- to be processed finally					↑ deprecated
			i = i + 1
		else
			local trace = {}
			-- input may be {{1, 2, ...}} or {{1}, {2}, ...}
			if type(args[i]) == 'table' and type(args[i][1]) == 'table' then
				if #args[i] == 1 then -- mathly{1, 2, ...} gives {{1, 2, ...}}
					args[i] = args[i][1]
				elseif #args[i][1] == 1 then -- {{1}, {2}, ...}
					args[i] = flatten(args[i])
				end
			end

			if type(args[i]) == 'table' then
				if type(args[i][1]) == 'table' then -- plot functions defined in each column of a matrix
					local traces_tmp = {}
					local x = seq(1, #args[i]) -- the range of x: 1 to # of rows
					if x_start == nil then
						x_start, x_stop = 1, #args[i]
					else
						x_start, x_stop = math.min(1, x_start), math.max(#args[i], x_stop)
					end
					for j = 1,#args[i][1] do
						local y = {}
						for k = 1,#args[i] do
							y[k] = (args[i][k])[j]
						end
						trace = {x, y, mode='lines', style='-'}
						if j < #args[i][1] then
							traces_tmp[#traces_tmp + 1] = trace
						end
					end
					i = i + 1 -- the item has been processed

					traces_tmp[#traces_tmp + 1] = trace
					for j = 1, #traces_tmp do
						traces[#traces + 1], traces_tmp[j] = traces_tmp[j], nil
					end
				else
					trace[1] = flatten(args[i]); i = i + 1
					trace[2] = flatten(args[i])
					if x_start == nil and #trace[1] >= 2 and type(trace[1][2]) ~= 'function' then
						x_start, x_stop = trace[1][1], trace[1][#trace[1]]
					end
					if i <= #args and type(args[i]) == 'table' and #trace[1] == #trace[2] then
						i = i + 1

						trace['mode'] = ''
						if type(args[i]) == 'string' then -- options
							local s = string.lower(args[i]); i = i + 1
							if s:find('%-%-') then
								trace['mode'], trace['style'] = 'lines', '--'
							elseif s:find('%-') then
								trace['mode'], trace['style'] = 'lines', '-'
							elseif s:find('%:') then
								trace['mode'], trace['style'] = 'lines', ':'
							end

							local x = {{'r', 'red'}, {'b', 'blue'}, {'g', 'green'}, {'c', 'cyan'},
												 {'m', 'magenta'}, {'y', 'yellow'}, {'k', 'black'}, {'w', 'white'}}
							for i = 1, #x do if s:find(x[i][1]) then trace.color = x[i][2]; break end end

							x = {{'fs', 'toself'}, {'fn', 'none'}, {'fa', 'tozeroy'}, {'ff', 'tonexty'}}
							for i = 1, #x do if s:find(x[i][1]) then trace.fill = x[i][2]; break end end

							local symbol = ''
							x = {{'o', 'circle'}, {'%*', 'star'}, {'x', 'x'}, {'%^', 'triangle-up'},
									 {'%v', 'triangle-down'}, {'%>', 'triagle-right'}, {'%<', 'triagle-left'}}
							for i = 1, #x do
								if s:find(x[i][1]) then
									trace.symbol, trace.mode = x[i][2], qq(trace.mode == '', 'markers', 'lines+markers')
									break
								end
							end
						elseif type(args[i]) == 'table' then -- is it options?
							local optq = false
							for k, v in pairs(args[i]) do
								if type(k) == 'string' then
									optq = ismember(string.lower(k), {'layout', 'color', 'size', 'width', 'mode', 'symbol', 'name'})
									if optq then break end
								end
							end
							if optq then -- this arg is options
								for k, v in pairs(args[i]) do
									if type(k) == 'string' then
										local key = string.lower(k)
										if key == 'layout' then
											layout_arg[#layout_arg + 1] = {layout = v} -- to be processed finally
										else
											trace[key] = v
										end
									else
										trace[k] = v
									end
								end
								i = i + 1
							end
							if trace['symbol'] ~= nil then
								if trace['style'] == nil then
									trace['mode'] = 'markers'
								else
									trace['mode'] = 'lines+markers'
								end
							else
								trace['mode'] = 'lines'
							end
						end

						traces[#traces + 1] = trace
					else
						print('Invalid input: x and y must be of the same size.')
						return exit_plot
					end
				end
			else -- invalid input, skipped
				i = i + 1
			end
		end
	end

	local xrange = nil
	for i = 1, #layout_arg, 2 do	-- processed finally
		local names = {}
		for k, v in pairs(layout_arg[i]) do -- layout settings are merged into the 1st trace
			if k == 'layout' then
				for k_, v_ in pairs(v) do
					if type(k_) == 'string' then
						local K = string.lower(k_)
						if K == 'name' then
							traces[1][K] = v_
						elseif ismember(K, {'autosize', 'grid', 'width', 'height', 'title', 'xaxis', 'yaxis', 'margin'}) then
							plotly.layout[K] = v_
							if K == 'grid' then
								plotly.layout[K]['pattern'] = 'independent'
							end
						elseif v.grid ~= nil then
							if K == 'gridaxes' then
								for j = 1, #traces do
									local s = qq(j == 1, '', j)
									local x, y = 'xaxis' .. s, 'yaxis' .. s
									plotly.layout[x], plotly.layout[y] = v_[x], v_[y]
								end
							elseif K =='gridaxisnames' then
								_specific_gridq = true
								for j = 1, #traces do
									local s = qq(j == 1, '', j)
									traces[j]['xaxis'], traces[j]['yaxis'] = v_['xaxis' .. s], v_['yaxis' .. s]
								end
							end
						end
					end
				end
			elseif k == 'xrange' then
				xrange = v
			elseif k ~= 'names' and k ~= 'xranges' and k ~= 'yranges' then
				traces[1][k] = v
			end
		end
		if layout_arg[i]['names'] ~= nil then names = layout_arg[i]['names'] end
		if #names > 0 then
			for j = 1, math.min(#traces, #names) do
				traces[j]['name'] = names[j]
			end
		end
	end

	if adjustxrangeq then
		local x_step = 1
		--if plotly.layout.grid == nil then
		if _xrange then
			x_start, x_stop = _xrange[1], _xrange[2]
			if _xrange[3] then x_step = _xrange[3] end
		elseif x_start == nil or plotly.layout.grid then
			if xrange ~= nil then
				x_start, x_stop = xrange[1], xrange[2]
				if xrange[3] ~= nil then x_step = xrange[3] end
			else
				x_start, x_stop = -5, 5
			end
		end
		x_start, x_stop = x_start - 0.1, x_stop + 0.1
		-- end
		for i = 1, #traces do
			if #traces[i] > 0 and #traces[i][1] >= 2 and type(traces[i][1][2]) == 'function' then
				local f, g = traces[i][1][2], plotly.layout.grid
				if g and g.xranges and g.xranges[i] then
					x_start, x_stop = g.xranges[i][1] - 0.1, g.xranges[i][2] + 0.1
					if g.xranges[i][3] ~= nil then x_step = g.xranges[i][3] end
				end
				traces[i][1] = linspace(x_start, x_stop, math.max(math.ceil(math.abs((x_stop - x_start) / x_step) * 10), 200))
				traces[i][2] = map(f, traces[i][1])
			end
		end
	end

	plotly.plots(traces):show()

::exit_plot::
	plotly.layout = {}
	_axis_equalq = axis_equalq
	_xaxis_visibleq = xaxis_visibleq
	_yaxis_visibleq = yaxis_visibleq
	_gridline_visibleq = gridline_visibleq
	_showlegendq = showlegendq
end -- plot

local function _plot_interval(start, stop, step)
	local tq = type(start) == 'table'
	if tq then
		stop, step = start[2], start[3]
		start = start[1]
	end
	if step == nil then
		step = 1
	elseif step < 0 then
		error('In a range of the format {start, stop, step}: step must be positive.')
	end
	if start > stop then start, stop = stop, start end
	if tq then return {start, stop, step} else return start, stop end
end

local function _set_resolution(r, n)
	n = n or 500
	if r == nil or type(r) ~= 'number' or r < n then r = n end
	return r
end

--// #data == #opts
function namedargs(dat, opts)
	local x, OPTS, k = {}, nil, #dat + 1
	for i = 1, #dat do
		local optq = false
		if type(dat[i]) == 'table' and dat[i][1] == nil then -- more test
			for j = i, #opts do
				optq = dat[i][opts[j]] ~= nil
				if optq then break end
			end
		end
		if optq then -- a = {x=1, y=2}: a[1] == nil
			OPTS = dat[i]; k = i; break
		else
			x[i] = dat[i]
		end
	end
	if OPTS == nil then return x end
	if k == #opts then
		if OPTS[opts[k]] ~= nil then
			x[k] = OPTS[opts[k]]
		else
			x[k] = OPTS
		end
	else
		while k <= #opts do
			x[k] = OPTS[opts[k]]; k = k + 1
		end
	end
	return x -- table.unpack(results) -- Lua 5.4.6&5.4.7: doesn't work well
end

local _3d_plotq = false

--// data for a 3D plot:
-- given that x = {x1, x2, ..., xm} and y = {y1, y2, ..., yn},
--	 X = {{x1, x1, ..., x1}, {x2, x2, ..., x2}, ..., {xm, xm, ..., xm}}, #X = m, #X[i] = n
--	 Y = {{y1, y2, ..., yn}, {y1, y2, ..., yn}, ..., {y1, y2, ..., yn}}, #Y = m, #Y[i] = n
--	 Z = {{z11, ..., z1n},	 {z21, ..., z2n},	 ..., {zm1, ..., zm2}},	 #Z = m, #Z[i] = n
--	 where zij = f(xi, yj) if a surface is defined by z = f(x, y)

--// function plot3d(f, xrange, yrange, title)
-- plot a surface generated by z = f(x, y); it is not designed as general as plot(...) for 2d graphs

-- if f is a function, xrange = {xstart, xstop}, y = {ystart, ystop}
-- otherwise, X = f, Y = xrange, Z = yrange, which allows users to set up data and use it to display a graph
function plot3d(f, xrange, yrange, title, resolution)
	local args = namedargs(
		{f, xrange, yrange, title, resolution},
		{'f', 'xrange', 'yrange', 'title', 'resolution'})
	f, xrange, yrange, title, resolution = args[1], args[2], args[3], args[4], args[5]

	xrange = xrange or {-5, 5}
	yrange = yrange or xrange
	local X, Y, Z = {}, {}, {}
	if type(f) == 'string' then f = ff(f) end
	if type(f) == 'function' then
		xrange, yrange = _plot_interval(xrange), _plot_interval(yrange)
		resolution = _set_resolution(resolution, 100)
		local n = max(math.ceil(max(xrange[2] - xrange[1], yrange[2] - yrange[1])) * 10, resolution)
		local x, y = linspace(xrange[1], xrange[2], n), linspace(yrange[1], yrange[2], n)
		for i = 1, #x do
			local xs, zs = {}, {}
			for j = 1, #y do xs[j] = x[i]; zs[j] = f(x[i], y[j]) end -- xs = mathly(1, #y, x[i])
			X[i], Y[i], Z[i] = xs, y, zs
		end
	else
		X, Y, Z = f, xrange, yrange
	end

	plotly.layout, _3d_plotq = {}, true
	if title ~= nil then plotly.layout.title = title end
	plotly.layout.margin = { l = 20, r = 20, b = 20, t = 40}

	local trace = {x = X, y = Y, z = Z, type = 'surface'}
	plotly.plots({trace}):show()
	plotly.layout, _3d_plotq = {}, false
end

-- plot rho, a spherical function of theta and phi, where theta is in the range thetarange = {θ1, θ2}
-- and phi is in the range phirange = {φ1, φ2}
function plotsphericalsurface(rho, thetarange, phirange, title, resolution)
	local args = namedargs(
		{rho, thetarange, phirange, title, resolution},
		{'rho', 'thetarange', 'phirange', 'title', 'resolution'})
	rho, thetarange, phirange, title, resolution = args[1], args[2], args[3], args[4], args[5]

	if type(rho) == 'number' then
		local tmp = rho
		rho = function(t, p) return tmp end
	elseif type(rho) == 'string' then
		rho = ff(rho)
	end
	thetarange, phirange = _plot_interval(thetarange or {0, 2*pi}), _plot_interval(phirange or {0, pi})
	resolution = _set_resolution(resolution, 100)

	local X, Y, Z = {}, {}, {}
	local m = max(math.ceil(max((thetarange[2] - thetarange[1]) * 10)), resolution)
	local n = max(math.ceil(max((phirange[2] - phirange[1]) * 10)), resolution)
	local theta = linspace(thetarange[1], thetarange[2], m)
	local phi = linspace(phirange[1], phirange[2], n)
	for i = 1, m do
		local x, y, z = {}, {}, {}
		for j = 1, n do
			x[j] = rho(theta[i], phi[j]) * math.sin(phi[j]) * math.cos(theta[i])
			y[j] = rho(theta[i], phi[j]) * math.sin(phi[j]) * math.sin(theta[i])
			z[j] = rho(theta[i], phi[j]) * math.cos(phi[j])
		end
		X[i], Y[i], Z[i] = x, y, z
	end
	plot3d(X, Y, Z, title)
end

-- Plot a surface defined by xyz = {x(u, v), y(u, v), z(u,v)}.
function plotparametricsurface(xyz, urange, vrange, title, resolution)
	local args = namedargs(
		{xyz, urange, vrange, title, resolution},
		{'xyz', 'urange', 'vrange', 'title', 'resolution'})
	xyz, urange, vrange, title, resolution = args[1], args[2], args[3], args[4], args[5]

	urange = _plot_interval(urange or {-5, 5})
	vrange = _plot_interval(vrange or urange)
	resolution = _set_resolution(resolution, 100)

	local x, y, z = {}, {}, {}
	local m = max(math.ceil(max((urange[2] - urange[1]) * 20)), resolution)
	local n = max(math.ceil(max((vrange[2] - vrange[1]) * 20)), resolution)
	local u, v = linspace(urange[1], urange[2], m), linspace(vrange[1], vrange[2], n)
	for i = 1, 3 do
		if type(xyz[i]) == 'string' then xyz[i] = ff(xyz[i]) end
	end
	for i = 1, m do
		local xs, ys, zs = {}, {}, {}
		for j = 1, n do
			xs[j], ys[j], zs[j] = xyz[1](u[i], v[j]), xyz[2](u[i], v[j]), xyz[3](u[i], v[j])
		end
		x[i], y[i], z[i] = xs, ys, zs
	end
	plot3d(x, y, z, title)
end

function plotparametriccurve2d(xy, trange, style, resolution, orientationq)
	plot(parametriccurve2d(xy, trange, style, resolution, orientationq))
end

-- xyz = { ... }, the parametric equations, x(t), y(t), z(t), in order, of a space curve,
-- trange is the range of t
function plotparametriccurve3d(xyz, trange, title, resolution, orientationq)
	local args = namedargs(
		{xyz, trange, title, resolution, orientationq},
		{'xyz', 'trange', 'title', 'resolution', 'orientationq'})
	xyz, trange, title, resolution, orientationq = args[1], args[2], args[3], args[4], args[5]

	trange, resolution = _plot_interval(trange or {0, 2 * pi}), _set_resolution(resolution)
	local n = math.max(math.ceil((trange[2] - trange[1]) * 50), resolution)
	local t = linspace(trange[1], trange[2], n)

	for i = 1, 3 do
		if type(xyz[i]) == 'string' then xyz[i] = ff(xyz[i]) end
	end

	local x, y, z = map(xyz[1], t), map(xyz[2], t), map(xyz[3], t)
	plotly.layout, _3d_plotq = {}, true
	if title ~= nil then plotly.layout.title = title end
	plotly.layout.margin = { l = 20, r = 20, b = 20, t = 40}

	local traces = {{x = x, y = y, z = z, type = 'scatter3d', mode = 'lines', showlegend = false}}
	if orientationq then
		local n, siz, t = 7, 12, trange[1]
		local h = (trange[2] - trange[1]) / (2 * n)
		for i = 1, n do
			traces[#traces + 1] = {
				x = {xyz[1](t)}, y = {xyz[2](t)}, z = {xyz[3](t)},
				type = 'scatter3d', mode = 'markers', showlegend = false,
				marker = {size = siz, color = 'blue', opacity = 0.8}}
			siz, t = siz - 1.25, t + h
		end
	end
	plotly.plots(traces):show(); traces = nil
	plotly.layout = {}
	_3d_plotq = false
end

local _anmt_fregex = '^%s*@%s*(%(%s*[%w,%s]*%))%s*(.+)%s*$' -- expr of a function
local _anmt_animateq, _anmt_act = false, ''

function _to_jscript_expr(expr)
	local f = string.gsub
	local s = f(expr, "%^", "**")
	s = f(s, "asin", "_ArcS_")
	s = f(s, "acos", "_ArcC_")
	s = f(s, "atan", "_ArcT_")
	s = f(s, "sin", "Math.sin")
	s = f(s, "cos", "Math.cos")
	s = f(s, "tan", "Math.tan")
	s = f(s, "exp", "Math.exp")
	s = f(s, "log", "Math.log")
	s = f(s, "sqrt", "Math.sqrt")
	s = f(s, "_ArcS_", "Math.asin")
	s = f(s, "_ArcC_", "Math.acos")
	s = f(s, "_ArcT_", "Math.atan")
	return s
end

local function _anmt_adjust_traces(traces)
	if type(traces) ~= 'table' or type(traces[1]) ~= 'table' then
		error(_anmt_act .. '(...): enhancements must be a list of lists.')
	end
	for i = 1, #traces do
		local obj = traces[i]
		if obj.line then -- { x = {-4, 2}, y = {3, 4}, color = 'blue', width = 2, line = true}
		elseif obj.point then -- { x = 5.1, y = 9.2, color = 'blue', size = 3, point = true}
		elseif obj.text ~= nil then
		elseif obj.parametriceqs or (type(obj.x) == 'string' and type(obj.y) == 'string') then
			_, s = string.match(obj.x, _anmt_fregex)
			obj.x = _to_jscript_expr(s)
			_, s = string.match(obj.y, _anmt_fregex)
			obj.y = _to_jscript_expr(s)
			obj.parametriceqs = true
		end
	end
end

local _anmt_cs_labels = {}
local function _anmt_new_control(c, cs, rs, opts) -- each a-zA-Z but p, t, x, y, T, X, and Y is a control
	local t = #c == 1 and ((c >= 'a' and c <= 'z') or (c >= 'A' and c <= 'Z')) and
						not ismember(c, {'p', 't', 'x', 'y', 'T', 'X', 'Y'}) and
						not ismember(c, cs)
	if t then
		if opts[c] ~= nil then
			if type(opts[c]) ~= 'table' then error('Range of ' .. c .. ' is invalid.') end
			local i = #cs + 1
			cs[i] = c; _anmt_cs_labels[i] = opts[c].label or c
			rs[i] = opts[c]
			if rs[i][3] == nil then rs[i][3] = qq(rs[i][1] > rs[i][2], -1, 1) end
		else
			error("Range of control '" .. c .. "' is not specified.")
		end
	end
end

local function _anmt_scan_controls(str, cs, rs, opts)
	for c in string.gmatch(str, "[^(%@%s|%(|%)|%{|%}|%[|%]|%+|%-|%*|%^|%/|%%|%,)]+") do
		_anmt_new_control(c, cs, rs, opts)
	end
end

local function _anmt_parse_args(fstr, opts)
	_anmt_cs_labels = {} -- ~[i], label of ith control
	local cs, rs = {}, {} -- ~[i], ith control, range of ith control
	if opts == nil then opts = {} end
	if _anmt_animateq == true then
		cs[1] = 'p'; _anmt_cs_labels[1] = 'Play'; rs[1] = {0, 1, 1/100} -- 'p' (play), reserved for animation
		if opts ~= nil and type(opts.p) == 'table' and opts.p.default ~= nil then rs[1].default = opts.p.default end
	end
	if opts.controls ~= nil then
		if type(opts.controls) == 'string' then
			for i = 1, #opts.controls do
				_anmt_new_control(string.sub(opts.controls, i, i), cs, rs, opts)
			end
		else
			error("Field 'controls' must be a string.")
		end
	end

	local xr = opts.xrange or {-5, 5, 0.1}
	if type(xr) ~= 'table' or xr[1] >= xr[2] then error('Range of x is invalid.') end

	local xexpr, yexpr, s = nil, nil, ''
	if type(fstr) == 'string' then
		s = fstr
		xexpr = nil
		_, yexpr = string.match(fstr, _anmt_fregex)
	elseif type(fstr) == 'table' then
		local x, y = '', ''
		if type(fstr.x) == 'string' and type(fstr.y) == 'string' then
			x, y = fstr.x, fstr.y
		elseif #fstr == 2 and type(fstr[1]) == 'string' and type(fstr[2]) == 'string' then
			x, y = fstr[1], fstr[2]
		end
		if x ~= '' then
			_, xexpr = string.match(x, _anmt_fregex)
			_, yexpr = string.match(y, _anmt_fregex)
			s = x .. ' ' .. yexpr
		elseif type(fstr[1]) == 'table' then -- fstr = {{...}, {...}, ...}
			error(_anmt_act .. "(fstr, ...): fstr can't be a table of tables.")
		end
	elseif fstr ~= nil then
		error(_anmt_act .. "(fstr, ...): fstr must be a string or a pair of strings.")
	end
	if type(opts.controls) == 'string' then
		local I = 1
		if _anmt_animateq then I = 2 end -- skip 1st one: p
		for i = I, #cs do
			rs[#rs + 1] = opts[cs[i]]
		end
	else
		_anmt_scan_controls(s, cs, rs, opts)
	end

	local jxexpr, jyexpr, tr = nil, nil, nil
	if fstr ~= nil then jyexpr = _to_jscript_expr(yexpr) end
	if xexpr ~= nil then
		jxexpr = _to_jscript_expr(xexpr)
		if opts.t == nil or type(opts.t) ~= 'table' then
			tr = opts.x or {-5, 5, 0.1}
		else
			tr = opts.t
		end
	end
	local jscode = ''
	if opts.javascript ~= nil then jscode = opts.javascript end
	if opts.enhancements ~= nil then _anmt_adjust_traces(opts.enhancements) end -- point, line, parametriceqs

	local title = nil
	if type(opts.layout) == 'table' then title = opts.layout.title end
	return cs, rs, xr, opts.yrange, tr, title, xexpr, yexpr, jxexpr, jyexpr, opts.enhancements, jscode
end -- _anmt_parse_args

function _anmt_fill(s)
	if s == 'fa' then -- fill to the x-Axis
		s = "tozeroy'"
	elseif s == 'ff' then -- fill to previous Function
		s = "tonexty'"
	elseif s == 'fs' then -- fill to Self
		s = "toself'"
	else
		s = "none'" -- No fill
	end
	return ", fill: '" .. s
end

local function _amnt_write_subtraces(traces, tr, file, resolution)	 -- traces = {{...}, {...}, ...}
	if type(traces) ~= 'table' or #traces == 0 then return end
	local fmt, head = string.format, ''
	local function toJS(v)
		if type(v) == 'string' then return _to_jscript_expr(v) else return tostring(v) end
	end
	local function write_traces()
		for i = 1, #traces do
			local obj, style = traces[i], '' -- Plotly JavaScript properties in string is allowed
			local color = qq(type(obj.color) == 'string', obj.color, 'black')
			if type(obj.style) == 'string' then style = ", " .. obj.style end
			if obj.line then
				trace = fmt("{ x: [%s, %s], y: [%s, %s], mode: 'lines', line: { color: '%s', width: %d %s } }",
										toJS(obj.x[1]), toJS(obj.x[2]), toJS(obj.y[1]), toJS(obj.y[2]), color, obj.width or 3, style)
				file:write(fmt("	%smthlyTraces.push(%s);\n", head, trace))
			elseif obj.point then
				trace = fmt("{ x: [%s], y: [%s], mode: 'markers', marker: { color: '%s', size: %f %s } }",
										toJS(obj.x), toJS(obj.y), color, obj.size or 8, style)
				file:write(fmt("	%smthlyTraces.push(%s);\n", head, trace))
			elseif obj.text ~= nil then
				trace = fmt("{ x: [%s], y: [%s], text: '%s', mode: 'text', type: 'scatter', textposition: 'bottom center', name: '', textfont: { color: '%s', size: %f %s } }",
										toJS(obj.x), toJS(obj.y), obj.text, color, obj.size or 10, style)
				file:write(fmt("	%smthlyTraces.push(%s);\n", head, trace))
			elseif obj.parametriceqs then
				local tr1, res, localtrq = obj.t, 500, true
				if tr1 == nil then
					if tr ~= nil then localtrq = false else tr1 = {-5, 5, 0.1} end
				end
				file:write(head .. "	if (true) {\n") -- 'if (true) ' can be deleted)
				if localtrq then
					file:write(head .. "		const t = [];\n") -- local t
					if type(obj.resolution) == 'number' then res = min({500, obj.resolution}) end
					local step = tr1[3] or (tr1[2] - tr1[1]) / res
					file:write(fmt("		%sfor (let i = %s; i <= %s; i += %s) { t.push(i); }\n", head, tostring(tr1[1]), tostring(tr1[2]), tostring(step)))
				end
				trace = fmt("{ x: t.map(t => %s), y: t.map(t => %s), mode: 'lines', line: { simplify: false, color: '%s', width: %f %s }%s }",
										obj.x, obj.y, color, obj.width or 3, style, _anmt_fill(obj.fill))
				file:write(fmt("		%smthlyTraces.push(%s);\n%s	}\n", head, trace, head))
			end
		end
	end
	write_traces()
end -- _amnt_write_subtraces

local function _amnt_write_traces(cs, opts, tr, file, xexpr, jxexpr, jyexpr, enhancements, resolution)
	if jyexpr ~= nil then -- fstr is nil
		local fmt, s = string.format, '{ '
		if xexpr == nil then
			s = s .. fmt("x: x, y: x.map(x => %s),", jyexpr)
		else -- parametric eqs
			s = s .. fmt("x: t.map(t => %s), y: t.map(t => %s),", jxexpr, jyexpr)
		end
		s = s .. " mode: 'lines', line: { simplify: false"
		if opts.color ~= nil then s = s .. ", color: '" .. opts.color .. "'" end
		if opts.width ~= nil then s = s .. ", width: " .. opts.width end
		if opts.style ~= nil then s = s .. ", " .. opts.style end
		s = s .. " }" .. _anmt_fill(opts.fill) .. " }"
		file:write(fmt("	mthlyTraces.push(%s);\n", s))
	end
	if type(enhancements) == 'table' then
		_amnt_write_subtraces(enhancements, tr, file, resolution)
	end
end

local function _anmt_layout_opts(axis, fmt, file) -- axis = layout.xaxis & yaxis
	if axis ~= nil then
		map(function(k) if axis[k] ~= nil then file:write(fmt(", %s: %s", k, qq(axis[k] == true, 'true', 'false'))) end end,
				{'showgrid', 'visible', 'zeroline', 'showticklabels'})
	end
end

local function _write_manipulate_html(fname, cs, rs, xr, yr, tr, title, xexpr, yexpr, jxexpr, jyexpr, enhancements, jscode, opts)
	local file, fmt = io.open(fname, "w"), string.format
	if file == nil then
		print(fmt("Failed to create %s. The very device might not be writable.", fname))
		return
	end
	local s = [[<!DOCTYPE html><!-- generated by MathLua: https://mathlua.github.io -->
<html>
<head>
<meta charset="utf-8">
<title>MathLua Function Animation</title>
<script src="%s"></script>
<!-- <script src="https://cdn.plot.ly/plotly-latest.min.js"></script> -->
<style>
label {
	display: inline-block;
	width: 10px;
	left: 50px;
	text-align: left;
	vertical-align: middle;
	position: absolute;
	white-space: nowrap;
}
input {
	display: inline-block;
	width: 200px;
	left: 65px;
	vertical-align: middle;
	position: absolute;
}
input:focus {outline: none;}
</style>
</head>
<body>
<div id="mathlyDiv" style="width:%dpx;height:%dpx;display:inline-block;top:%dpx;position:absolute;"></div>
<span id='title' style="width:%dpx;left:0px;display:block;text-align:center;">&nbsp;</span>
<!-- controls -->
]]
	local w, h, optsq, layout, resolution = 800, 600, type(opts) == 'table', nil, 500
	if optsq then
		if opts.resolution ~= nil and type(opts.resolution) == 'number' then
			resolution = max({500, abs(opts.resolution)})
		end
		if type(opts.layout) == 'table' then
			layout = opts.layout
			if type(layout.width)	== 'number' and layout.width > 0 then w = layout.width end
			if type(layout.height) == 'number' and layout.height > 0 then h = layout.height end
		end
	end
	file:write(fmt(s, plotly_engine, w, h, 50 + 30 * qq(#cs > 1, #cs - 2, 0), w))
	local top = 60 -- sliders
	local shift = 0
	if #cs > 0 then shift = max(map(function(x) return #x end, _anmt_cs_labels)) end
	shift = 8 * shift
	for i = 1, #cs do
		s = [[<label for="mthlySldr%s" style='top:%dpx;'>%s:</label>
<input type="range" id="mthlySldr%s" min="%s" max="%s" value="%s" style='left:%dpx;top:%dpx;' step="%s"></input><span id="mthlySldr%svalue" style="left:%dpx;top:%dpx;position:absolute">&nbsp;</span>
]]
		s = fmt(s, cs[i], top, _anmt_cs_labels[i], cs[i], tostring(rs[i][1]), tostring(rs[i][2]), tostring(rs[i][1]), 64 + shift, top, tostring(rs[i][3]), cs[i], 285 + shift, top)
		if i == 1 and _anmt_animateq then
			file:write(fmt([[
<button id='mthlyPlayButtn' type="button" onclick="mthlyPlay()" style="width:68px;left:%dpx;top:%dpx;position:absolute">Pause</button>
<button type="button" onclick=mthlySpeedUp(-50) style="width:60px;left:%dpx;top:%dpx;position:absolute">Slower</button>
<button type="button" onclick=mthlySpeedUp(50) style="width:60px;left:%dpx;top:%dpx;position:absolute">Faster</button>
]], 340+shift, top, 411+shift, top, 474+shift, top))
		else
			file:write(fmt([[
<button type="button" title="Previous value" onclick="mthly%sNext(-1)" style="width:48px;left:%dpx;top:%dpx;position:absolute">Prev</button>
<button type="button" title="Next value" onclick="mthly%sNext(1)" style="width:48px;left:%dpx;top:%dpx;position:absolute">Next</button>
]], cs[i], 340+shift, top, cs[i], 391+shift, top))
		end
		top = top + 30
		file:write(s)
	end
	s = '<span id="displaytext" style="left:%dpx;top:%dpx;position:absolute">&nbsp;</span>\n'
	file:write(fmt(s, 74, top))
	file:write(fmt([[
<script type="text/javascript">
function displaytext() { return ""; } // to be overwritten
function displaytitle() { return "%s"; }
var x = [], t = [], X, Y, T, p, mthlyGlobal = [], mthlyGlobal1 = [], mthlyGlobal2 = [], mthlyGlobal3 = [], mthlyGlobal4 = [], mthlyGlobal5 = [];
]], title or ''))
	for i = qq(_anmt_animateq, 2, 1), #cs do
		file:write(fmt([[
function mthly%sNext(x) {
	x = %s + x*mthly%sStep;
	if (x < mthly%sMin) {
		x = mthly%sMax;
	} else if (x > mthly%sMax) {
		x = mthly%sMin;
	}
	x = Math.round(x * 1000) / 1000;
	mthlySldr%s.value = x;
	document.getElementById("mthlySldr%svalue").innerHTML = x;
}
]], cs[i], cs[i], cs[i], cs[i], cs[i], cs[i], cs[i], cs[i], cs[i]))
	end
	if _anmt_animateq then
		file:write([[

var mthlyAutoPlayq = true, mthlyIntervalId = null, mthlyInterval = 200;
const mthlyPlayButtn = document.getElementById('mthlyPlayButtn');
function mthlyPlayButtnTxt() { mthlyPlayButtn.textContent = mthlyAutoPlayq? 'Pause' : 'Resume'; }
function mthlyPlay() { mthlyAutoPlayq = !mthlyAutoPlayq; mthlyPlayButtnTxt(); }
function mthlySpeedUp(step) {
	mthlyAutoPlayq = true; mthlyPlayButtnTxt();
	if (mthlyIntervalId != null) { clearInterval(mthlyIntervalId); }
	mthlyInterval -= step;
	if (mthlyInterval <= 0) { mthlyInterval = 10; }
	mthlyIntervalId = setInterval(mthlyAnimatePlot, mthlyInterval);
}
var mthlySldrpstep = ]] .. tostring(rs[1][3]) .. ";\n")
		if type(opts.speed) == 'number' then file:write(fmt("mthlySpeedUp(%f);\n", opts.speed * 50)) end
	end

	local squareq = true
	if layout ~= nil and layout.square == false then squareq = false end
	file:write(fmt("\nconst mthlyLayout = {\n	xaxis: { range: [%s, %s]", tostring(xr[1]), tostring(xr[2])))
	if layout ~= nil then _anmt_layout_opts(layout.xaxis, fmt, file) end
	file:write("}, // plot with fixed axes\n")

	if yr == nil then
		yr = xr
	elseif type(yr) ~= 'table' or yr[1] >= yr[2] then
		error('Range of y is invalid.')
	end
	file:write(fmt("	yaxis: { range: [%s, %s]", tostring(yr[1]), tostring(yr[2])))
	if layout ~= nil then _anmt_layout_opts(layout.yaxis, fmt, file) end
	if squareq then file:write(", scaleanchor: 'x', scaleratio: 1") end -- square aspect ratio
	file:write("	},\n	showlegend: false\n};\n\n")
	if title == nil then
		if xexpr == nil then
			title = 'y = ' .. yexpr
		else
			title = 'x(t) = ' .. xexpr .. ', y(t) = ' .. yexpr
		end
	end

	for i = 1, #cs do
		file:write(fmt("var mthlySldr%s = document.getElementById('mthlySldr%s');\n", cs[i], cs[i]))
	end

	for i = 1, #cs do -- values of control sliders
		local v = rs[i].default;
		if v == nil then v = rs[i][1] end
		file:write(fmt("mthlySldr%s.value = %s;\nvar %s = %s;\n", cs[i], tostring(v), cs[i], tostring(v)))
	end -- why Number(...)? Values of sliders in JavaScript are STRINGS!

	if not _anmt_animateq then file:write("p = 1;\n") end
	if xexpr ~= nil then -- parametric eqs
		s = fmt("for (let i = %s; i <= p * (%s %s %s) %s %s; i += %s) { t.push(i); }\n",
						tostring(tr[1]), tostring(tr[2]), qq(tr[1] > 0, '-', '+'), tostring(abs(tr[1])),
						qq(tr[1] > 0, '+', '-'), tostring(abs(tr[1])), tostring((tr[2] - tr[1]) / resolution))
	else
		s = fmt("for (let i = %s; i <= p * (%s %s %s) %s %s; i += %s) { x.push(i); }",
						tostring(xr[1]), tostring(xr[2]), qq(xr[1] > 0, '-', '+'), tostring(abs(xr[1])),
						qq(xr[1] > 0, '+', '-'), tostring(abs(xr[1])), tostring((xr[2] - xr[1]) / resolution))
		if tr == nil then tr = xr; s = s .. "; t = x;" end
		s = s .. "\n"
	end
	file:write(s)

	-- X, Y, T - values at the last/present point of a curve
	if _anmt_animateq then
		if xexpr ~= nil then
			file:write(fmt("let mthlyTmp = t[t.length - 1];\nif (true) { const t = mthlyTmp; X = %s; Y = %s; T = mthlyTmp; }\n", jxexpr, jyexpr))
		else
			file:write(fmt("let mthlyTmp = x[x.length - 1];\nif (true) { const x = mthlyTmp; X = mthlyTmp; Y = %s; }\n", jyexpr))
		end
	end

	file:write("\nvar mthlyTraces = [];\nconst mthlyxMin = " .. tostring(xr[1]) .. ", mthlyxMax = " .. tostring(xr[2]) .. ", mthlyxStep = " .. tostring(xr[3] or 1) ..
						 ";\nconst mthlyyMin = " .. tostring(yr[1]) .. ", mthlyyMax = " .. tostring(yr[2]) .. ";\n")
	file:write("const mthlytMin = " .. tostring(tr[1]) .. ", mthlytMax = " .. tostring(tr[2]) .. ", mthlytStep = " .. tostring(tr[3] or 1) .. ";\n")
	for i = 1, #cs do
		file:write("const mthly" .. cs[i].. "Min = " .. tostring(rs[i][1]) .. ", mthly" .. cs[i].. "Max = " .. tostring(rs[i][2]) .. ", mthly" .. cs[i] .. "Step = " .. tostring(rs[i][3] or 1) .. ';\n')
	end
	file:write("\nfunction mthlyUpdateTraces() {\n	mthlyTraces = [];\n") -- // mthlyTraces = new Array(); mthlyTraces.splice(0); ... no good
	if type(jscode) == 'string' and jscode ~= '' then file:write("\n  // vvvvv user's javascript vvvvv\n" .. jscode .. "  // ^^^^^ user's javascript ^^^^^\n\n") end
	_amnt_write_traces(cs, opts, tr, file, xexpr, jxexpr, jyexpr, enhancements, resolution)
	if _anmt_animateq then file:write("	mthlyPlayButtnTxt();\n") end
	file:write([[
	document.getElementById("displaytext").innerHTML = displaytext();
	document.getElementById("title").innerHTML = displaytitle();
}

mthlyUpdateTraces();
const mthlyInitData = mthlyTraces;

var mthlyNewCs = [], mthlyOldCs = []])
	for i = 1, #cs do
		if i > 1 then file:write(", ") end
		file:write("99999999") -- each control is numeric
	end
	file:write("];\n\nfunction mthlyAnimatePlot() {\n")
	if _anmt_animateq then
		s = [[
	if (mthlyAutoPlayq) {
		let x = String(Number(mthlySldrp.value) + mthlySldrpstep);
		mthlySldrp.value = String(x);
		if (x > 1) { mthlySldrp.value = '0'; }
		document.getElementById("mthlySldrpvalue").innerHTML = '' + Math.round(mthlySldrp.value*100) + '%'
	}
]]
		file:write(s)
	end

	for i = 1, #cs do -- values of control sliders
		file:write(fmt("	%s = Number(mthlySldr%s.value);\n", cs[i], cs[i]))
	end

	if _anmt_animateq then
		if xexpr ~= nil then -- parametric eqs
			file:write(fmt(
				"	t = []; for (let i = %s; i <= p * (%s %s %s) %s %s; i += %s) { t.push(i); };\n	T = t[t.length - 1];\n",
				tostring(tr[1]), tostring(tr[2]), qq(tr[1] > 0, '-', '+'), tostring(abs(tr[1])),
				qq(tr[1] > 0, '+', '-'), tostring(abs(tr[1])), tostring((tr[2] - tr[1]) / resolution)))
			file:write(fmt("	if (true) { const t = T; X = %s; Y = %s; };\n", jxexpr, jyexpr))
		else
			file:write(fmt(
				"	x = []; for (let i = %s; i <= p * (%s %s %s) %s %s; i += %s) { x.push(i); }; t = x;\n	X = x[x.length - 1];",
				tostring(xr[1]), tostring(xr[2]), qq(xr[1] > 0, '-', '+'), tostring(abs(xr[1])),
				qq(xr[1] > 0, '+', '-'), tostring(abs(xr[1])), tostring((xr[2] - xr[1]) / resolution)))
			file:write(fmt("	if (true) { const x = X; Y = %s; T = x; };\n", jyexpr))
		end
	end

	file:write("	// has any controls changed?\n	mthlyNewCs = [") -- new values of controls
	for i = 1, #cs do
		if i > 1 then file:write(", ") end
		file:write(cs[i])
	end
	file:write("];\n")

	if #cs == 1 then
		file:write("	if (Math.abs(mthlyOldCs[0] - mthlyNewCs[0]) < 0.00001) { return; }\n")
	else
		file:write(fmt([[
	var unchangedq = true;
	for (let i = 0; i < %d; i++) {
		if (Math.abs(mthlyOldCs[i] - mthlyNewCs[i]) > 0.00001) {
			unchangedq = false; break;
		}
	}
	if (unchangedq) { return; }
]], #cs))
	end

	file:write("	mthlyOldCs = [") -- new values of controls
	for i = 1, #cs do
		if i > 1 then file:write(", ") end
		file:write(cs[i])
	end
	file:write([[]; // update values of controls
	mthlyUpdateTraces();
	Plotly.animate('mathlyDiv', {
		data: mthlyTraces,
		traces: mthlyTraces.keys() // update all traces
	}, {
		transition: { duration: 0 },
		frame: { duration: 0 }
	});
}

]])

	for i = 1, #cs do -- slider event handlers
		s = [[
document.getElementById("mthlySldr%svalue").innerHTML = mthlySldr%s.value;
mthlySldr%s.addEventListener("input", function() { document.getElementById("mthlySldr%svalue").innerHTML = mthlySldr%s.value; });
]]
		file:write(fmt(s, cs[i], cs[i], cs[i], cs[i], cs[i]))
	end
	file:write([[

Plotly.newPlot('mathlyDiv', mthlyInitData, mthlyLayout);
mthlyAnimatePlot();
mthlyIntervalId = setInterval(mthlyAnimatePlot, 200); // animate every 0.2 seconds
</script>
</body>
</html>
]])
	file:close()
end -- _write_manipulate_html

-- vvvvvvvvvvv from dkjson 2.8 (at the end of this source file) vvvvvvvvvvv --
local _open_cmd -- this needs to stay outside the function, or it'll re-sniff every time...
local function _open_url(url)
	local fmt = string.format
	if not _open_cmd then
		if __is_windows then
			_open_cmd = function(url)
				-- os.execute(fmt('start "%s"', url))
				os.execute(fmt('"%s" %s', win_browser, url))
			end
		elseif (io.popen("uname -s"):read'*a'):sub(1, 6) == "Darwin" then
			_open_cmd = function(url)
				-- os.execute(fmt('open "%s"', url))
				os.execute(fmt('%s "%s"', mac_browser, url))
			end
		else
			_open_cmd = function(url)
				-- os.execute(fmt('xdg-open "%s"', url))
				os.execute(fmt('%s "%s"', linux_browser, url))
			end
		end
	end
	_open_cmd(url)
end
-- ^^^^^^^^^^^ from dkjson 2.8 (at the end of this source file) ^^^^^^^^^^^ --

function help(w)
	local lua_manual_url = 'file:///' .. doc_folder .. 'manual.html'
	local mathly_manual_url = 'file:///' .. doc_folder .. 'mathly.html'
	local mathq = ismember(w, {'abs', 'acos', 'acot', 'asin', 'atan', 'ceil', 'cos', 'cot', 'csc', 'deg', 'e',
		'eps', 'exp', 'floor', 'log', 'log10', 'phi', 'pi', 'rad', 'random', 'sec', 'sin', 'sqrt', 'tan'})
	local basics = {'_G', '_VERSION', 'assert', 'collectgarbage', 'dofile', 'error', 'getmetatable', 'ipairs',
		'load', 'loadfile', 'next', 'pairs', 'pcall', 'print', 'rawequal', 'rawget', 'rawlen', 'rawset', 'require',
		'select', 'setmetatable', 'tonumber', 'tostring', 'type', 'warn', 'xpcall', -- at beginning of the Index in lua5_5.html

		'do', 'else', 'end', 'f', 'file', 'function', 'goto', 'if', 'io', 'math', 'os', 're', 'regex',
		'repeat', 'string', 'table', 'then', 'until', 'while'} -- extra anchors added in manual.html
	local url
	if mathq then
			url = mathly_manual_url .. '#math'
	else
		if ismember(w:sub(1, 4), {'lua_', 'luaL'}) then
			url = lua_manual_url .. '#' .. w
		else
			local f = w:match('[:|%.](.+)')
			if f then
				url = lua_manual_url .. '#pdf-' .. f
			elseif ismember(w, basics) then
				url = lua_manual_url .. '#pdf-' .. w
			else
				url = mathly_manual_url .. '#' .. w
			end
		end
	end
	_open_url(url)
end

-- manipulate/animate interactively the graph of f(x) with 'controls' and enhancements
function manipulate(f, opts) -- Mathematica
	_anmt_animateq, _anmt_act = false, 'manipulate'
	local cs, rs, xr, yr, tr, title, xexpr, yexpr, jxexpr, jyexpr, enhancements, jscode = _anmt_parse_args(f, opts)
	_write_manipulate_html(tmp_plot_html_file, cs, rs, xr, yr, tr, title, xexpr, yexpr, jxexpr, jyexpr, enhancements, jscode, opts)
	_open_url(tmp_plot_html_file)
	print("The graph is in " .. tmp_plot_html_file .. ' if you need it.')
end

function animate(f, opts) -- Mathematica
	_anmt_animateq, _anmt_act = true, 'animate'
	local cs, rs, xr, yr, tr, title, xexpr, yexpr, jxexpr, jyexpr, enhancements, jscode = _anmt_parse_args(f, opts)
	_write_manipulate_html(tmp_plot_html_file, cs, rs, xr, yr, tr, title, xexpr, yexpr, jxexpr, jyexpr, enhancements, jscode, opts)
	_open_url(tmp_plot_html_file)
	print("The graph is in " .. tmp_plot_html_file .. ' if you need it.')
end

-- scan a string and replace each appearance of a ctrl with its val
function _tables_replace(str, cs, vs) -- must be GLOBAL
	local function scan_replace(ctrl, val)
		local i, v, cpt = 1, '', '' -- captured
		while i <= #str do
			local c = str:sub(i, i)
			while i <= #str and ((c >= 'a' and c <= 'z') or (c >= 'A' and c <= 'Z') or (c >= '0' and c <= '9')) do
				cpt = cpt .. c
				i = i + 1; c = '' -- c processed
				if i <= #str then c = str:sub(i, i) end
			end
			if cpt ~= '' then
				if cpt == ctrl then
					v = v .. tostring(val) -- a ctrl can only be a number
				else
					v = v .. cpt
				end
				cpt = ''
			end
			if c ~= '' then v = v .. c end
			i = i + 1
		end
		return v
	end
	for i = 1, #cs do str = scan_replace(cs[i], vs[i]) end
	return str
end

function table1(str, opts) -- Mathematica
	local cs, rs, fmt = {}, {}, string.format	-- controls & their ranges
	local function cs_values_str()
		local cstr, vstr = '{', '{'
		for i = 1, #cs do
			if i > 1 then cstr = cstr .. ', '; vstr = vstr .. ', ' end
			cstr = cstr .. "'" .. cs[i] .. "'"
			vstr = vstr .. cs[i]
		end
		return cstr .. '}', vstr .. '}'
	end
	if opts == nil then opts = {} end
	-- scan for controls in str and set their ranges from opts
	if type(opts.controls) == 'string' then -- order of controls is in this string explicitly
		for i = 1, #opts.controls do
			_anmt_new_control(opts.controls:sub(i, i), cs, rs, opts)
		end
	elseif type(str) == 'string' and str:sub(1, 1) ~= '!' then -- order of controls is in str implicitly
		_anmt_scan_controls(str, cs, rs, opts)
	end
	if #cs == 0 then
		for k, v in pairs(opts) do
			if type(k) == 'string' then _anmt_new_control(k, cs, rs, opts) end
		end
		if #cs == 0 then print("No controls are specified."); return end
	end
	-- generate Lua code
	local c, idx = '', 1 -- c: code
	for i = 1, #cs do c = c .. fmt('local t%d = {}\n', i) end
	local function luacode(i)
		local head = ''; for j = 2, i do head = head .. '  ' end
		local t = fmt('t%d', idx); idx = idx + 1
		local T = fmt('t%d', idx)
		c = c .. head .. 'for ' .. cs[i] .. ' = ' .. tostring(rs[i][1]) .. ', ' .. tostring(rs[i][2]) ..', ' .. tostring(rs[i][3]) .. ' do\n'
		if i == #rs then
			c = c .. head .. fmt("  %s[#%s + 1] = ", t, t)
			local ty = type(str)
			if ty == 'number' then
				c = c .. tostring(str)
			elseif ty == 'string' then
				if str:sub(1, 1) == '!' then -- '!a+b' will be "a+b" without evaluation
					if type(opts.controls) == 'string' then
						local cstr, vstr = cs_values_str()
						c = c .. "_tables_replace('" .. str:sub(2) .. "', " .. cstr .. ", " .. vstr .. ")"
					else
						c = c .. "'" .. str:sub(2) .. "'"
					end
				else
					c = c .. str
				end
			elseif ty == 'boolean' then
				c = c .. qq(str, 'true', 'false')
			else
				error("mytable(expr, ...): expr can't be a table, but you may use a string, e.g., '{1, 2, 3}' and '{1, i, {3, {j - 1}}, 5}'.")
			end
			c = c .. '\n'
		else
			luacode(i + 1)
			c = c .. head .. fmt('  %s[#%s + 1] = %s; %s = {}\n', t, t, T, T)
		end
		c = c .. head .. "end\n"
	end
	luacode(1)
	c = c .. "return t1\n"
	if opts.printcode == true then print(c) end
	-- run generated Lua code dynamically
	local stat, v = pcall(load, c)
	if stat then stat, v = pcall(v) end
	return v
end -- table1
tables = table1 -- deprecated

local function _freq_distro(x, nbins, xmin, xmax, width)
	nbins = nbins or 10
	x = sort(x)
	local freqs, x1, j = {}, xmin, 1
	for k = 1, nbins do
		freqs[k] = 0
		local x2 =	x1 + width
		while j <= #x do
			if x[j] < x2 then
				freqs[k] = freqs[k] + 1
				j = j + 1
			else
				break
			end
		end
		freqs[k] = freqs[k] / #x -- relative freq
		x1 = x2
	end
	return freqs
end

-- if x is a table of tables/rows, each row is a data set; otherwise, x is a table and a single data set.
function hist(x, nbins, style, xrange)
	local args = namedargs(
		{x, nbins, style, xrange},
		{'x', 'nbins', 'style', 'xrange'})
	x, nbins, style, xrange = args[1], args[2], args[3], args[4]

	if type(x) == 'table' then
		if type(x[1]) ~= 'table' then x = { x } end
	else
		error('hist(x, ...): x must be a table.')
	end

	local xmin, xmax, width
	local g, freqs = {'graph-hist'}, {} -- special graph object, https://plotly.com/javascript/bar-charts/
	local allintq = all(x, isinteger, false) == 1
	nbins = nbins or 10

	if xrange ~= nil then
		xmin, xmax = _plot_interval(xrange[1], xrange[2])
	else
		local tmp = flatten(x)
		xmin, xmax = min(tmp), max(tmp)
	end
	if allintq then
		width = math.ceil((xmax - xmin + 1) / nbins)
	else
		width = (xmax - xmin) / nbins
	end

	for i = 1, #x do
		freqs[i] = _freq_distro(x[i], nbins, xmin, xmax, width)
	end

	local labels = {}
	local x1 = xmin
	for i = 1, nbins do
		local x2 = x1 + width
		if allintq then
			labels[#labels + 1] = sprintf("[%d, %d]", x1, x2 - 1)
		else
			labels[#labels + 1] = sprintf("[%.4f, %.4f)", x1, x2)
		end
		x1 = x2
	end

	for j = 1, #x do
		g[#g + 1] = labels
		g[#g + 1] = freqs[j]
	end
	return g
end -- hist

local function _xmin_xmax_width(x, xrange, nbins, allintq)
	local xmin, xmax, width
	if xrange ~= nil then
		xmin, xmax = _plot_interval(xrange[1], xrange[2])
	else
		xmin, xmax = x[1], x[#x]
	end
	if allintq then
		width = math.ceil((xmax - xmin + 1) / nbins)
	else
		width = (xmax - xmin) / nbins
	end
	return xmin, xmax, width
end

-- another version of histogram, as see in most textbooks
-- the output can be treated as an ordinary graph object such as a curve
function hist1(x, nbins, style, xrange, freqpolygonq, style1, histq) -- style1: for freqpolygon
	local args = namedargs(
		{x, nbins, style, xrange, freqpolygonq, style1, histq},
		{'x', 'nbins', 'style', 'xrange', 'freqpolygonq', 'style1', 'histq'})
	x, nbins, style, xrange, freqpolygonq, style1, histq = args[1], args[2], args[3], args[4], args[5], args[6], args[7]

	if histq == nil then histq = true end
	nbins = nbins or 10
	x = sort(flatten(x))
	local xmin, xmax, width = _xmin_xmax_width(x, xrange, nbins, all(x, isinteger) == 1)
	local freqs = _freq_distro(x, nbins, xmin, xmax, width)
	local g, x1, freqp_xy = {'graph'}, xmin, {{xmin - width / 2}, {0}}
	for i = 1, nbins do
		local x2 = x1 + width
		if histq then
			local gobj = polygon({{x1, 0}, {x1, freqs[i]}, {x2, freqs[i]}, {x2, 0}}, style)
			g[#g + 1] = gobj[2]
			g[#g + 1] = gobj[3]
			g[#g + 1] = gobj[4]
		end
		if freqpolygonq then
			freqp_xy[1][i + 1], freqp_xy[2][i + 1] = x1 + width / 2, freqs[i]
		end
		x1 = x2
	end
	if freqpolygonq then
		freqp_xy[1][nbins + 2] = x1 + width / 2
		freqp_xy[2][nbins + 2] = 0
	end

	if freqpolygonq then
		style1 = style1 or '-ro'
		g[#g + 1] = freqp_xy[1]
		g[#g + 1] = freqp_xy[2]
		g[#g + 1] = style1
		for i = 1, nbins + 2 do -- points
			g[#g + 1] = {freqp_xy[1][i]}
			g[#g + 1] = {freqp_xy[2][i]}
			g[#g + 1] = style1
		end
	end
	return g
end -- hist1

-- data = {{label1, value1}, {label2, value2}, ..., {namen, valuen}}
function pareto(data, style, style1) -- style1: for freq curve
	local args = namedargs(
		{data, style, style1},
		{'data', 'style', 'style1'})
	data, style, style1 = args[1], args[2], args[3]

	if style == nil then style = '-fs' end
	if style1 == nil then style1 = '-ro' end

	local total = 0
	local dat = {}
	for i = 1, #data do
		total = total + data[i][2]
		dat[i] = data[i]
	end
	for i = 1, #dat - 1 do -- sort data by values from highest to lowest; same data set, no performance issue
		local maxi, maxx = i, dat[i][2]
		for j = i + 1, #dat do
			if dat[j][2] > maxx then maxi, maxx = j, dat[j][2] end
		end
		if maxi ~= i then
			dat[i], dat[maxi] = dat[maxi], dat[i]
		end
	end
	local freqs = {}
	for i = 1, #dat do
		freqs[i] = dat[i][2] -- / total
	end

	local g, x1, freqxy, width = {'pareto'}, 0, {{0}, {0}}, 20
	for i = 1, #dat do
		local x2 = x1 + width
		local gobj = polygon({{x1, 0}, {x1, freqs[i]}, {x2, freqs[i]}, {x2, 0}}, style)
		g[#g + 1] = gobj[2]
		g[#g + 1] = gobj[3]
		g[#g + 1] = gobj[4]
		freqxy[1][i + 1] = x2
		freqxy[2][i + 1] = freqxy[2][i] + freqs[i]
		x1 = x2
	end

	g[#g + 1] = freqxy[1]
	g[#g + 1] = freqxy[2]
	g[#g + 1] = style1
	for i = 1, #dat + 1 do -- points
		g[#g + 1] = {freqxy[1][i]}
		g[#g + 1] = {freqxy[2][i]}
		g[#g + 1] = style1 -- {symbol='circle', size=8, color='red'}
	end

	x1 = 0 -- 'plot' the names
	local texts = {}
	local shiftx, shifty = width * 0.4, dat[1][2]*0.04
	for i = 1, #dat do
		local shift = (width - #dat[i][1])/2
		if shift < shiftx then shift = shiftx end
		texts[i] = text(x1 + shift, -shifty, data[i][1])
		x1 = x1 + width
	end

	x1 = #dat * width + shiftx
	local n, percent = 5, 20
	if #dat > 10 then n, percent = 10, 10 end
	for i = 1, n do
		local scale = i * percent
		local y1 = (scale / 100) * total + shifty
		texts[#texts + 1] = text(x1, y1, tostring(scale) .. '%')
	end

	local names = {}
	for i = 1, #dat * 5 do names[i] = '' end
	g[#g + 1] = {names = names}

	g[#g + 1] = texts
	shownotxaxis(); shownotlegend()
	return g
end -- pareto

function freqpolygon(x, nbins, style, xrange)
	local args = namedargs(
		{x, nbins, style, xrange},
		{'x', 'nbins', 'style', 'xrange'})
	x, nbins, style, xrange = args[1], args[2], args[3], args[4]
	return hist1(x, nbins, nil, xrange, true, style, false)
end

function histfreqpolygon(x, nbins, style, xrange, style1)
	local args = namedargs(
		{x, nbins, style, xrange, style1},
		{'x', 'nbins', 'style', 'xrange', 'style1'})
	x, nbins, style, xrange, style1 = args[1], args[2], args[3], args[4], args[5]
	return hist1(x, nbins, style, xrange, true, style1, true)
end

-- if x is a table of tables/rows, each row is a data set; otherwise, x is a table and a single data set.
function boxplot(x, names)
	local args = namedargs({x, names}, {'x', 'names'})
	x, names = args[1], args[2]

	if type(x) == 'table' then
		if type(x[1]) ~= 'table' then x = { x } end
	else
		error('boxplot(x, ...): x must be a table.')
	end

	local g = {'graph-box'} -- special graph object, https://plotly.com/javascript/bar-charts/
	g[2] = 'x' -- horizontal -- gobj: {'graph-box', 'x', data...}, 'x' or 'y'
	if #x > 3 then g[2] = 'y' end -- vertical
	for j = 1, #x do
		g[j + 2] = x[j]
	end
	if names ~= nil then g[#g + 1] = names end
	return g
end

function pie(x, nbins, style, names, title)
	local args = namedargs({x, nbins, style, names, title}, {'x', 'nbins', 'style', 'names', 'title'})
	x, nbins, style, names, title = args[1], args[2], args[3], args[4], args[5]

	_axis_equalq, _xaxis_visibleq, _yaxis_visibleq, _gridline_visibleq, _showlegendq = true, false, false, false, false
	local freqs, xmin, xmax, width
	local binsq = x['bins'] ~= nil -- x = {bins = {freq1, freq2, ...}}
	local namesq = type(names) == 'table'
	local allintq = all(x, isinteger, false) == 1
	if binsq then
		freqs = x['bins']
		freqs = tt(rr(freqs) / sum(freqs))
		nbins = #freqs
	else
		if nbins == nil then
			if namesq then nbins = #names else nbins = 10 end
		end
		x = flatten(x)
		if nbins >= #x then
			freqs = tt(rr(x) / sum(x)); nbins = #x
			binsq = true
		else
			x = sort(x)
			xmin, xmax, width = _xmin_xmax_width(x, nil, nbins, allintq)
			freqs = _freq_distro(x, nbins, xmin, xmax, width)
		end
	end

	local labels = {}
	for i = 1, nbins do
		if namesq and i <= #names then
			labels[i] = names[i]
		elseif binsq then
			labels[i] = 'class ' .. i
		else
			local x2 = xmin + width
			if allintq then
				labels[i] = sprintf("[%d, %d]", xmin, x2 - 1)
			else
				labels[i] = sprintf("[%.2f, %.2f)", xmin, x2)
			end
			xmin = x2
		end
	end

	local gobj = {type = 'pie', values = freqs, labels = labels, textinfo = "label+percent", hoverinfo = 'label+percent'}
	gobj = merge(style, gobj)
	if title ~= nil then gobj.layout = {title = {text = title}} end
	return gobj
end -- pie

--// plot a wedge of a disk/circle
-- radius: r
-- center: center {x, y}
-- angles: {angle1, angle2}
function wedge(r, center, angles, style, wedgeq)
	local args = namedargs(
		{r, center, angles, style, wedgeq},
		{'r', 'center', 'angles', 'style', 'wedgeq'})
	r, center, angles, style, wedgeq = args[1], args[2], args[3], args[4], args[5]

	center = center or {0, 0}
	angles = _plot_interval(angles or {0, 2*pi})
	if wedgeq == nil then wedgeq = true end
	local theta = angles[2] - angles[1]
	local arcpts = math.ceil(300 * theta/(2*pi))
	local inc, x, y, k = theta / arcpts, {}, {}, 1
	theta =	angles[1]
	if wedgeq then
		x[1], y[1] = center[1], center[2]
		k = k + 1
	end
	for i = 1, arcpts + 1 do
		x[k], y[k] = center[1] + r * math.cos(theta), center[2] + r * math.sin(theta)
		k = k + 1
		theta = theta + inc
	end
	local data, opt = {'graph'}, '-'
	if wedgeq then
		x[k], y[k] = center[1], center[2]
		opt = '-fs'
	end
	data[2], data[3], data[4] = x, y, qq(style == nil, opt, style)
	return data
end

--// plot an arc of a circle
-- radius: r
-- center: center {x, y}
-- angles: {angle1, angle2}
function arc(r, center, angles, style)
	local args = namedargs(
		{r, center, angles, style},
		{'r', 'center', 'angles', 'style'})
	r, center, angles, style = args[1], args[2], args[3], args[4]

	return wedge(r, center, angles, style, false)
end

function circle(r, center, style)
	local args = namedargs(
		{r, center, style},
		{'r', 'center', 'style'})
	r, center, style = args[1], args[2], args[3]

	if center == nil then center = {0, 0} end
	return arc(r, center, {0, 2*pi}, style)
end

function polygon(xy, style)
	local args = namedargs({xy, style}, {'xy', 'style'})
	xy, style = args[1], args[2]

	local x, y = {}, {}
	local k = 1
	for i = 1, #xy do
		x[k], y[k] = xy[i][1], xy[i][2]
		k = k + 1
	end
	x[k] = xy[1][1]
	y[k] = xy[1][2]
	local data = {'graph', x, y}
	data[4] = style or '-fs'
	return data
end

function line(point1, point2, style)
	local args = namedargs({point1, point2, style}, {'point1', 'point2', 'style'})
	point1, point2, style = args[1], args[2], args[3]

	local data = {'graph', {point1[1], point2[1]}, {point1[2], point2[2]}}
	if style == nil then data[4] = '-' else data[4] = style end
	return data
end

-- style: e.g., {symbol='circle-open', size=10, color='blue'}
function point(x, y, style)	-- plot a point at (x, y)
	local args = namedargs({x, y, style}, {'x', 'y', 'style'})
	x, y, style = args[1], args[2], args[3], args[4], args[5], args[6], args[7]

	if type(x) == 'number' then
		x, y = {x}, {y}
	else
		local X, Y = _poly_input(x)
		if #X ~= 0 then style = y; x, y = X, Y end
	end
	assert(type(x) == 'table' and type(y) == 'table' and #x == #y, 'point(x, y ...): x and y must be two numbers or two tables of the same size.')

	local data = {'graph'}
	for i = 1, #x do
		data[#data + 1] = {x[i]}
		data[#data + 1] = {y[i]}
		if style == nil then
			data[#data + 1] = {symbol='circle', size=8, showlegend = false}
		else
			data[#data + 1] = style
		end
	end
	return data
end

-- write text txt at (x, y) on a graph)
--
-- style: {family = 'sans serif', size = 18, color = '#ff0000'}
function text(x, y, txt, style)
	local args = namedargs(
		{x, y, txt, style},
		{'x', 'y', 'txt', 'style'})
	x, y, txt, style = args[1], args[2], args[3], args[4]

	style = style or {color = 'black'}
	local trace = {{x}, {y}}
	trace['text'] = txt
	trace['textfont'] = style
	trace['mode'] = 'text'
	trace['type'] = 'scatter'
	trace['textposition'] = 'bottom'
	trace['name'] = ''
	return {'text', trace}
end

-- xy = {x(t), y(t)}
function parametriccurve2d(xy, trange, style, resolution, orientationq)
	local args = namedargs(
		{xy, trange, style, resolution, orientationq},
		{'xy', 'trange', 'style', 'resolution', 'orientationq'})
	xy, trange, style, resolution, orientationq = args[1], args[2], args[3], args[4], args[5]

	trange = _plot_interval(trange or {-5, 5})
	resolution = _set_resolution(resolution)
	local data = {'graph'}
	local ts = linspace(trange[1], trange[2], math.max(math.ceil((trange[2] - trange[1]) * 50), resolution))

	for i = 1, 2 do
		if type(xy[i]) == 'string' then xy[i] = ff(xy[i]) end
	end

	data[2] = map(xy[1], ts)
	data[3] = map(xy[2], ts)
	ts = nil
	if style == nil then
		data[4] = '-'
	else
		data[4] = style
	end
	if orientationq then
		local points = {}
		local n, siz, t = 7, 12, trange[1]
		local h = (trange[2] - trange[1]) / (2 * n)
		for i = 1, n do
			points[i] = {{xy[1](t)}, {xy[2](t)}, {symbol='circle', size=siz, color='blue', opacity = 0.8, showlegend = false}}
			siz, t = siz - 1.25, t + h
		end
		data[5] = points
	end
	return data
end -- parametriccurve2d

-- r(θ), a polar function
function polarcurve(r, trange, style, resolution, orientationq)
	local args = namedargs(
		{r, trange, style, resolution, orientationq},
		{'r', 'trange', 'style', 'resolution', 'orientationq'})
	r, trange, style, resolution, orientationq = args[1], args[2], args[3], args[4], args[5]

	if type(r) == 'number' then
		local f = r
		r = function(t) return f end
	elseif type(r) == 'string' then
		r = ff(r)
	end
	return parametriccurve2d({
			function(t) return r(t) * math.cos(t) end,
			function(t) return r(t) * math.sin(t) end
		}, trange or {0, 2*pi}, style, resolution, orientationq)
end

function plotpolarcurve(r, trange, style, resolution, orientationq)
	plot(polarcurve(r, trange, style, resolution, orientationq))
end

-- x and y are tables of the same size
function scatter(x, y, style)
	local args = namedargs(
		{x, y, style},
		{'x', 'y', 'style'})
	x, y, style = args[1], args[2], args[3]

	local X, Y = _poly_input(x)
	if #X ~= 0 then style = y; x, y = X, Y end
	x = flatten(x)
	y = flatten(y)
	assert(#x == #y, 'scatter(x, y): x and y must be tables of the same size.')
	local data = {'graph', x, y}
	if style == nil then
		data[4] = {symbol='circle-open', size=8, showlegend = false}
	else
		data[4] = style
	end
	return data
end

function dotplot(x, y, style)
	local args = namedargs(
		{x, y, style},
		{'x', 'y', 'style'})
	x, y, style = args[1], args[2], args[3]
	if style == nil or type(style) ~= 'table' then
		style = { size = 8, symbol = 'circle', opacity = 1 }
	end
	return { 'dotplot', {x = x, y = y, mode = 'markers', marker = style }}
end

-- x and y are tables of the same size
function contourplot(f, x, y, style)
	local args = namedargs(
		{f, x, y, style},
		{'f', 'x', 'y', 'style'})
	f, x, y, style = args[1], args[2], args[3], args[4]
	local function data(x)
		if type(x) ~= 'table' then
			error('contourplot(f, x, y, style): x and y must be ranges or tables of numbers.')
		end
		x = flatten(x)
		if #x <= 3 then
			return linspace(x[1], x[2], x[3] or 200)
		else
			return x
		end
	end
	if type(f) == 'string' then f = ff(f) end
	if x == nil then x = {-5, 5} end
	x = data(x)
	if y == nil then y = x else y = data(y) end
	local z = {}
	for i = 1, #y do
		z[i] = {}
		for j = 1, #x do
			z[i][j] = f(x[j], y[i])
		end
	end
	return {'contour', x, y, z, style or {colorscale = 'Jet', contours = {coloring = 'lines'}}}
end

-- dy/dx = f(x, y)
function slopefield(f, xrange, yrange, scale)
	local args = namedargs(
		{f, xrange, yrange, scale},
		{'f', 'xrange', 'yrange', 'scale'})
	f, xrange, yrange, scale = args[1], args[2], args[3], args[4]

	if type(f) == 'string' then f = ff(f) end
	xrange = _plot_interval(xrange or {-5, 5, 0.5})
	yrange = _plot_interval(yrange or xrange)
	if type(f) ~= 'function' or type(xrange) ~= 'table' or type(yrange) ~= 'table' then
		error('slopefield(f, xrange, yrange, scale): f is a function as in dy/dx = f(x, y), xrange and yrange are of the format {begin, end, step}.')
	end
	scale = scale or 1
	if scale < 0 then scale = -scale end
	local len = (xrange[2] - xrange[1]) / 50 * scale -- length of a dash
	local k, dashes = 1, {}
	for x = xrange[1], xrange[2], xrange[3] do
		for y = yrange[1], yrange[2], yrange[3] do
			local slope = f(x, y)
			local xinc = len / math.sqrt(1 + slope^2)
			local by = y + slope * xinc
			xinc = xinc / 2 -- place the dash to the midpoint
			dashes[k] = line({x - xinc, y}, {x + xinc, by}, {width=0.5, color='black'})
			k = k + 1
		end
	end
	return {'slopefield', xrange, dashes}
end

directionfield = slopefield

-- f(x, y) returns a vector {xcomponent, ycomponent}
function vectorfield2d(f, xrange, yrange, scale)
	local args = namedargs(
		{f, xrange, yrange, scale},
		{'f', 'xrange', 'yrange', 'scale'})
	f, xrange, yrange, scale = args[1], args[2], args[3], args[4]

	if type(f) == 'string' then f = ff(f) end
	xrange = _plot_interval(xrange or {-5, 5, 0.5})
	yrange = _plot_interval(yrange or xrange)
	if type(f) ~= 'function' or type(xrange) ~= 'table' or type(yrange) ~= 'table' then
		error('vectorfield2d(f, xrange, yrange, scale): f is a vector function, xrange and yrange are of the format {begin, end, step}.')
	end
	scale = scale or 5
	if scale < 0 then scale = -scale end
	local k, annotations = 1, {}
	for x = xrange[1], xrange[2], xrange[3] do
		for y = yrange[1], yrange[2], yrange[3] do
			local v = f(x, y)
			annotations[k] = {
				x = x, y = y, -- head
				-- axref = 'pixel', yxref = 'pixel',
				ax = -v[1] * scale, ay = v[2] * scale,	-- tail
				-- if axref is "pixel" (deafult?), ax is specified in pixels relative to x. ax > 0 moves the tail to the right; otherwise, to the left.
				-- if ayref is 'pixel', ay is specified in pixels relative to y. ay > 0 moves the tail upwards; otherwise, downwards.
				showarrow = true, text = '',
				arrowhead = 1, -- default: 1 - a simple line arrowhead; 5 - a simple line, angled arrowhead
				arrowsize = 1, arrowwidth = 0.8, arrowcolor = 'black'
			}
			k = k + 1
		end
	end
	return {'vectorfield2d', xrange, annotations}
end -- vectorfield2d

function axissquare()		_axis_equalq = true	end
function axisnotsquare() _axis_equalq = false end

function showaxes()		_xaxis_visibleq = true;	_yaxis_visibleq = true	end
function shownotaxes() _xaxis_visibleq = false; _yaxis_visibleq = false end

function showxaxis()		_xaxis_visibleq = true	end
function shownotxaxis() _xaxis_visibleq = false end
function showyaxis()		_yaxis_visibleq = true	end
function shownotyaxis() _yaxis_visibleq = false end

function showgridlines()		_gridline_visibleq = true end
function shownotgridlines() _gridline_visibleq = false end

function showlegend()		_showlegendq = true	end
function shownotlegend() _showlegendq = false end

-- transpose a matrix
function transpose(A)
	_mathly_matrix(A, 'transpose(A)')
	local B = {}
	local m, n = size(A)
	if type(A[1]) ~= 'table' then -- m == 1
		for i = 1,n do B[i] = { A[i] } end
	else
		for i = 1,n do
			B[i] = {}
			for j = 1,m do B[i][j] = A[j][i] end
		end
	end
	return _set_matrix_meta(B)
end

local function _rrefb(b) -- b ~= nil
	local q = type(b) ~= 'table'
	if not q then
		if type(b[1]) ~= 'table' then
			b = cc(b)
		elseif getmetatable(b) ~= mathly_meta then
			if ismatrix(b) then
				setmetatable(b, mathly_meta)
			else
				q = true
			end
		end
	end
	return b, q
end

-- calculate the reduced row-echlon form of matrix A
-- if B is provided, it works on [ A | B]; useful for finding the inverse of A or
-- solving Ax = b by rref [ A | b ]
function rref(a, b) -- gauss-jordan elimination
	_mathly_matrix(a, 'rref(A)')
	local bq = b ~= nil
	if bq then b, bq = _rrefb(b) end
	if bq then error('rref(A, B): B must be a vector or a matrix') end

	local rows, columns = size(a)
	local ROWS = math.min(rows, columns)

	local bcolumns = 0
	if b ~= nil then
		bq = true
		assert(#b == rows, 'rref(A, B): A and B must have the same number of rows.')
	end

	local A = copy(a) -- 4/23/25
	local B = copy(b) --
	if bq then
		if type(B[1]) ~= 'table' then B = cc(B) end
		bcolumns = #B[1]
	end

	local abs = math.abs
	for i = 1, ROWS do
		local largest = abs(A[i][i]) -- choose the pivotal entry
		local idx = i
		for j = i + 1, rows do
			local tmp = abs(A[j][i])
			if tmp > largest then
				idx, largest = j, tmp
			end
		end

		if largest > 1e-15 then -- none-zero
			if i ~= idx then -- interchange the two rows
				A[i], A[idx] = A[idx], A[i]
				if bq then B[i], B[idx] = B[idx], B[i] end
			end

			largest = A[i][i]	-- 'normalize' the row: 0 ... 0 1 x x x
			A[i][i] = 1
			for j = i + 1, columns do
				A[i][j] = A[i][j] / largest
			end
			if bq then B[i] = B[i] / largest end

			for j = i + 1, rows do -- eliminate entries below A[i][i]
				local Aji = A[j][i]
				for k = i, columns do
					A[j][k] = A[j][k] - A[i][k] * Aji
				end
				if bq then
					for n = 1, #B[1] do B[j][n] = B[j][n] - B[i][n] * Aji end
				end
			end
		end
	end

	for i = ROWS, 2, -1 do
		local m = i
		if A[i][i] ~= 1 then -- A[i][i] must be 0, find the 1st none-zero entry
			j = i + 1
			while j <= columns and abs(A[i][j]) < 1e-15 do
				j = j + 1
			end
			if j <= columns then -- found it
				m = j
				local Aij = A[i][j]	 -- 'normalize' the row, 0...0 1 xxx
				while j <= columns do
					A[i][j] = A[i][j] / Aij
					j = j + 1
				end
				if bq then B[i] = B[i] / Aij end
			else
				m = columns + 1
			end
		end

		if m <= columns then -- eliminate entries above A[i][m]
			for j = i - 1, 1, -1 do
				local Ajm = A[j][m]
				for k = m, columns do
					A[j][k] = A[j][k] - A[i][k] * Ajm
				end
				if bq then
					for n = 1, #B[1] do B[j][n] = B[j][n] - B[i][n] * Ajm end
				end
			end
		end
	end
	if bq then
		if type(B[1]) == 'table' and #B[1] == 1 then B = B^T end
		return A, B
	else
		return A
	end
end -- rref

-- solve Ax = b and return x: A is square
function linsolve(A, b, opt)
	_mathly_matrix(A, 'linsolve(A)')
	local B = b
	if b ~= nil then
		local q
		B, q = _rrefb(B)
		if q then error('linsolve(A, b): b must be a vector or a matrix.') end
	else
		error('linsolve(A, b): b is not provided.')
	end

	if opt ~= 'UT' and opt ~= 'LT' then
		local v1, v2 = rref(A, B)
		return v2
	end

	local m, n = size(A)
	assert(m == n and n == #B, 'linsolve(A, b, ...): A must be square and the dimensions of A and b must match.')
	local y = zeros(m, #B[1])
	for j = 1, #B[1] do
		if opt == 'UT' then -- back substitution
			y[n][j] = B[n][j] / A[n][n]
			for i = n - 1, 1, -1 do
				local s = B[i][j]
				for k = i + 1,	n do s = s - A[i][k] * y[k][j] end
				y[i][j] = s / A[i][i]
			end
		else -- forward substitution
			y[1][j] = B[1][j] / A[1][1]
			for i = 2, n do
				local s = B[i][j]
				for k = 1, i - 1 do s = s - A[i][k] * y[k][j] end
				y[i][j] = s / A[i][i]
			end
		end
	end
	if #y[1] == 1 then y = tt(y) end
	return _set_matrix_meta(y)
end -- linsolve

-- calculate the inverse of matrix A
-- rref([A | I]) gives [ I | B ], where B is the inverse of A
function inv(A)
	_mathly_matrix(A, 'inv(A)')
	local rows, columns = size(A)
	assert(rows == columns, 'inv(A): A must be square.')
	local v1, v2 = rref(A, eye(rows))
	return v2
end

-- return rows and columns of matrix A, given that A is a valid vector, matrix, string, or a number.
function size(A)
	if type(A) == 'table' then
		if type(A[1]) == 'table' then
			return #A, #A[1]
		else
			return 1, #A
		end
	elseif type(A) == 'string' then
		return 1, #A
	else
		return 1, 1
	end
end

-- Return a mxn block matrix with each entry a copy of matrix A.
function repmat(A, m, n)
	local B = A
	if getmetatable(A) ~= mathly_meta then
		if type(A) == 'table' then
			B = mathly(A)
		else
			B = {{A}}
		end
	end
	if n == nil then n = m end

	local C = {}
	local row, col = size(B)
	for i = 1, m * row do C[i] = {} end
	for i = 1, m do
		local tmp1 = (i - 1) * row + 1
		for j = 1, n do
			local I = tmp1
			local tmp2 = (j - 1) * col + 1
			for ii = 1, row do
				local J = tmp2
				for jj = 1, col do
					C[I][J] = B[ii][jj]
					J = J + 1
				end
				I = I + 1
			end
		end
	end
	return _set_matrix_meta(C)
end

-- flipud - Return a matrix with rows of matrix A reversed (upside down)
-- fliplr - Return a matrix with columns of matrix A reversed (from left to right)
function flipud(A) local a = rr(A, range(#A, 1, -1));		return _set_matrix_meta(a) end
function fliplr(A) local a = cc(A, range(#A[1], 1, -1)); return _set_matrix_meta(a) end

-- reverse and return a table. if it is a matrix, it is flattened columnwisely first to a table and then reversed
function reverse(t)
	if type(t) == 'string' then
		return string.reverse(t)
	else
		return tt(t, {-1, 1, -1})
	end
end

function sort(t, compf)
	if type(compf) == 'string' then compf = ff(compf) end
	table.sort(t, compf)
	if isvector(t) then t = _set_matrix_meta(t) end
	return t
end

-- Make A a lower (opt = 'LT'), upper ('UT'), or symmetric ('SYM') matrix by replacing entries with 0's or so
function remake(A, opt)
	_mathly_matrix(A, 'remake(A, ...)')
	local B
	local m, n = size(A)
	local minn = math.min(m, n)
	if opt == 'UT' then
		B = zeros(m, n)
		if m == 1 then B = rr(B) end
		for i = 1, m do
			for j = i, n do
				B[i][j] = A[i][j]
			end
		end
	elseif opt == 'LT' then
		B = zeros(m, n)
		if m == 1 then B = rr(B) end
		for i = 1, m do
			for j = 1, math.min(i, n) do
				B[i][j] = A[i][j]
			end
		end
	elseif opt == 'SYM' then
		B = {}
		for i = 1, minn do
			B[i] = {}
			for j = i, minn do
				B[i][j] = A[i][j]
			end
		end
		for i = 2, minn do
			for j = 1, i - 1 do
				B[i][j] = B[j][i]
			end
		end
	elseif opt == 'DIAG' then
		B = diag(diag(A))
	elseif type(opt) == 'table' and type(opt[1]) == 'number' then
		local opts = unique(flatten(opt))
		B = zeros(m, n)
		if m == 1 then B = rr(B) end
		local I, J
		for k = 1, #opts do
			for i = 1, m do
				I = i - opts[k]
				for j = i, n do
					if I > 0 and I <= m then
						B[I][j] = A[I][j]
					end
					I = I + 1
				end
			end
		end
	else
		B = A
	end
	return _set_matrix_meta(B)
end -- remake

-- use entries of matrix A to generate a new mxn matrix, given that A is a valid vector or matrix
function reshape(A, m, n)
	local rows, columns = size(A)
	local total = rows * columns
	if n == nil then n = math.ceil(total / m) end

	local t
	if rows == 1 or columns == 1 then
		t = flatten(A)
	else
		t = {}
		for j = 1, columns do
			for i = 1, rows do
				t[#t + 1] = A[i][j]
			end
		end
	end

	local k = 1
	local B = {}
	for i = 1, m do B[i] = {} end
	for j = 1, n do
		for i = 1, m do
			if k <= total then
				B[i][j] = t[k]
				k = k + 1
			else
				B[i][j] = 0
			end
		end
	end
	return setmetatable(B, mathly_meta)
end -- reshape

-- return the number of rows of a matrix
function length(A)
	if type(A) == 'table' and type(A[1]) == 'table' and #A == 1 then
		return length(A[1]) -- mathly{1, 2, 3} gives {{1, 2, 3}}
	end
	if type(A) == 'string' or type(A) == 'table' then
		return #A
	else
		return 1
	end
end

-- // function diag(A, k)
-- return a table of all entries of the k-th diagonal as a column vector
-- k defaults to 0.
--
-- which diagonal? If k = 0, the main diagonal; if k = j, the diagonal j rows above (if j > 0)
-- or -j rows below the main diagonal (if j < 0). E.g., k = 1, the diagonal right above the main
-- diagonal; k = -1, the diagonal right below the main diagonal.
--
-- // function diag(v), where v is a vector
-- return a square matrix with v as its main diagonal

-- // function diag(v, k), where v is a vector
-- if k > 0, return a matrix with v as the diagonal k rows above the main diagonal.
-- if k < 0, return a matrix with v as the diagonal -k columns below the main diagonal
-- if k = 0, same as diag(v)
--
-- // function diag(v, m, n), where v is a vector
-- return a mxn matrix with vector v (or first elements in it) as its main diagonal
function diag(A, m, n)
	local v = getmetatable(A) == mathly_meta
	if v or ismatrix(A) then
		if not v then setmetatable(A, mathly_meta) end
		local rows, columns = size(A)
		if rows == 1 or columns == 1 then -- row/column vector
			v = flatten(A)
		else -- a matrix
			m = m or 0
			local x = {}
			local xi = 1
			for i = 1, math.min(rows, columns) do
				local j = i - m
				if j > 0 and j <= rows then
					x[xi] = {A[j][i]}
					xi = xi + 1
				end
			end
			return mathly(x)
		end
	elseif type(A) ~= 'table' then
		v = {A}
	else
		v = A
	end

	local z, siz
	if m == nil or n ~= nil then
		if m == nil then m = #v; n = m end
		siz = math.min(#v, m, n)
		z = zeros(m, n)
		if m == 1 then z = rr(z) end -- zeros(1, n) is not a mathly matrix
		for i = 1, siz do
			z[i][i] = v[i]
		end
	else -- return a matrix with v as its diagonal |m| rows above/below the main diagonal
		siz = #v + math.abs(m)
		z = zeros(siz, siz)
		if m >= 0 then
			for i = 1, #v do
				local j = i + m
				z[i][j] = v[i]
			end
		else
			for i = 1, #v do
				local j = i - m
				z[j][i] = v[i]
			end
		end
	end
	return setmetatable(z, mathly_meta)
end -- diag

--[[
--// function eigs(A)
-- Return eigenvalues of a square matrix A.
function eigs(A) -- apply qr factorization
	_mathly_matrix(A, 'eigs(A)')
	local row, col = size(A)
	assert(row == col, 'eigs(A): A must be a square matrix.')
	local Q, R

	local i = 1
	local abs = math.abs
	while true do
		q, r = qr(A)
		A = r * q
		if abs(A[i + 1][i]) < 1e-4 then
			i = i + 1
			if i == row then break end
		end
	end

--	while true do
--		Q, R = qr(A)
--		A = R * Q
--		if norm(diag(A, -1)) < 1e-5 then break end
--	end
	return diag(A)
end
--]]

-- expand/shrink a matrix by adding value v's or dropping entries.
-- the default value of v is 0
function expand(A, m, n, v)
	_mathly_matrix(A, 'expand(A, ...)')
	if m == nil then return A end
	if n == nil then n = m end
	if v == nil then v = 0 end

	local rows, cols = size(A)
	local row, col = math.min(m, rows), math.min(n, cols)
	local z = {}
	for i = 1, row do
		z[i] = {}
		for j = 1, col do
			z[i][j] = A[i][j]
		end
		for j = col + 1, n do
			z[i][j] = v
		end
	end
	for i = row + 1, m do
		z[i] = {}
		for j = 1, n do
			z[i][j] = v
		end
	end
	return setmetatable(z, mathly_meta)
end

-- extract a submatrix of matrix A if B is not specified, or set the submatrix of A with B (A is modified!)
-- 1. make a COPY of A, or
-- 2. COPY to A from B
function submatrix(A, rrange, crange, B, rrange1, crange1)
	assert(type(A) == 'table' and type(A[1]) == 'table', 'submatrix(A, ...): A must be a matrix.')
	return copy(A, rrange, crange, B, rrange1, crange1)
end

-- return a specified slice of a vector
function subtable(A, irange, B, irange1)
	assert(type(A) == 'table' and type(A[1]) ~= 'table', "subtable(A, irange, B, irange1): table A can't be a matrix.")
	local a = copy(A, irange, B, irange1)
	return _set_matrix_meta(a)
end

-- Return L and U in LU factorization of A by Crout's method
function lu(A)
	_mathly_matrix(A, 'lu(A)')
	local s, n = size(A)
	assert(n == s and n > 1, "lu(A): A is not square.\n")
	local abs, L, U = math.abs, zeros(n, n), zeros(n, n)
	for i = 1, n do -- calculate L[i][1 : i]
		for j = 1, i do
			s = 0
			for k = 1, j - 1 do
				s = s + L[i][k] * U[k][j]
			end
			L[i][j] = A[i][j] - s
		end

		U[i][i] = 1	-- calculate U[i][i : end]
		for j = i + 1, n do
			s = 0
			for k = 1, i - 1 do
				s = s + L[i][k] * U[k][j]
			end
			if abs(L[i][i]) < eps then
				error(sprintf('L[%d][%d] = 0. No LU factorization is found.', i, i))
			end
			U[i][j] = (A[i][j] - s) / L[i][i]
		end
	end
	return L, U
end

-- Return QR factorization A=QR, where mxn matrix A = mxn matrix Q * nxn matrix R, Q has orthonormal
-- column vectors, and R is an invertible upper triangular matrix.
-- note: this implementation requires that m >= n.
function qr(A)	-- by Gram-Schmidt process
	_mathly_matrix(A, 'qr(A)')
	local m, n = size(A)
	assert(m >= n, 'qr(A): A is a mxn matrix, where m >= n.')

	local Q = copy(A, '*', 1) -- A(:, 1) -- construct Q
	Q = Q * (1 / norm(Q))
	for i = 2, n do
		local u = copy(A, '*', i) -- A(:, i)
		local v = copy(u)
		for j = 1, i - 1 do
			local vj = copy(Q, '*', j) -- Q(:, j)
			v = v - (sum(u * vj) / sum(vj * vj)) * vj -- u .* vj, vj .* vj
		end
		v = v * (1 / norm(v))	-- normalize it
		Q = horzcat(Q, v)
	end

	local R = zeros(n, n) -- calculate R
	for i = 1, n do
		for j = i, n do
			R[i][j] = sum(copy(A, '*', j) * copy(Q, '*', i)) -- A(:, j) .* Q(:, i)
		end
	end
	return Q, R
end

function det(B)
	_mathly_matrix(B, 'det(A)')
	local m, n = size(B)
	if m ~= n then
		print('det(A): A must be square.')
		return 0
	end
	local A = copy(B)

	local val = 1 -- by gauss elimination
	local abs = math.abs
	for i = 1, n - 1 do
		local maxi = i -- pivoting
		local maxx = abs(A[i][i])
		for k = i + 1, n do
			local absx = abs(A[k][i])
			if absx > maxx then maxi = k; maxx = absx end
		end
		if maxx < 10*eps then return 0 end -- matrix is not invertible

		if maxi ~= i then -- interchange two rows
			val = - val
			for k = i, n do
				A[i][k], A[maxi][k] = A[maxi][k], A[i][k]
			end
		end
		val = val * A[i][i] -- factor out A[i][i]
		for k = i + 1, n do -- 'normalize' A[i][..] --> {0 ... 0 1 x x x}
			A[i][k] = A[i][k] / A[i][i]
		end
		A[i][i] = 1

		for j = i + 1, n do -- elimination
			if abs(A[j][i]) > 10*eps then
				for k = i + 1, n do
					A[j][k] = A[j][k] - A[j][i] * A[i][k]
				end -- A[j][i] = 0 -- not necessary
			end
		end
	end
	return val * A[n][n]
end -- det

-- Concatenate matrices, horizontal
-- rows have to be the same, e.g.: #A == #B
function horzcat(...)
	local args = {}
	for _, v in pairs{...} do
		args[#args + 1] = v
	end
	if #args == 0 then return {} end

	local rows = #args[1]
	for i = 2, #args do
		assert(rows == #args[i], "The row numbers are not the same.")
	end

	local t = {}
	for i = 1, rows do
		t[i] = {}
		for j = 1,#args[1][1] do
			t[i][j] = args[1][i][j]
		end

		for k = 2, #args do
			local offset = #t[i]
			for j = 1, #args[k][1] do
				t[i][j+offset] = args[k][i][j]
			end
		end
	end
	return _set_matrix_meta(t)
end

-- Concatenate matrices, vertical
-- columns have to be the same; e.g.: #A[1] == #B[1]
function vertcat(...)
	local args = {}
	for _, v in pairs{...} do
		args[#args + 1] = v
	end
	if #args == 0 then return {} end

	local cols = #args[1][1]
	for i = 2, #args do
		assert(cols == #args[i][1], "The column numbers are not the same.")
	end

	local t = {}
	for i = 1, #args[1] do
		t[i] = {}
		for j = 1, #args[1][1] do
			t[i][j] = args[1][i][j]
		end
	end
	for k = 2, #args do
		local offset = #t
		for i = 1, #args[k] do
			local _i = i + offset
			t[_i] = {}
			for j = 1, cols do
				t[_i][j] = args[k][i][j]
			end
		end
	end
	return _set_matrix_meta(t)
end

-- merge elements and FLATTENED tables into a single table
function tblcat(...)
	local args = {}
	for _, v in pairs{...} do
		args[#args + 1] = v
	end

	local t = {}
	for i = 1, #args do
		if type(args[i]) == 'table' then
			local x = flatten(args[i])
			for j = 1, #x do
				t[#t + 1] = x[j]
			end
		else
			t[#t + 1] = args[i]
		end
	end
	if isvector(t) then t = _set_matrix_meta(t) end
	return t
end

-----------[[ Set behaviours of +, -, *, and ^ -----------]]

function mathly.numtableadd(t, n, op)
	local function do_it(t)
		local v = {}
		for i = 1, #t do
			if type(t[i]) == 'table' then
				v[#v + 1] = do_it(t[i])
			else
				if op == '+' then
					v[#v + 1] = t[i] + n
				else
					v[#v + 1] = t[i] - n
				end
			end
		end
		return v
	end
	return _set_matrix_meta(do_it(t))
end

-- Special case: if m1 is a row/column mathly matrix, m2 can be a Lua table of any type.
-- This case saves the trouble of accessing b as b[i] rather than b[i][1] while doing Ax - b or Ax + b
function mathly.add_sub_shared(m1, m2, op)
	if type(m1) == 'number' and type(m2) == 'table' then
		if op == '-' then
			return mathly.numtableadd(-m2, m1, '+')
		else
			return mathly.numtableadd(m2, m1, '+')
		end
	elseif type(m2) == 'number' and type(m1) == 'table' then
		return mathly.numtableadd(m1, m2, op)
	end

	local rc = 0
	if getmetatable(m1) == mathly_meta then
		if type(m1[1]) ~= 'table' then rc = 1 elseif #m1[1] == 1 then rc = 2 end
	elseif getmetatable(m2) == mathly_meta then
		if type(m2[1]) ~= 'table' then rc = 1 elseif #m2[1] == 1 then rc = 2 end
	end

	local msg = 'm1 ' .. op .. ' m2: dimensions do not match.'
	local t = {}
	local M1, M2
	if rc == 0 then
		M1, M2 = m1, m2
	elseif rc == 1 then
		M1, M2 = rr(m1), rr(m2)
	else
		M1, M2 = cc(m1), cc(m2)
	end

	local d11, d12 = size(M1)
	local d21, d22 = size(M2)
	if d11 ~= d21 or d12 ~= d22 then error(msg) end

	for i = 1,#M1 do
		local x = {}
		for j = 1,#M1[1] do
			if op == '+' then
				x[j] = M1[i][j] + M2[i][j]
			else
				x[j] = M1[i][j] - M2[i][j]
			end
		end
		t[i] = x
	end

	if rc == 1 then t = tt(t) end
	return _set_matrix_meta(t)
end -- mathly.add_sub_shared

mathly_meta.__add = function(A, B)
	return mathly.add_sub_shared(A, B, '+')
end

mathly_meta.__sub = function(A, B)
	return mathly.add_sub_shared(A, B, '-')
end

-- matlab: a .* b
-- v1 determines the size and structure of the resulted vector
function mathly.matlabvmul(v1, v2)
	local v22 = flatten(v2)
	local x = {}
	if type(v1[1]) ~= 'table' then -- v1 = {1, 2, ...}
		for i = 1,#v1 do x[i] = v1[i] * v22[i] end
	else -- v1 = {{1}, {2}, ...}
		for i = 1,#v1 do x[i] = { v1[i][1] * v22[i] } end
	end
	return _set_matrix_meta(x)
end

-- multiply 2 matrices
-- if both are row/column vectors, find m1 .* m2 as in matlab
-- special case: m1 is a mathly matrix, m2 is any kind of table, for solving Ax = B.
function mathly.mul(m1, m2)
	if type(m1) == 'number' then
		return mathly.mulnum(m2, m1)
	elseif type(m2) == 'number' then
		return mathly.mulnum(m1, m2)
	end
	assert(type(m2) == 'table', 'm1 * m2: m2 must be a table')

	local t, M1, M2 = {}, m1, m2
	local vmsg = 'v1 * v2: vectors v1 and v2 must be of same size.'
	local mmsg = 'A * B: dimensions do not match.'
	if type(m1[1]) ~= 'table' then -- m1: {1, 2, ...}
		if type(m2[1]) ~= 'table' then -- m2: {1, 2, ... }
			if #m1 == #m2 then
				return mathly.matlabvmul(m1, m2)
			else
				error(vmsg)
			end
		elseif #m1 == #m2 then -- m2: {{1, ...},, ...} --> (1xn) x (nxm)
			M1 = { m1 } -- M2 = m2
		elseif #m2 == 1 and #m2[1] == #m1 then -- mythly{1, 2} gives {{1, 2}}
			return mathly.matlabvmul(m1, m2[1])
		else
			error(mmsg)
		end
	elseif #m1[1] == 1 then -- m1: {{1}, ...}
		if type(m2[1]) ~= 'table' then -- m2: {1, ...} --> (nx1) x (1xm)
			M2 = { m2 } -- M1 = m1
		elseif type(m2[1]) == 'table' and #m2[1] == 1 then -- m2: {{1}, ...}
			return mathly.matlabvmul(m1, m2)
		elseif #m2 == 1 then -- m2: {{1, ...}} --> (nx1) x (1xm)
			-- M2 = m2; M1 == m1
		else
			error(mmsg)
		end
	elseif #m1[1] == #m2 then -- m1: {{1, ...}, ...}
		if type(m2[1]) ~= 'table' then -- m2: {1, 2, ...} --> (mxn) x (nx1)
			M2 = {}
			for i = 1,#m2 do M2[i] = { m2[i] } end
		else
			M2 = m2 -- (mxn) x (nxr)
		end
	elseif #m1 == 1 and #m2 == 1 and #m1[1] == #m2[1] then -- both: {{1, 2, ...}}
		return mathly.matlabvmul(m1[1], m2[1])
	else
		error(mmsg)
	end

	for i = 1,#M1 do
		t[i] = {}
		for j = 1,#M2[1] do
			local num = M1[i][1] * M2[1][j]
			for n = 2,#M1[1] do
				num = num + M1[i][n] * M2[n][j]
			end
			t[i][j] = num
		end
	end
	return _set_matrix_meta(t)
end -- mathly.mul

-- Set multiply "*" behaviour
mathly_meta.__mul = function(A, B)
	return mathly.mul(A, B)
end

-- scalar multiplication
function mathly.mulnum(A, num)
	local t = {}
	for i = 1,#A do
		if type(A[1]) == 'table' then
			t[i] = {}
			for j = 1,#A[1] do
				t[i][j] = A[i][j] * num
			end
		else
			t[i] = num * A[i]
		end
	end
	return _set_matrix_meta(t)
end

-- Set division "/" behaviour
mathly_meta.__div = function(m1, m2)
	local err = 'm1 / m2: the dimensions of m1 and m2 do not match.'
	local function adjust(m1, m2)
		if type(m1[1]) ~= 'table' then
			local m, n = size(m2)
			if m == 1 then
				m1 = rr(m1)
			elseif n == 1 then
				m1 = cc(m1)
			else
				error(err)
			end
		end
		return m1
	end
	if type(m2) == 'number' then
		return map(function(x) return x/m2 end, m1)
	elseif type(m1) == 'number' then
		return map(function(x) return m1/x end, m2)
	elseif type(m1) == 'table' and type(m2) == 'table' then
		m1 = adjust(m1, m2)
		m2 = adjust(m2, m1)
		local m, n = size(m1)
		local M, N = size(m2)
		if m ~= M or n ~= N then error(err) end
		local tmp = map(function(x, y) return x/y end, m1, m2)
		return _set_matrix_meta(tmp)
	else
		error('m1 / m2: the type of m1 or m2 is not allowed.')
	end
end -- mathly_meta.__div

-- Set unary minus "-" behavior
mathly_meta.__unm = function(t)
	return mathly.mulnum(t, -1)
end

-- Power of matrix: A^n
-- if n is a table or a non-integer or a number < 0, or A is row/column vector, elementwise
function mathly.pow(A, n)
	if type(n) == 'table' or (type(n) == 'number' and (math.type(n) ~= 'integer' or (n < 2 and n ~= 0))) then
		return _map2(function(x, k) return x^k end, A, n)
	end

	assert(isinteger(n), "A ^ n: n is a nonnegative integer.")
	local t = {}
	if type(A[1]) ~= 'table' then
		for i = 1, #A do t[i] = A[i] ^ n end
	elseif #A == 1 then -- row vector, element wise
		for i = 1, #A[1] do t[i] = A[1][i] ^ n end
		t = {t}
	elseif #A[1] == 1 then -- column vector
		for i = 1, #A do t[i] = { A[i][1] ^ n } end
	else
		assert(#A == #A[1], "A ^ n: A must be a square matrix.")
		if n == 0 then return setmetatable(eye(#A), mathly_meta) end
		t = copy(A)
		for i = 2, n	do t = mathly.mul(t, A) end
	end
	return _set_matrix_meta(t)
end

-- if opt is 'T' (i.e., T, reserved by MathLua), return the transpose of matrix A
mathly_meta.__pow = function(A, opt)
	if opt == 'T' then
		return setmetatable(transpose(A), mathly_meta)
	else
		return setmetatable(mathly.pow(A, opt), mathly_meta)
	end
end

-- Set concat ".." behaviour
mathly_meta.__concat = function(...)
	return horzcat(...)
end

function mathly.tostring(t)
	_set_disp_format(t)
	if type(t[1]) == 'table' then
		local rowstrs = {}
		for i = 1,#t do
			rowstrs[i] = table.concat(_map(_tostring, t[i]), " ")
		end
		return table.concat(rowstrs, "\n")
	else
		return table.concat(_map(_tostring, t), " ")
	end
end

-- Set tostring "tostring(t)" behaviour
mathly_meta.__tostring = function(...)
	return mathly.tostring(...)
end

--// mathly (rows [, comlumns [, value]])
-- set __call behaviour of matrix
-- for mathly(...) as mathly.new(...)
setmetatable(mathly, { __call = function(...) return mathly.new(...) end })

-- set __call "matrix()" behaviour
mathly_meta.__call = function(...)
	disp(...)
end

--// __index handling
mathly_meta.__index = {}
for k,v in pairs(mathly) do
	mathly_meta.__index[k] = v
end

--------------- end of mathly.lua -----------------


--[[ The following code is obtained from URL: https://github.com/kenloen/plotly.lua
		 All variables in functions are made 'local' in addition to some changes. Some
		 functions have been removed. All credit belongs to the original auther. --]]

local json = { version = "dkjson 2.8" }

-- https://cdn.plot.ly/plotly-latest.min.js
plotly.cdn_main = "<script src='" .. plotly_engine .. "'></script>"
plotly.id_count = 1
plotly.layout = {}

local _writehtml_failedq = false

-- From: https://stackoverflow.com/questions/11163748/open-web-browser-using-lua-in-a-vlc-extension#18864453
-- Attempts to open a given URL in the system default browser, regardless of Operating System.
-- Figure metatable
local figure = {}

---Adding a trace for the figure. All options can be found here: https://plotly.com/javascript/reference/index/
---Easy to call like: figure:add_trace{x=x, y=y, ...}
---@param self table
---@param trace table
function figure.add_trace(self, trace)
	self["data"][#self["data"]+1] = trace
end

local _dash_style = {["-"] = "solid", [":"] = "dot", ["--"] = "dash"}
local _mode_shorthand = {["m"] = "markers", ["l"]="lines", ["m+l"]="lines+markers", ["l+m"]="lines+markers"}


--[[Adding a trace for the figure with shorthand for common options (similar to matlab or matplotlib).
All js options can be found here: https://plotly.com/javascript/reference/index/
Easy to call like: figure:plot{x, y, ...}
Shorthand options:
 key            | explanation
 ---------------+------------
 *1*            | x-values
 *2*            | y-values
 *ls*           | line-style (options: "-", ".", "--")
 *lw*           | line-width (numeric value - default 2)
 *ms*           | marker-size (numeric value - default 2)
 *c* or *color* | sets color of line and marker
 *mode*         | shorter mode forms (options: "m"="markers", "l"="lines", "m+l" or "l+m"="markers+lines")
]]
---@param self plotly.figure
---@param trace table
---@return plotly.figure
function figure.plot(self, trace)
	if not trace.line then trace.line = {} end
	if not trace.marker then trace.marker = {} end
	for k, v in pairs(trace) do
		if k == "ls" or k == 'style' then
			trace.line.dash = _dash_style[v]
			trace[k] = nil
		elseif k == "lw" or k == 'width' then
			trace.line.width = v
			trace[k] = nil
		elseif k == 1 then
			trace.x = v
			trace[k] = nil
		elseif k == 2 then
			trace.y = v
			trace[k] = nil
		elseif k == "ms" or k == 'size' then
			trace.marker.size = v
			trace[k] = nil
		elseif k == 'symbol' then
			trace.marker.symbol = v
			trace[k] = nil
		elseif k == "c" or k == "color" then
			trace.marker.color = v
			trace.line.color = v
			trace[k] = nil
		elseif k == "mode" and _mode_shorthand[v] then
			trace.mode = _mode_shorthand[v]
		end
	end

	self:add_trace(trace)
	self:update_layout(plotly.layout)
	return self
end -- figure.plot

function figure.update_layout(self, layout)
	for name, val in pairs(layout) do
		self["layout"][name] = val
	end
end

function figure.toplotstring(self)
	if self.layout == nil then self.layout = {} end
	if self.layout.xaxis == nil then self.layout.xaxis = {} end
	if self.layout.yaxis == nil then self.layout.yaxis = {} end
	if (not _3d_plotq) and (not self.layout.grid) and _axis_equalq then
		self.layout.xaxis.scaleanchor = 'y'
		self.layout.yaxis.scaleratio = 1
	end

	if _3d_plotq then
		if self.layout.zaxis == nil then self.layout.zaxis = {} end
	else
		self.layout.showlegend = _showlegendq
		if not self.layout.grid then -- to make it simple, only valid for 2d graphs on a single figure; invalid for a grid of subplots
			self.layout.xaxis.visible = _xaxis_visibleq
			self.layout.xaxis.showgrid = _gridline_visibleq
			self.layout.yaxis.visible = _yaxis_visibleq
			self.layout.yaxis.showgrid = _gridline_visibleq
			if _xrange then self.layout.xaxis.range = _xrange end
			if _yrange then self.layout.yaxis.range = _yrange end
		end
	end
	if _vecfield_annotations ~= nil then
		self.layout.showlegend = false
		self.layout.annotations = _vecfield_annotations
		_vecfield_annotations = nil
	end
	self:update_layout(plotly.layout)
	if self.layout.width == nil and self.layout.height == nil then
		self.layout.width = 600 -- 4x3
		self.layout.height = 450
	elseif self.layout.height == nil then
		self.layout.height = self.layout.width
	elseif self.layout.width == nil then
		self.layout.width = self.layout.height
	end
	if self.layout.grid ~= nil then
		if type(self.layout.grid.rows) == 'string' then
			self.layout.grid.rows = tonumber(self.layout.grid.rows)
		end
		if type(self.layout.grid.columns) == 'string' then
			self.layout.grid.columns = tonumber(self.layout.grid.columns)
		end
		if self.layout.grid.columns == nil or
			 self.layout.grid.rows == nil or
			 self.layout.grid.rows * self.layout.grid.columns < #self.data then
			return '<html><body>Invalid grid: rows and/or columns not defined, or rows * columns &lt; the number of traces.</body></html>'
		end

		-- plotly-2.9.0.min.js, hopefully all versions, determines if grid options are used
		-- by checking whether the texts of xaxis and yaxis are different for traces
		for i = 1,#self.data do
			if not _specific_gridq then
				self['data'][i]['xaxis'] = 'x' .. i -- they are different :-)
				self['data'][i]['yaxis'] = 'y' .. i
			end
			local g = self.layout.grid
			if g then
				if g.xranges and g.xranges[i] then
					local axis = 'xaxis' .. qq(i == 1, '', i)
					if self['layout'][axis] == nil then self['layout'][axis] = {} end
					self['layout'][axis]['range'] = g.xranges[i]
				end
				if g.yranges and g.yranges[i] then
					local axis = 'yaxis' .. qq(i == 1, '', i)
					if self['layout'][axis] == nil then self['layout'][axis] = {} end
					self['layout'][axis]['range'] = g.yranges[i]
				end
			end
			if _3d_plotq then self['data'][i]['zaxis'] = 'z' .. i end
		end
	end

	-- Converting input
	local data_str = json.encode(self["data"])
	local layout_str = json.encode(self["layout"])
	local div_id
	if not self.div_id then div_id = "plot" .. plotly.id_count end
	plotly.id_count = plotly.id_count+1
	local plot = [[<div id='%s'>
<script type="text/javascript">
	var data = %s
	var layout = %s
	Plotly.newPlot(%s, data, layout);
</script>
</div>
]] -- simplified
	return string.format(plot, div_id, data_str, layout_str, div_id)
end -- figure.toplotstring

function figure.tohtmlstring(self)
	local header = "<html>\n<meta charset=\"utf-8\">\n<head>" .. plotly.cdn_main .. "</head>\n"
	return header.."<body>\n" .. self:toplotstring() .. "</body>\n</html>"
end

---Saves the figure to an HTML file with *filename*
function figure.tofile(self, filename)
	_writehtml_failedq = false
	local html_str = self:tohtmlstring()
	local file = io.open(filename, "w")
	if file ~= nil then
		file:write(html_str)
		file:close()
	else
		_writehtml_failedq = true
		print(string.format("Failed to create %s. The very device might not be writable.", filename))
	end
	return self
end

---Opens/shows the plot in the browser
function figure.show(self)
	self:tofile(tmp_plot_html_file)
	if not _writehtml_failedq then
		_open_url(tmp_plot_html_file) -- keep the file
		print("The graph is in " .. tmp_plot_html_file .. ' if you need it.')
	end
end

function plotly.figure()
	local fig = {data={}, layout={}, config={}}
	setmetatable(fig, {__index=figure})
	return fig
end

-- plot multiple functions/traces on a single figure
function plotly.plots(traces)
	local fig = plotly.figure()
	for i = 1, #traces do
		fig:plot(traces[i])
	end
	return fig
end



--[[ The code above is obtained from URL: https://github.com/kenloen/plotly.lua
		 All variables in functions are made 'local' in addition to some changes. Some
		 functions have been removed. All credit belongs to the original auther. --]]


--[[ The following code is obtained from URL: http://dkolf.de/dkjson-lua
		 Names are changed to _dk_ and some functions or so have been removed.
		 All credit belongs to the original auther. --]]

-- global dependencies:
local _dk_pairs, _dk_type, _dk_tostring = pairs, type, tostring
local _dk_error = error
local _dk_floor, _dk_huge = math.floor, math.huge
local _dk_gsub, _dk_strsub, _dk_strbyte, _dk_strfind, _dk_strformat =
			string.gsub, string.sub, string.byte, string.find, string.format
local _dk_strmatch = string.match
local _dk_concat = table.concat

local function _dk_isarray(t)
	local max, n, arraylen = 0, 0, 0
	for k,v in _dk_pairs(t) do
		if k == 'n' and _dk_type(v) == 'number' then
			arraylen = v
			if v > max then max = v end
		else
			if _dk_type(k) ~= 'number' or k < 1 or _dk_floor(k) ~= k then
				return false
			end
			if k > max then max = k end
			n = n + 1
		end
	end
	if max > 10 and max > arraylen and max > n * 2 then
		return false -- don't create an array with too many holes
	end
	return true, max
end

local _dk_escapecodes = {
	["\""] = "\\\"", ["\\"] = "\\\\", ["\b"] = "\\b", ["\f"] = "\\f",
	["\n"] = "\\n",  ["\r"] = "\\r",  ["\t"] = "\\t"
}

local function _dk_escapeutf8(uchar)
	local value = _dk_escapecodes[uchar]
	if value then
		return value
	end
	local a, b, c, d = _dk_strbyte(uchar, 1, 4)
	a, b, c, d = a or 0, b or 0, c or 0, d or 0
	if a <= 0x7f then
		value = a
	elseif 0xc0 <= a and a <= 0xdf and b >= 0x80 then
		value = (a - 0xc0) * 0x40 + b - 0x80
	elseif 0xe0 <= a and a <= 0xef and b >= 0x80 and c >= 0x80 then
		value = ((a - 0xe0) * 0x40 + b - 0x80) * 0x40 + c - 0x80
	elseif 0xf0 <= a and a <= 0xf7 and b >= 0x80 and c >= 0x80 and d >= 0x80 then
		value = (((a - 0xf0) * 0x40 + b - 0x80) * 0x40 + c - 0x80) * 0x40 + d - 0x80
	else
		return ""
	end
	if value <= 0xffff then
		return _dk_strformat("\\u%.4x", value)
	elseif value <= 0x10ffff then
		-- encode as UTF-16 surrogate pair
		value = value - 0x10000
		local highsur, lowsur = 0xD800 + _dk_floor(value/0x400), 0xDC00 + (value % 0x400)
		return _dk_strformat("\\u%.4x\\u%.4x", highsur, lowsur)
	else
		return ""
	end
end -- _dk_escapeutf8

local function _dk_fsub(str, pattern, repl)
	-- gsub always builds a new string in a buffer, even when no match
	-- exists. First using find should be more efficient when most strings
	-- don't contain the pattern.
	if _dk_strfind(str, pattern) then
		return _dk_gsub(str, pattern, repl)
	else
		return str
	end
end

local function _dk_quotestring(v)
	-- based on the regexp "escapable" in https://github.com/douglascrockford/JSON-js
	v = _dk_fsub(v, "[%z\1-\31\"\\\127]", _dk_escapeutf8)
	if _dk_strfind(v, "[\194\216\220\225\226\239]") then
		v = _dk_fsub(v, "\194[\128-\159\173]", _dk_escapeutf8)
		v = _dk_fsub(v, "\216[\128-\132]", _dk_escapeutf8)
		v = _dk_fsub(v, "\220\143", _dk_escapeutf8)
		v = _dk_fsub(v, "\225\158[\180\181]", _dk_escapeutf8)
		v = _dk_fsub(v, "\226\128[\140-\143\168-\175]", _dk_escapeutf8)
		v = _dk_fsub(v, "\226\129[\160-\175]", _dk_escapeutf8)
		v = _dk_fsub(v, "\239\187\191", _dk_escapeutf8)
		v = _dk_fsub(v, "\239\191[\176-\191]", _dk_escapeutf8)
	end
	return "\"" .. v .. "\""
end
json._dk_quotestring = _dk_quotestring

local function _dk_replace(str, o, n)
	local i, j = _dk_strfind(str, o, 1, true)
	if i then
		return _dk_strsub(str, 1, i-1) .. n .. _dk_strsub(str, j+1, -1)
	else
		return str
	end
end

-- locale independent _dk_num2str functions
local _dk_decpoint, _dk_numfilter

local function _dk_updatedecpoint()
	_dk_decpoint = _dk_strmatch(_dk_tostring(0.5), "([^05+])")
	-- build a filter that can be used to remove group separators
	_dk_numfilter = "[^0-9%-%+eE" .. _dk_gsub(_dk_decpoint, "[%^%$%(%)%%%.%[%]%*%+%-%?]", "%%%0") .. "]+"
end

_dk_updatedecpoint()

local function _dk_num2str(num)
	return _dk_replace(_dk_fsub(_dk_tostring(num), _dk_numfilter, ""), _dk_decpoint, ".")
end

local _dk_encode2 -- forward declaration

local function _dk_addpair(key, value, prev, level, buffer, buflen, tables, globalorder, state)
	local kt = _dk_type(key)
	if kt ~= 'string' and kt ~= 'number' then
		return nil, "type '" .. kt .. "' is not supported as a key by JSON."
	end
	if prev then
		buflen = buflen + 1
		buffer[buflen] = ","
	end
	-- When Lua is compiled with LUA_NOCVTN2S this will fail when
	-- numbers are mixed into the keys of the table. JSON keys are always
	-- strings, so this would be an implicit conversion too and the failure
	-- is intentional.
	buffer[buflen+1] = _dk_quotestring(key)
	buffer[buflen+2] = ":"
	return _dk_encode2(value, level, buffer, buflen + 2, tables, globalorder, state)
end

local function _dk_appendcustom(res, buffer, state)
	local buflen = state.bufferlen
	if _dk_type(res) == 'string' then
		buflen = buflen + 1
		buffer[buflen] = res
	end
	return buflen
end

local function _dk_exception(reason, value, state, buffer, buflen, defaultmessage)
	defaultmessage = defaultmessage or reason
	local handler = state._dk_exception
	if not handler then
		return nil, defaultmessage
	else
		state.bufferlen = buflen
		local ret, msg = handler(reason, value, state, defaultmessage)
		if not ret then return nil, msg or defaultmessage end
		return _dk_appendcustom(ret, buffer, state)
	end
end

_dk_encode2 = function(value, level, buffer, buflen, tables, globalorder, state)
	local valtype = _dk_type(value)
	if value == nil then
		buflen = buflen + 1
		buffer[buflen] = "null"
	elseif valtype == 'number' then
		local s
		if value ~= value or value >= _dk_huge or -value >= _dk_huge then
			-- This is the behaviour of the original JSON implementation.
			s = "null"
		else
			s = _dk_num2str(value)
		end
		buflen = buflen + 1
		buffer[buflen] = s
	elseif valtype == 'boolean' then
		buflen = buflen + 1
		buffer[buflen] = value and "true" or "false"
	elseif valtype == 'string' then
		buflen = buflen + 1
		buffer[buflen] = _dk_quotestring(value)
	elseif valtype == 'table' then
		if tables[value] then
			return _dk_exception('reference cycle', value, state, buffer, buflen)
		end
		tables[value] = true
		level = level + 1
		local isa, n = _dk_isarray(value)
		local msg
		if isa then -- JSON array
			buflen = buflen + 1
			buffer[buflen] = "["
			for i = 1, n do
				buflen, msg = _dk_encode2(value[i], level, buffer, buflen, tables, globalorder, state)
				if not buflen then return nil, msg end
				if i < n then
					buflen = buflen + 1
					buffer[buflen] = ","
				end
			end
			buflen = buflen + 1
			buffer[buflen] = "]"
		else -- JSON object
			local prev = false
			buflen = buflen + 1
			buffer[buflen] = "{"
			local order = globalorder
			if order then
				local used = {}
				n = #order
				for i = 1, n do
					local k = order[i]
					local v = value[k]
					if v ~= nil then
						used[k] = true
						buflen, msg = _dk_addpair(k, v, prev, level, buffer, buflen, tables, globalorder, state)
						if not buflen then return nil, msg end
						prev = true -- add a seperator before the next element
					end
				end
				for k,v in _dk_pairs(value) do
					if not used[k] then
						buflen, msg = _dk_addpair(k, v, prev, level, buffer, buflen, tables, globalorder, state)
						if not buflen then return nil, msg end
						prev = true -- add a seperator before the next element
					end
				end
			else -- unordered
				for k,v in _dk_pairs(value) do
					buflen, msg = _dk_addpair(k, v, prev, level, buffer, buflen, tables, globalorder, state)
					if not buflen then return nil, msg end
					prev = true -- add a seperator before the next element
				end
			end
			buflen = buflen + 1
			buffer[buflen] = "}"
		end
		tables[value] = nil
	else
		return _dk_exception('unsupported type', value, state, buffer, buflen,
			"type '" .. valtype .. "' is not supported by JSON.")
	end
	return buflen
end -- _dk_encode2

function json.encode(value, state)
	state = state or {}
	local oldbuffer = state.buffer
	local buffer = oldbuffer or {}
	state.buffer = buffer
	_dk_updatedecpoint()
	local ret, msg =
		_dk_encode2(value, state.level or 0, buffer, state.bufferlen or 0, state.tables or {}, state.keyorder, state)
	if not ret then
		_dk_error(msg, 2)
	elseif oldbuffer == buffer then
		state.bufferlen = ret
		return true
	else
		state.bufferlen = nil
		state.buffer = nil
		return _dk_concat(buffer)
	end
end

--[[ The above code is obtained from URL: http://dkolf.de/dkjson-lua
		 Names are changed to _dk_ and some functions or so have been removed.
		 All credit belongs to the original auther. --]]

return mathly

--[[

1. Most functions provided in this mathly module, e.g., copy, disp, and display, can't be applied to tables
like x = {1, 2, age=20, 10, year=2024} with fields, for instance, age. It is designed simply for numerical
computing.

2. Part of modules dkjson.lua (http://dkolf.de/dkjson-lua) and plotly.lua (https://github.com/kenloen/plotly.lua)
is merged into this project to reduce dependencies and make it easier for users to download and use mathly. Though
some changes have been made, full credit belongs to the original authors for whom the original author of mathly
is very grateful.

3. This project was started first right in the downloaded code of the Lua module, matrix.lua, found
in https://github.com/davidm/lua-matrix/blob/master/lua/matrix.lua, to see if Lua is good for
numerical computing. However, it failed to solve numerically a boundary value problem. The solution
was obviously wrong because the boundary condition at one endpoint is not satisfied, but I could not find
anything wrong in both the algorithm and the code. I had to wonder if there were bugs in the module. In many
cases, it is easier to start a small project from scratch than debugging and using others' code. In
addition, matrix.lua addresses a column vector like a[i][1] and a row vector a[1][i], rather than a[i]
in both cases, which is quite ugly and unnatural. Furthermore, basic plotting utility is not provided in
matrix.lua. Therefore, this mathly module was developed. But anyway, the work in matrix.lua is highly
appreciated.

David Wang, dwang at liberty dot edu, on 12/25/2024

--]]
