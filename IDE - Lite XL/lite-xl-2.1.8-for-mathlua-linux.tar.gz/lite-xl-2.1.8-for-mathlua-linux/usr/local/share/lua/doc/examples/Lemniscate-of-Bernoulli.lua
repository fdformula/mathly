-- by David Wang, dwang@liberty.edu, on 09/21/2026
-- https://en.wikipedia.org/wiki/Lemniscate_of_Bernoulli
-- see also: https://www.mathcurve.com/courbes2d.gb/lemniscate/lemniscate.shtml
opts = {
  t = {0, 2 * pi, 0.01},
  a = {-20, 20, default = 4},
  xrange = {-22, 22}, yrange = {-5, 5},
  resolution = 3000,
  layout = {
    width = 600, height = 600, square = true,
    xaxis = { visible = false }, yaxis = { visible = false },
    title = "<font size=3>Lemniscate of Bernoulli:<br><em>x</em>(<em>t</em>) = a cos <em>t</em> / (1 + sin<sup>2</sup><em>t</em>), <em>y</em>(<em>t</em>) = a sin <em>t</em> cos <em>t</em> / (1 + sin<sup>2</sup><em>t</em>)</font>"
  }
}
manipulate({
    '@(t) a*cos(t)/(1+sin(t)^2)',
    '@(t) a*sin(t)*cos(t)/(1+sin(t)^2)'
  }, opts)
